
require('dotenv').config();
const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');
const multer = require('multer');
const Tesseract = require('tesseract.js');
const fs = require('fs').promises; // Use promises for async file cleanup

const app = express();
const upload = multer({ dest: 'uploads/' });

// Middleware
app.use(cors());
app.use(express.json());

// MongoDB Schema and Model
const textSchema = new mongoose.Schema({
  name: String,
  content: String,
  dateTime: Date,
});
const TextModel = mongoose.model('Text', textSchema);

// Text extraction route
app.post('/api/extract-text', upload.single('image'), async (req, res) => {
  try {
    const imagePath = req.file.path;
    console.log('Processing image: ' + imagePath);

    const result = await Tesseract.recognize(
      imagePath,
      'eng',
      { logger: m => console.log(m) } // Optional: Log progress
    );
    console.log('OCR Result: ' + result.data.text);

    // Save to MongoDB
    const newText = new TextModel({
      name: `Document ${await TextModel.countDocuments() + 1}`,
      content: result.data.text,
      dateTime: new Date(),
    });
    await newText.save();

    res.json({ extractedText: result.data.text });

    // Clean up the uploaded file
    await fs.unlink(imagePath).catch(err => console.error('Error deleting file:', err));
  } catch (error) {
    console.error('OCR Error: ', error);
    res.status(500).json({ error: 'OCR processing failed', details: error.message });

    // Ensure file is deleted even if an error occurs
    if (imagePath) {
      await fs.unlink(imagePath).catch(err => console.error('Error deleting file in catch:', err));
    }
  }
});
app.get('/api/getSavedTexts', async (req, res) => {
  try {
    const texts = await TextModel.find().sort({ dateTime: -1 }); // Newest first
    res.json(texts);
  } catch (error) {
    res.status(500).json({ error: 'Failed to fetch texts' });
  }
}); 

// MongoDB connection
const MONGO_URI = process.env.MONGO_URI;
mongoose.connect(MONGO_URI, {
  useNewUrlParser: true,
  useUnifiedTopology: true,
})
  .then(() => console.log('MongoDB connected'))
  .catch((err) => console.error('MongoDB connection error:', err));

// Start server
const PORT = process.env.PORT || 3000;
app.listen(PORT, '0.0.0.0',() => {
  console.log(`Server running on port ${PORT}`);
});
console.log("Loaded PORT:", process.env.PORT);
console.log("Loaded MONGO_URI:", process.env.MONGO_URI);
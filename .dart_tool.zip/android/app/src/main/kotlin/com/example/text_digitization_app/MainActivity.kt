package com.example.text_digitization_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()


// import 'package:flutter/material.dart';
// import 'package:hive/hive.dart';
// import 'package:firebase_auth/firebase_auth.dart';
// import '../models/text_model.dart';
// import '../screens/protected_saved_documents_screen.dart';
// import '../screens/settings_screens.dart';
// import '../screens/text_extractor_screen.dart';
// import '../screens/welcome_screen.dart';
// import 'package:shared_preferences/shared_preferences.dart';


// class Sidebar extends StatefulWidget {
//   final Box<TextModel>? box;

//   const Sidebar({Key? key, required this.box}) : super(key: key);

//   @override
//   State<Sidebar> createState() => _SidebarState();
// }

// class _SidebarState extends State<Sidebar> {
//   String? _email;
//   String? _name;
//   String? _photoUrl;

//   @override
//   void initState() {
//     super.initState();
//     _loadUserInfo();
//   }
//   Future<void> _loadUserInfo() async {
//   final prefs = await SharedPreferences.getInstance();
//   setState(() {
//     _email = prefs.getString('email') ?? 'Your Documents Hub';
//     _name = prefs.getString('name') ?? 'Welcome!';
//     _photoUrl = prefs.getString('photoUrl');
//   });
//   print("Loaded Email: $userEmail");
//   print("Loaded Name: $userName");
//   print("Loaded Photo URL: $userPhotoUrl");
// }


  


//   @override
//   Widget build(BuildContext context) {
//     return Drawer(
//       child: Container(
//         decoration: const BoxDecoration(
//           gradient: LinearGradient(
//             colors: [Color(0xFF0D47A1), Color(0xFF1976D2)],
//             begin: Alignment.topCenter,
//             end: Alignment.bottomCenter,
//           ),
//         ),
//         child: Column(
//           children: [
//             Container(
//               padding: const EdgeInsets.only(top: 40, bottom: 20),
//               width: double.infinity,
//               decoration: BoxDecoration(
//                 gradient: LinearGradient(
//                   colors: [Colors.blue.shade900, Colors.blueAccent],
//                   begin: Alignment.topLeft,
//                   end: Alignment.bottomRight,
//                 ),
//                 boxShadow: [
//                   BoxShadow(
//                     color: Colors.black26,
//                     blurRadius: 6,
//                     offset: Offset(0, 3),
//                   ),
//                 ],
//               ),
//               child: Column(
//                 children: [
//                   CircleAvatar(
//                     radius: 40,
//                     backgroundImage: _photoUrl != null
//                         ? NetworkImage(_photoUrl!)
//                         : const AssetImage("assets/default_avatar.png") as ImageProvider,
//                   ),
//                   const SizedBox(height: 10),
//                   Text(
//                     _name ?? 'Welcome!',
//                     style: const TextStyle(color: Colors.white, fontSize: 18, fontWeight: FontWeight.bold),
//                   ),
//                   Text(
//                     _email ?? 'Your Documents Hub',
//                     style: const TextStyle(color: Colors.white70, fontSize: 14),
//                   ),
//                 ],
//               ),
//             ),
//             const SizedBox(height: 10),
//             Expanded(
//               child: ListView(
//                 children: [
//                   _buildTile(
//                     icon: Icons.medical_services,
//                     title: 'Text Extractor',
//                     page: TextExtractorScreen(box: widget.box!),
//                   ),
//                   _buildTile(
//                     icon: Icons.folder_shared,
//                     title: 'Saved Documents',
//                     page: ProtectedSavedDocumentsScreen(box: widget.box!),
//                   ),
//                   _buildTile(
//                     icon: Icons.settings,
//                     title: 'Settings',
//                     page: SettingsScreen(box: widget.box!),
//                   ),
//                   const Divider(color: Colors.white38, indent: 16, endIndent: 16),
//                   _buildTile(
//                     icon: Icons.logout,
//                     title: 'Sign Out',
//                     onTap: () async {
//                       await FirebaseAuth.instance.signOut();
//                       Navigator.of(context).pushAndRemoveUntil(
//                         MaterialPageRoute(
//                           builder: (context) => WelcomeScreen(box: widget.box!),
//                         ),
//                         (route) => false,
//                       );
//                     },
//                   ),
//                 ],
//               ),
//             ),
//             const Padding(
//               padding: EdgeInsets.all(12.0),
//               child: Text(
//                 'Made for Doctors 🩺',
//                 style: TextStyle(color: Colors.white70, fontStyle: FontStyle.italic),
//               ),
//             ),
//           ],
//         ),
//       ),
//     );
//   }

//   Widget _buildTile({
//     required IconData icon,
//     required String title,
//     Widget? page,
//     VoidCallback? onTap,
//   }) {
//     return ListTile(
//       leading: Icon(icon, color: Colors.white),
//       title: Text(
//         title,
//         style: const TextStyle(color: Colors.white, fontSize: 16, fontWeight: FontWeight.w500),
//       ),
//       hoverColor: Colors.white24,
//       onTap: onTap ??
//           () {
//             Navigator.pop(context);
//             Navigator.pushReplacement(
//               context,
//               MaterialPageRoute(builder: (context) => page!),
//             );
//           },
//     );
//   }
// }


// import 'package:flutter/material.dart';
// import 'package:hive/hive.dart';
// import 'package:firebase_auth/firebase_auth.dart';
// import '../models/text_model.dart';
// import '../screens/protected_saved_documents_screen.dart';
// import '../screens/settings_screens.dart';
// import '../screens/text_extractor_screen.dart';
// import '../screens/welcome_screen.dart';
// import 'package:shared_preferences/shared_preferences.dart';

// class Sidebar extends StatefulWidget {
//   final Box<TextModel>? box;

//   const Sidebar({Key? key, required this.box}) : super(key: key);

//   @override
//   State<Sidebar> createState() => _SidebarState();
// }

// class _SidebarState extends State<Sidebar> {
//   String? _email;
//   String? _name;
//   String? _photoUrl;

//   @override
//   void initState() {
//     super.initState();
//     _loadUserInfo();
//   }

//   Future<void> _loadUserInfo() async {
//     final prefs = await SharedPreferences.getInstance();
//     setState(() {
//       _email = prefs.getString('email') ?? 'Your Documents Hub';
//       _name = prefs.getString('name') ?? 'Welcome!';
//       _photoUrl = prefs.getString('photoUrl');
//     });

//     // Debugging: Ensure correct data is being loaded
//     print("Loaded Email: $_email");
//     print("Loaded Name: $_name");
//     print("Loaded Photo URL: $_photoUrl");
//   }

//   @override
//   Widget build(BuildContext context) {
//     return Drawer(
//       child: Container(
//         decoration: const BoxDecoration(
//           gradient: LinearGradient(
//             colors: [Color(0xFF0D47A1), Color(0xFF1976D2)],
//             begin: Alignment.topCenter,
//             end: Alignment.bottomCenter,
//           ),
//         ),
//         child: Column(
//           children: [
//             Container(
//               padding: const EdgeInsets.only(top: 40, bottom: 20),
//               width: double.infinity,
//               decoration: BoxDecoration(
//                 gradient: LinearGradient(
//                   colors: [Colors.blue.shade900, Colors.blueAccent],
//                   begin: Alignment.topLeft,
//                   end: Alignment.bottomRight,
//                 ),
//                 boxShadow: [
//                   BoxShadow(
//                     color: Colors.black26,
//                     blurRadius: 6,
//                     offset: Offset(0, 3),
//                   ),
//                 ],
//               ),
//               child: Column(
//                 children: [
//                   CircleAvatar(
//                     radius: 40,
//                     backgroundImage: _photoUrl != null
//                         ? NetworkImage(_photoUrl!)
//                         : const AssetImage("assets/default_avatar.png") as ImageProvider,
//                   ),
//                   const SizedBox(height: 10),
//                   Text(
//                     _name ?? 'Welcome!',
//                     style: const TextStyle(color: Colors.white, fontSize: 18, fontWeight: FontWeight.bold),
//                   ),
//                   Text(
//                     _email ?? 'Your Documents Hub',
//                     style: const TextStyle(color: Colors.white70, fontSize: 14),
//                   ),
//                 ],
//               ),
//             ),
//             const SizedBox(height: 10),
//             Expanded(
//               child: ListView(
//                 children: [
//                   _buildTile(
//                     icon: Icons.medical_services,
//                     title: 'Text Extractor',
//                     page: TextExtractorScreen(box: widget.box!),
//                   ),
//                   _buildTile(
//                     icon: Icons.folder_shared,
//                     title: 'Saved Documents',
//                     page: ProtectedSavedDocumentsScreen(box: widget.box!),
//                   ),
//                   _buildTile(
//                     icon: Icons.settings,
//                     title: 'Settings',
//                     page: SettingsScreen(box: widget.box!),
//                   ),
//                   const Divider(color: Colors.white38, indent: 16, endIndent: 16),
//                   _buildTile(
//                     icon: Icons.logout,
//                     title: 'Sign Out',
//                     onTap: () async {
//                       await FirebaseAuth.instance.signOut();
//                       Navigator.of(context).pushAndRemoveUntil(
//                         MaterialPageRoute(
//                           builder: (context) => WelcomeScreen(box: widget.box!),
//                         ),
//                         (route) => false,
//                       );
//                     },
//                   ),
//                 ],
//               ),
//             ),
//             const Padding(
//               padding: EdgeInsets.all(12.0),
//               child: Text(
//                 'Made for Doctors 🩺',
//                 style: TextStyle(color: Colors.white70, fontStyle: FontStyle.italic),
//               ),
//             ),
//           ],
//         ),
//       ),
//     );
//   }

//   Widget _buildTile({
//     required IconData icon,
//     required String title,
//     Widget? page,
//     VoidCallback? onTap,
//   }) {
//     return ListTile(
//       leading: Icon(icon, color: Colors.white),
//       title: Text(
//         title,
//         style: const TextStyle(color: Colors.white, fontSize: 16, fontWeight: FontWeight.w500),
//       ),
//       hoverColor: Colors.white24,
//       onTap: onTap ??
//           () {
//             Navigator.pop(context);
//             Navigator.pushReplacement(
//               context,
//               MaterialPageRoute(builder: (context) => page!),
//             );
//           },
//     );
//   }
// }

// import 'package:flutter/material.dart';
// import 'package:shared_preferences/shared_preferences.dart';
// import 'package:firebase_auth/firebase_auth.dart';
// import '../screens/protected_saved_documents_screen.dart';
// import '../screens/settings_screens.dart';
// import '../screens/text_extractor_screen.dart';
// import '../screens/welcome_screen.dart';
// import 'package:hive/hive.dart';  // Import Hive
// import '../models/text_model.dart';  // Import TextModel


// class Sidebar extends StatefulWidget {
//   final Box<TextModel> box;  // Add this line to accept the box parameter
//   const Sidebar({super.key, required this.box});

//   @override
//   State<Sidebar> createState() => _SidebarState();
// }

// class _SidebarState extends State<Sidebar> {
//   String? _email;
//   String? _name;
//   String? _avatarLetter;

//   @override
//   void initState() {
//     super.initState();
//     _loadUserInfo();
//   }

//   Future<void> _loadUserInfo() async {
//     final prefs = await SharedPreferences.getInstance();
//     setState(() {
//       _email = prefs.getString('email') ?? 'Your Documents Hub';
//       _name = prefs.getString('name') ?? 'Welcome!';
//       _avatarLetter = prefs.getString('avatar') ?? 'U';  // Default to 'U'
//     });
//   }

//   @override
//   Widget build(BuildContext context) {
//     return Drawer(
//       child: Container(
//         decoration: const BoxDecoration(
//           gradient: LinearGradient(
//             colors: [Color(0xFF0D47A1), Color(0xFF1976D2)],
//             begin: Alignment.topCenter,
//             end: Alignment.bottomCenter,
//           ),
//         ),
//         child: Column(
//           children: [
//             Container(
//               padding: const EdgeInsets.only(top: 40, bottom: 20),
//               width: double.infinity,
//               decoration: BoxDecoration(
//                 gradient: LinearGradient(
//                   colors: [Colors.blue.shade900, Colors.blueAccent],
//                   begin: Alignment.topLeft,
//                   end: Alignment.bottomRight,
//                 ),
//                 boxShadow: [
//                   BoxShadow(
//                     color: Colors.black26,
//                     blurRadius: 6,
//                     offset: Offset(0, 3),
//                   ),
//                 ],
//               ),
//               child: Column(
//                 children: [
//                   CircleAvatar(
//                     radius: 40,
//                     child: Text(
//                       _avatarLetter!,
//                       style: const TextStyle(
//                         fontSize: 30,
//                         fontWeight: FontWeight.bold,
//                         color: Colors.white,
//                       ),
//                     ),
//                     backgroundColor: Colors.blueAccent,
//                   ),
//                   const SizedBox(height: 10),
//                   Text(
//                     _name ?? 'Welcome!',
//                     style: const TextStyle(color: Colors.white, fontSize: 18, fontWeight: FontWeight.bold),
//                   ),
//                   Text(
//                     _email ?? 'Your Documents Hub',
//                     style: const TextStyle(color: Colors.white70, fontSize: 14),
//                   ),
//                 ],
//               ),
//             ),
//             const SizedBox(height: 10),
//             Expanded(
//               child: ListView(
//                 children: [
//                   _buildTile(
//                     icon: Icons.medical_services,
//                     title: 'Text Extractor',
//                     page: TextExtractorScreen(),
//                   ),
//                   _buildTile(
//                     icon: Icons.folder_shared,
//                     title: 'Saved Documents',
//                     page: ProtectedSavedDocumentsScreen(),
//                   ),
//                   _buildTile(
//                     icon: Icons.settings,
//                     title: 'Settings',
//                     page: SettingsScreen(),
//                   ),
//                   const Divider(color: Colors.white38, indent: 16, endIndent: 16),
//                   _buildTile(
//                     icon: Icons.logout,
//                     title: 'Sign Out',
//                     onTap: () async {
//                       await FirebaseAuth.instance.signOut();
//                       Navigator.of(context).pushAndRemoveUntil(
//                         MaterialPageRoute(
//                           builder: (context) => WelcomeScreen(),
//                         ),
//                         (route) => false,
//                       );
//                     },
//                   ),
//                 ],
//               ),
//             ),
//             const Padding(
//               padding: EdgeInsets.all(12.0),
//               child: Text(
//                 'Made for Doctors 🩺',
//                 style: TextStyle(color: Colors.white70, fontStyle: FontStyle.italic),
//               ),
//             ),
//           ],
//         ),
//       ),
//     );
//   }

//   Widget _buildTile({required IconData icon, required String title, Widget? page, VoidCallback? onTap}) {
//     return ListTile(
//       leading: Icon(icon, color: Colors.white),
//       title: Text(
//         title,
//         style: const TextStyle(color: Colors.white, fontSize: 16, fontWeight: FontWeight.w500),
//       ),
//       hoverColor: Colors.white24,
//       onTap: onTap ?? () {
//         Navigator.pop(context);
//         Navigator.pushReplacement(context, MaterialPageRoute(builder: (context) => page!));
//       },
//     );
//   }
// }


import 'package:flutter/material.dart';
import 'package:hive/hive.dart';
import 'package:firebase_auth/firebase_auth.dart';
import '../models/text_model.dart';
import '../screens/protected_saved_documents_screen.dart';
import '../screens/settings_screens.dart';
import '../screens/text_extractor_screen.dart';
import '../screens/welcome_screen.dart';
import 'package:shared_preferences/shared_preferences.dart';

class Sidebar extends StatefulWidget {
  final Box<TextModel>? box;

  const Sidebar({Key? key, required this.box}) : super(key: key);

  @override
  State<Sidebar> createState() => _SidebarState();
}

class _SidebarState extends State<Sidebar> {
  String? _email;
  String? _name;

  @override
  void initState() {
    super.initState();
    _loadUserInfo();
  }

  Future<void> _loadUserInfo() async {
    final prefs = await SharedPreferences.getInstance();
    setState(() {
      _email = prefs.getString('email') ?? 'Your Documents Hub';
      _name = prefs.getString('name') ?? 'Welcome!';
    });

    // Debugging: Ensure correct data is being loaded
    print("Loaded Email: $_email");
    print("Loaded Name: $_name");
  }

  @override
  Widget build(BuildContext context) {
    return Drawer(
      child: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            colors: [Color(0xFF0D47A1), Color(0xFF1976D2)],
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
          ),
        ),
        child: Column(
          children: [
            Container(
              padding: const EdgeInsets.only(top: 40, bottom: 20),
              width: double.infinity,
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: [Colors.blue.shade900, Colors.blueAccent],
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                ),
                boxShadow: [
                  BoxShadow(
                    color: Colors.black26,
                    blurRadius: 6,
                    offset: Offset(0, 3),
                  ),
                ],
              ),
              child: Column(
                children: [
                  CircleAvatar(
                    radius: 40,
                    backgroundImage: const AssetImage("assets/default_avatar.png"), // Default avatar
                  ),
                  const SizedBox(height: 10),
                  Text(
                    _name ?? 'Welcome!',
                    style: const TextStyle(color: Colors.white, fontSize: 18, fontWeight: FontWeight.bold),
                  ),
                  Text(
                    _email ?? 'Your Documents Hub',
                    style: const TextStyle(color: Colors.white70, fontSize: 14),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 10),
            Expanded(
              child: ListView(
                children: [
                  _buildTile(
                    icon: Icons.medical_services,
                    title: 'Text Extractor',
                    page: TextExtractorScreen(box: widget.box!),
                  ),
                  _buildTile(
                    icon: Icons.folder_shared,
                    title: 'Saved Documents',
                    page: ProtectedSavedDocumentsScreen(box: widget.box!),
                  ),
                  _buildTile(
                    icon: Icons.settings,
                    title: 'Settings',
                    page: SettingsScreen(box: widget.box!),
                  ),
                  const Divider(color: Colors.white38, indent: 16, endIndent: 16),
                  _buildTile(
                    icon: Icons.logout,
                    title: 'Sign Out',
                    onTap: () async {
                      await FirebaseAuth.instance.signOut();
                      Navigator.of(context).pushAndRemoveUntil(
                        MaterialPageRoute(
                          builder: (context) => WelcomeScreen(box: widget.box!),
                        ),
                        (route) => false,
                      );
                    },
                  ),
                ],
              ),
            ),
            const Padding(
              padding: EdgeInsets.all(12.0),
              child: Text(
                'Made for Doctors 🩺',
                style: TextStyle(color: Colors.white70, fontStyle: FontStyle.italic),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildTile({
    required IconData icon,
    required String title,
    Widget? page,
    VoidCallback? onTap,
  }) {
    return ListTile(
      leading: Icon(icon, color: Colors.white),
      title: Text(
        title,
        style: const TextStyle(color: Colors.white, fontSize: 16, fontWeight: FontWeight.w500),
      ),
      hoverColor: Colors.white24,
      onTap: onTap ??
          () {
            Navigator.pop(context);
            Navigator.pushReplacement(
              context,
              MaterialPageRoute(builder: (context) => page!),
            );
          },
    );
  }
}

// import 'package:flutter/material.dart';
// import 'package:hive/hive.dart';
// import 'package:http/http.dart' as http;
// import 'dart:convert';
// import '../models/text_model.dart';
// import '../services/api_service.dart';
// import '../services/password_service.dart';
// import '../screens/text_extractor_screen.dart';
// import '../screens/saved_documents_screen.dart';
// import '../screens/settings_screens.dart';


// class SavedDocumentsScreen extends StatefulWidget {
//   final Box<TextModel> box;
//   const SavedDocumentsScreen({Key? key, required this.box}) : super(key: key);

//   @override
//   _SavedDocumentsScreenState createState() => _SavedDocumentsScreenState();
// }

// class _SavedDocumentsScreenState extends State<SavedDocumentsScreen> {
//   List<TextModel> _texts = [];
//   List<TextModel> _filteredTexts = [];
//   late TextEditingController _searchController;

//   @override
//   void initState() {
//     super.initState();
//     _searchController = TextEditingController();
//     _verifyPasswordAndLoad();  // Ensure password check on every load
//   }

//   Future<void> _verifyPasswordAndLoad() async {
//     final savedPassword = await PasswordService.getPassword();
//     print("Password fetched during verification: $savedPassword");
//     if (savedPassword == null || savedPassword.isEmpty) {
//       _loadTextsFromServer();  // No password set, load documents directly
//       return;
//     }

//     final controller = TextEditingController();
//     bool verified = false;

//     // Show password dialog every time the user tries to access saved documents
//     await showDialog(
//       barrierDismissible: false, // Prevent dismissing by tapping outside
//       context: context,
//       builder: (context) {
//         return AlertDialog(
//           title: const Text('Enter Password'),
//           content: TextField(
//             controller: controller,
//             obscureText: true,
//             decoration: const InputDecoration(hintText: 'App password'),
//           ),
//           actions: [
//             TextButton(
//               onPressed: () => Navigator.pop(context),
//               child: const Text('Cancel'),
//             ),
//             ElevatedButton(
//               onPressed: () {
//                 if (controller.text.trim() == savedPassword) {
//                   verified = true;
//                   Navigator.pop(context); // Close the dialog if password is correct
//                 } else {
//                   ScaffoldMessenger.of(context).showSnackBar(
//                     const SnackBar(content: Text('Incorrect password')),
//                   );
//                 }
//               },
//               child: const Text('Submit'),
//             ),
//           ],
//         );
//       },
//     );

//     if (verified) {
//       _loadTextsFromServer();  // Proceed to load documents if password is correct
//     } else {
//       Navigator.pop(context);  // Close screen if password is incorrect
//     }
//   }

//   Future<void> _loadTextsFromServer() async {
//     final response = await http.get(Uri.parse(ApiService.getSavedTextsUrl()));

//     if (response.statusCode == 200) {
//       final List<dynamic> data = json.decode(response.body);
//       setState(() {
//         _texts = data.map((json) => TextModel.fromJson(json)).toList();
//         _filteredTexts = _texts;
//       });
//     } else {
//       ScaffoldMessenger.of(context).showSnackBar(
//         const SnackBar(content: Text('Failed to load texts')),
//       );
//     }
//   }

//   void _searchDocuments(String query) {
//     final filtered = _texts.where((text) {
//       final titleLower = text.name.toLowerCase();
//       final queryLower = query.toLowerCase();
//       return titleLower.contains(queryLower);
//     }).toList();

//     setState(() {
//       _filteredTexts = filtered;
//     });
//   }

//   @override
//   void dispose() {
//     _searchController.dispose();
//     super.dispose();
//   }

//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       // Use the original Sidebar widget here for the drawer
//       drawer: Sidebar(box: widget.box),  // Add Sidebar widget here as the drawer
//       appBar: AppBar(title: const Text('Saved Documents')),
//       body: Padding(
//         padding: const EdgeInsets.all(16.0),
//         child: Column(
//           children: [
//             TextField(
//               controller: _searchController,
//               onChanged: _searchDocuments,
//               decoration: const InputDecoration(
//                 labelText: 'Search documents...',
//                 border: OutlineInputBorder(),
//               ),
//             ),
//             const SizedBox(height: 20),
//             Expanded(
//               child: _filteredTexts.isEmpty
//                   ? const Center(child: Text('No documents found.'))
//                   : ListView.builder(
//                       itemCount: _filteredTexts.length,
//                       itemBuilder: (context, index) {
//                         final text = _filteredTexts[index];
//                         return Card(
//                           child: ListTile(
//                             title: Text(text.name),
//                             subtitle: Text(
//                               text.content.length > 100
//                                   ? '${text.content.substring(0, 100)}...'
//                                   : text.content,
//                             ),
//                           ),
//                         );
//                       },
//                     ),
//             ),
//           ],
//         ),
//       ),
//     );
//   }
// }

// import 'dart:convert';
// import 'dart:typed_data';
// import 'dart:io';
// import 'dart:html' as html;

// import 'package:flutter/foundation.dart' show kIsWeb;
// import 'package:flutter/material.dart';
// import 'package:flutter/services.dart';
// import 'package:image_picker/image_picker.dart';
// import 'package:http/http.dart' as http;
// import 'package:hive/hive.dart';
// import 'package:pdf/pdf.dart';
// import 'package:pdf/widgets.dart' as pw;
// import 'package:path_provider/path_provider.dart';
// import 'package:open_file/open_file.dart';
// import 'package:share_plus/share_plus.dart';


// import '../models/text_model.dart';
// import '../widgets/sidebar.dart';

// class TextExtractorScreen extends StatefulWidget {
//   final Box<TextModel> box;

//   const TextExtractorScreen({super.key, required this.box});

//   @override
//   _TextExtractorScreenState createState() => _TextExtractorScreenState();
// }

// class _TextExtractorScreenState extends State<TextExtractorScreen> {
//   XFile? _image;
//   String _extractedText = "";
//   String _statusMessage = "";
//   final picker = ImagePicker();

//   Future<void> _getImage(ImageSource source) async {
//     try {
//       debugPrint('Picking image from $source...');
//       final pickedFile = await picker.pickImage(source: source);
//       debugPrint('Picked file: ${pickedFile?.path}');

//       if (pickedFile != null) {
//         setState(() {
//           _image = pickedFile;
//           _extractedText = "";
//           _statusMessage = "Image selected, uploading...";
//         });
//         await _uploadImage(pickedFile);
//       } else {
//         setState(() {
//           _statusMessage = "No image selected.";
//         });
//         debugPrint('No image selected');
//       }
//     } catch (e, stackTrace) {
//       setState(() {
//         _statusMessage = "Picker error: $e";
//       });
//       debugPrint('Picker error: $e');
//       debugPrint('Stack trace: $stackTrace');
//     }
//   }

//   Future<void> _uploadImage(XFile image) async {
//     try {
//       debugPrint('Uploading image: ${image.path}');
//       final uri = Uri.parse('http://localhost:3000/api/extract-text');
//       debugPrint('POST to: $uri');
//       var request = http.MultipartRequest('POST', uri);

//       if (kIsWeb) {
//         final bytes = await image.readAsBytes();
//         debugPrint('Image bytes length: ${bytes.length}');
//         request.files.add(http.MultipartFile.fromBytes(
//           'image',
//           bytes,
//           filename: image.name,
//         ));
//       } else {
//         request.files
//             .add(await http.MultipartFile.fromPath('image', image.path));
//         debugPrint('Image file path: ${image.path}');
//       }

//       final response = await request.send();
//       debugPrint('Response status: ${response.statusCode}');
//       final responseBody = await response.stream.bytesToString();
//       debugPrint('Response body (raw): $responseBody');

//       if (response.statusCode == 200) {
//         try {
//           final data = jsonDecode(responseBody) as Map<String, dynamic>? ?? {};
//           final extracted =
//               data['extractedText']?.toString() ?? 'No text extracted.';
//           debugPrint('Parsed extractedText: $extracted');

//           setState(() {
//             _extractedText = extracted;
//             _statusMessage = "Text extracted successfully!";
//           });

//           // Save to Hive with numbered name
//           debugPrint('Saving to Hive, box size before: ${widget.box.length}');
//           final newName = 'Document ${widget.box.length + 1}';
//           final newText = TextModel(
//             name: newName,
//             content: _extractedText,
//             dateTime: DateTime.now(),
//           );
//           await widget.box.add(newText);
//           await widget.box.flush();
//           await widget.box.compact();
//           debugPrint(
//               'Saved: name=${newText.name}, content=${newText.content}, date=${newText.dateTime}');
//           debugPrint('Box size after save: ${widget.box.length}');
//           debugPrint(
//               'Last item: ${widget.box.getAt(widget.box.length - 1)?.name}');
//         } catch (e, stackTrace) {
//           setState(() {
//             _extractedText = "";
//             _statusMessage =
//                 "Parse or save error: $e (Response: $responseBody)";
//           });
//           debugPrint('Parse or save error: $e');
//           debugPrint('Stack trace: $stackTrace');
//           debugPrint('Raw response causing error: $responseBody');
//         }
//       } else {
//         setState(() {
//           _extractedText = "";
//           _statusMessage =
//               'Upload failed (Status: ${response.statusCode}, Body: $responseBody)';
//         });
//         debugPrint(
//             'Upload failed: ${response.statusCode}, Body: $responseBody');
//       }
//     } catch (e, stackTrace) {
//       setState(() {
//         _extractedText = "";
//         _statusMessage = 'Upload error: $e';
//       });
//       debugPrint('Upload error: $e');
//       debugPrint('Stack trace: $stackTrace');
//     }
//   }

//   Future<void> _generatePDF() async {
//     if (_extractedText.isEmpty) {
//       setState(() {
//         _statusMessage = "No text to convert to PDF.";
//       });
//       return;
//     }

//     try {
//       // Create a PDF document
//       final pdf = pw.Document();
//       pdf.addPage(
//         pw.Page(
//           build: (pw.Context context) => pw.Center(
//             child: pw.Text(
//               _extractedText,
//               style: pw.TextStyle(fontSize: 12),
//             ),
//           ),
//         ),
//       );

//       final pdfBytes = await pdf.save();
//       final fileName =
//           'Extracted_Text_${DateTime.now().millisecondsSinceEpoch}.pdf';
//       await _showPDFOptions(pdfBytes, fileName);
//     } catch (e, stackTrace) {
//       setState(() {
//         _statusMessage = "PDF generation error: $e";
//       });
//       debugPrint('PDF generation error: $e');
//       debugPrint('Stack trace: $stackTrace');
//     }
//   }

//   Future<void> _showPDFOptions(Uint8List pdfBytes, String fileName) async {
//     if (kIsWeb) {
//       final blob = html.Blob([pdfBytes]);
//       final url = html.Url.createObjectUrlFromBlob(blob);
//       final anchor = html.AnchorElement(href: url)
//         ..setAttribute("download", fileName)
//         ..click();
//       html.Url.revokeObjectUrl(url);
//       setState(() {
//         _statusMessage = "PDF downloaded successfully!";
//       });
//     } else 
//     {

//       showDialog(
//         context: context,
//         builder: (context) => AlertDialog(
//           title: const Text('PDF Options'),
//           content: SingleChildScrollView(
//             child: ListBody(
//               children: <Widget>[
//                 ElevatedButton(
//                   onPressed: () async {
//                     Navigator.pop(context);
//                     final directory = await getApplicationDocumentsDirectory();
//                     final file = File('${directory.path}/$fileName');
//                     await file.writeAsBytes(pdfBytes);
//                     setState(() {
//                       _statusMessage = "PDF saved to ${file.path}";
//                     });
//                     await OpenFile.open(file.path);
//                   },
//                   child: const Text('Download and Open'),
//                 ),
//                 ElevatedButton(
//                   onPressed: () async {
//                     Navigator.pop(context);
//                     final directory = await getApplicationDocumentsDirectory();
//                     final file = File('${directory.path}/$fileName');
//                     await file.writeAsBytes(pdfBytes);
//                     await Share.shareFiles(['${file.path}'],
//                         text: 'Extracted Text PDF');
//                     setState(() {
//                       _statusMessage = "PDF shared successfully!";
//                     });
//                   },
//                   child: const Text('Share'),
//                 ),
//                 ElevatedButton(
//                   onPressed: () async {
//                     Navigator.pop(context);
//                     final editedText = await _editPDFContent(_extractedText);
//                     if (editedText != null) {
//                       final updatedPdf = pw.Document();
//                       updatedPdf.addPage(
//                         pw.Page(
//                           build: (pw.Context context) => pw.Column(
//                             children: [
//                               pw.Text('Edited Document',
//                                   style: pw.TextStyle(
//                                       fontSize: 16,
//                                       fontWeight: pw.FontWeight.bold)),
//                               pw.Text(editedText,
//                                   style: pw.TextStyle(fontSize: 12)),
//                             ],
//                           ),
//                         ),
//                       );
//                       final updatedPdfBytes = await updatedPdf.save();
//                       final updatedFile = File(
//                           '${(await getApplicationDocumentsDirectory()).path}/$fileName');
//                       await updatedFile.writeAsBytes(updatedPdfBytes);
//                       setState(() {
//                         _extractedText = editedText;
//                         _statusMessage =
//                             "PDF edited and saved to ${updatedFile.path}";
//                       });
//                       await OpenFile.open(updatedFile.path);
//                     }
//                   },
//                   child: const Text('Edit'),
//                 ),
//               ],
//             ),
//           ),
//         ),
//       );
//     }
//   }

//   Future<String?> _editPDFContent(String currentText) async {
//     String? editedText = currentText;
//     await showDialog(
//       context: context,
//       builder: (context) => AlertDialog(
//         title: const Text('Edit PDF Content'),
//         content: TextField(
//           maxLines: 5,
//           controller: TextEditingController(text: currentText),
//           onChanged: (value) => editedText = value,
//           decoration: const InputDecoration(hintText: 'Edit the text here'),
//         ),
//         actions: [
//           TextButton(
//             onPressed: () => Navigator.pop(context),
//             child: const Text('Cancel'),
//           ),
//           TextButton(
//             onPressed: () {
//               Navigator.pop(context, editedText);
//             },
//             child: const Text('Save'),
//           ),
//         ],
//       ),
//     );
//     return editedText;
//   }

//   @override
//   Widget build(BuildContext context) {
//     debugPrint(
//         'TextExtractorScreen build, box: $widget.box, size: ${widget.box.length}');
//     return Scaffold(
//       drawer: Sidebar(box: widget.box),
//       appBar: AppBar(
//         title: const Text('Text Extractor'),
//         leading: Builder(
//           builder: (context) => IconButton(
//             icon: const Icon(Icons.menu),
//             onPressed: () => Scaffold.of(context).openDrawer(),
//           ),
//         ),
//       ),
//       body: Center(
//         child: SingleChildScrollView(
//           child: Column(
//             mainAxisAlignment: MainAxisAlignment.center,
//             children: [
//               Row(
//                 mainAxisAlignment: MainAxisAlignment.center,
//                 children: [
//                   ElevatedButton(
//                     onPressed: () => _getImage(ImageSource.gallery),
//                     child: const Text('Pick an Image'),
//                   ),
//                   const SizedBox(width: 20),
//                   if (!kIsWeb)
//                     ElevatedButton(
//                       onPressed: () => _getImage(ImageSource.camera),
//                       child: const Text('Capture Image'),
//                     ),
//                 ],
//               ),
//               const SizedBox(height: 20),
//               ElevatedButton(
//                 onPressed: _extractedText.isEmpty ? null : _generatePDF,
//                 child: const Text('Convert to PDF'),
//               ),
//               const SizedBox(height: 20),
//               Text(
//                 _statusMessage,
//                 style: const TextStyle(fontSize: 16, color: Colors.blue),
//               ),
//               const SizedBox(height: 20),
//               Container(
//                 width: MediaQuery.of(context).size.width * 0.8,
//                 padding: const EdgeInsets.all(16),
//                 decoration: BoxDecoration(
//                   border: Border.all(color: Colors.grey),
//                   borderRadius: BorderRadius.circular(10),
//                 ),
//                 child: Column(
//                   children: [
//                     _image != null
//                         ? kIsWeb
//                             ? Image.network(
//                                 _image!.path,
//                                 height: 200,
//                                 width: 200,
//                                 fit: BoxFit.contain,
//                                 errorBuilder: (context, error, stackTrace) =>
//                                     const Text('Error loading image'),
//                               )
//                             : FutureBuilder<Uint8List>(
//                                 future: _image!.readAsBytes(),
//                                 builder: (context, snapshot) {
//                                   if (snapshot.connectionState ==
//                                           ConnectionState.done &&
//                                       snapshot.hasData) {
//                                     return Image.memory(
//                                       snapshot.data!,
//                                       height: 200,
//                                       width: 200,
//                                       fit: BoxFit.contain,
//                                       errorBuilder:
//                                           (context, error, stackTrace) =>
//                                               const Text('Error loading image'),
//                                     );
//                                   } else if (snapshot.hasError) {
//                                     return const Text('Error loading image');
//                                   }
//                                   return const CircularProgressIndicator();
//                                 },
//                               )
//                         : const Text('No image selected'),
//                     const SizedBox(height: 20),
//                     Text(
//                       _extractedText.isEmpty
//                           ? 'No text extracted yet.'
//                           : _extractedText,
//                       style: const TextStyle(fontSize: 16),
//                       textAlign: TextAlign.center,
//                     ),
//                   ],
//                 ),
//               ),
//             ],
//           ),
//         ),
//       ),
//     );
//   }
// }


// import 'dart:convert';
// import 'dart:typed_data';
// import 'dart:io';
// import 'dart:html' as html;

// import 'package:flutter/foundation.dart' show kIsWeb;
// import 'package:flutter/material.dart';
// import 'package:flutter/services.dart';
// import 'package:image_picker/image_picker.dart';
// import 'package:http/http.dart' as http;
// import 'package:hive/hive.dart';
// import 'package:pdf/pdf.dart';
// import 'package:pdf/widgets.dart' as pw;
// import 'package:path_provider/path_provider.dart';
// import 'package:open_filex/open_filex.dart';
// import 'package:share_plus/share_plus.dart';
// import '../widgets/vertical_tab_sidebar.dart'; // Add this at the top
// import '../models/text_model.dart';
// //import '../widgets/sidebar.dart';

// class TextExtractorScreen extends StatefulWidget {
//   final Box<TextModel> box;

//   const TextExtractorScreen({super.key, required this.box});

//   @override
//   _TextExtractorScreenState createState() => _TextExtractorScreenState();
// }

// class _TextExtractorScreenState extends State<TextExtractorScreen> {
//   XFile? _image;
//   String _extractedText = "";
//   String _statusMessage = "";
//   final picker = ImagePicker();

//   Future<void> _getImage(ImageSource source) async {
//     try {
//       debugPrint('Picking image from $source...');
//       final pickedFile = await picker.pickImage(source: source);
//       debugPrint('Picked file: ${pickedFile?.path}');

//       if (pickedFile != null) {
//         setState(() {
//           _image = pickedFile;
//           _extractedText = "";
//           _statusMessage = "Image selected, uploading...";
//         });
//         await _uploadImage(pickedFile);
//       } else {
//         setState(() {
//           _statusMessage = "No image selected.";
//         });
//         debugPrint('No image selected');
//       }
//     } catch (e, stackTrace) {
//       setState(() {
//         _statusMessage = "Picker error: $e";
//       });
//       debugPrint('Picker error: $e');
//       debugPrint('Stack trace: $stackTrace');
//     }
//   }

//   Future<void> _uploadImage(XFile image) async {
//     try {
//       debugPrint('Uploading image: ${image.path}');
//       final uri = Uri.parse('http://localhost:3000/api/extract-text');
//       debugPrint('POST to: $uri');
//       var request = http.MultipartRequest('POST', uri);

//       if (kIsWeb) {
//         final bytes = await image.readAsBytes();
//         debugPrint('Image bytes length: ${bytes.length}');
//         request.files.add(http.MultipartFile.fromBytes(
//           'image',
//           bytes,
//           filename: image.name,
//         ));
//       } else {
//         request.files
//             .add(await http.MultipartFile.fromPath('image', image.path));
//         debugPrint('Image file path: ${image.path}');
//       }

//       final response = await request.send();
//       debugPrint('Response status: ${response.statusCode}');
//       final responseBody = await response.stream.bytesToString();
//       debugPrint('Response body (raw): $responseBody');

//       if (response.statusCode == 200) {
//         try {
//           final data = jsonDecode(responseBody) as Map<String, dynamic>? ?? {};
//           final extracted =
//               data['extractedText']?.toString() ?? 'No text extracted.';
//           debugPrint('Parsed extractedText: $extracted');

//           setState(() {
//             _extractedText = extracted;
//             _statusMessage = "Text extracted successfully!";
//           });

//           // Save to Hive with numbered name
//           debugPrint('Saving to Hive, box size before: ${widget.box.length}');
//           final newName = 'Document ${widget.box.length + 1}';
//           final newText = TextModel(
//             name: newName,
//             content: _extractedText,
//             dateTime: DateTime.now(),
//           );
//           await widget.box.add(newText);
//           await widget.box.flush();
//           await widget.box.compact();
//           debugPrint(
//               'Saved: name=${newText.name}, content=${newText.content}, date=${newText.dateTime}');
//           debugPrint('Box size after save: ${widget.box.length}');
//           debugPrint(
//               'Last item: ${widget.box.getAt(widget.box.length - 1)?.name}');
//         } catch (e, stackTrace) {
//           setState(() {
//             _extractedText = "";
//             _statusMessage =
//                 "Parse or save error: $e (Response: $responseBody)";
//           });
//           debugPrint('Parse or save error: $e');
//           debugPrint('Stack trace: $stackTrace');
//           debugPrint('Raw response causing error: $responseBody');
//         }
//       } else {
//         setState(() {
//           _extractedText = "";
//           _statusMessage =
//               'Upload failed (Status: ${response.statusCode}, Body: $responseBody)';
//         });
//         debugPrint(
//             'Upload failed: ${response.statusCode}, Body: $responseBody');
//       }
//     } catch (e, stackTrace) {
//       setState(() {
//         _extractedText = "";
//         _statusMessage = 'Upload error: $e';
//       });
//       debugPrint('Upload error: $e');
//       debugPrint('Stack trace: $stackTrace');
//     }
//   }

//   Future<void> _generatePDF() async {
//     if (_extractedText.isEmpty) {
//       setState(() {
//         _statusMessage = "No text to convert to PDF.";
//       });
//       return;
//     }

//     try {
//       // Create a PDF document
//       final pdf = pw.Document();
//       pdf.addPage(
//         pw.Page(
//           build: (pw.Context context) => pw.Center(
//             child: pw.Text(
//               _extractedText,
//               style: pw.TextStyle(fontSize: 12),
//             ),
//           ),
//         ),
//       );

//       final pdfBytes = await pdf.save();
//       final fileName =
//           'Extracted_Text_${DateTime.now().millisecondsSinceEpoch}.pdf';
//       await _showPDFOptions(pdfBytes, fileName);
//     } catch (e, stackTrace) {
//       setState(() {
//         _statusMessage = "PDF generation error: $e";
//       });
//       debugPrint('PDF generation error: $e');
//       debugPrint('Stack trace: $stackTrace');
//     }
//   }
//   Future<void> _showPDFOptions(Uint8List pdfBytes, String fileName) async {
//   if (kIsWeb) {
//     final blob = html.Blob([pdfBytes]);
//     final url = html.Url.createObjectUrlFromBlob(blob);
//     final anchor = html.AnchorElement(href: url)
//       ..setAttribute("download", fileName)
//       ..click();
//     html.Url.revokeObjectUrl(url);
//     setState(() {
//       _statusMessage = "PDF downloaded successfully!";
//     });
//   } else {
//     showDialog(
//       context: context,
//       builder: (context) => AlertDialog(
//         title: const Text('PDF Options'),
//         content: SingleChildScrollView(
//           child: ListBody(
//             children: <Widget>[
//               ElevatedButton(
//                 onPressed: () async {
//                   Navigator.pop(context);
//                   final directory = await getApplicationDocumentsDirectory();
//                   final file = File('${directory.path}/$fileName');
//                   await file.writeAsBytes(pdfBytes);
//                   setState(() {
//                     _statusMessage = "PDF saved to ${file.path}";
//                   });
//                   await OpenFilex.open(file.path);
//                 },
//                 child: const Text('Download and Open'),
//               ),
//               ElevatedButton(
//                 onPressed: () async {
//                   Navigator.pop(context);
//                   final directory = await getApplicationDocumentsDirectory();
//                   final file = File('${directory.path}/$fileName');
//                   await file.writeAsBytes(pdfBytes);

//                   await Share.shareXFiles(
//                     [XFile(file.path)],
//                     text: 'Extracted Text PDF',
//                   );

//                   setState(() {
//                     _statusMessage = "PDF shared successfully!";
//                   });
//                 },
//                 child: const Text('Share'),
//               ),
//               ElevatedButton(
//                 onPressed: () async {
//                   Navigator.pop(context);
//                   final editedText = await _editPDFContent(_extractedText);
//                   if (editedText != null) {
//                     final updatedPdf = pw.Document();
//                     updatedPdf.addPage(
//                       pw.Page(
//                         build: (pw.Context context) => pw.Column(
//                           children: [
//                             pw.Text('Edited Document',
//                                 style: pw.TextStyle(
//                                     fontSize: 16,
//                                     fontWeight: pw.FontWeight.bold)),
//                             pw.Text(editedText,
//                                 style: pw.TextStyle(fontSize: 12)),
//                           ],
//                         ),
//                       ),
//                     );
//                     final updatedPdfBytes = await updatedPdf.save();
//                     final updatedFile = File(
//                       '${(await getApplicationDocumentsDirectory()).path}/$fileName',
//                     );
//                     await updatedFile.writeAsBytes(updatedPdfBytes);
//                     setState(() {
//                       _extractedText = editedText;
//                       _statusMessage =
//                           "PDF edited and saved to ${updatedFile.path}";
//                     });
//                     await OpenFilex.open(updatedFile.path);
//                   }
//                 },
//                 child: const Text('Edit'),
//               ),
//             ],
//           ),
//         ),
//       ),
//     );
//   }
// }



//   Future<String?> _editPDFContent(String currentText) async {
//     String? editedText = currentText;
//     await showDialog(
//       context: context,
//       builder: (context) => AlertDialog(
//         title: const Text('Edit PDF Content'),
//         content: TextField(
//           maxLines: 5,
//           controller: TextEditingController(text: currentText),
//           onChanged: (value) => editedText = value,
//           decoration: const InputDecoration(hintText: 'Edit the text here'),
//         ),
//         actions: [
//           TextButton(
//             onPressed: () => Navigator.pop(context),
//             child: const Text('Cancel'),
//           ),
//           TextButton(
//             onPressed: () {
//               Navigator.pop(context, editedText);
//             },
//             child: const Text('Save'),
//           ),
//         ],
//       ),
//     );
//     return editedText;
//   }

//   @override
//   Widget build(BuildContext context) {
//     debugPrint('TextExtractorScreen build, box: $widget.box, size: ${widget.box.length}');
//     return Scaffold(
//       body: VerticalTabSidebar(box: widget.box),
//       appBar: AppBar(
//         title: const Text('MediScan - Text Extractor', style: TextStyle(fontWeight: FontWeight.bold)),
//         leading: Builder(
//           builder: (context) => IconButton(
//             icon: const Icon(Icons.menu),
//             onPressed: () => Scaffold.of(context).openDrawer(),
//           ),
//         ),
//         backgroundColor: Colors.blue.shade700,
//       ),
//       body: Container(
//         padding: const EdgeInsets.all(20),
//         color: Colors.grey.shade100,
//         child: Center(
//           child: SingleChildScrollView(
//             child: Column(
//               mainAxisAlignment: MainAxisAlignment.center,
//               children: [
//                 Card(
//                   elevation: 4,
//                   shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
//                   child: Padding(
//                     padding: const EdgeInsets.symmetric(vertical: 20, horizontal: 20),
//                     child: Column(
//                       children: [
//                         const Text(
//                           "Upload Prescription Image",
//                           style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
//                         ),
//                         const SizedBox(height: 20),
//                         Row(
//                           mainAxisAlignment: MainAxisAlignment.spaceEvenly,
//                           children: [
//                             ElevatedButton.icon(
//                               onPressed: () => _getImage(ImageSource.gallery),
//                               icon: const Icon(Icons.photo_library),
//                               label: const Text('Gallery'),
//                               style: ElevatedButton.styleFrom(
//                                 backgroundColor: Colors.blueAccent,
//                                 shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
//                                 padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 12),
//                               ),
//                             ),
//                             if (!kIsWeb)
//                               ElevatedButton.icon(
//                                 onPressed: () => _getImage(ImageSource.camera),
//                                 icon: const Icon(Icons.camera_alt),
//                                 label: const Text('Camera'),
//                                 style: ElevatedButton.styleFrom(
//                                   backgroundColor: Colors.green,
//                                   shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
//                                   padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 12),
//                                 ),
//                               ),
//                           ],
//                         ),
//                         const SizedBox(height: 20),
//                         AnimatedSwitcher(
//                           duration: const Duration(milliseconds: 500),
//                           child: _image != null
//                               ? ClipRRect(
//                                   borderRadius: BorderRadius.circular(12),
//                                   child: kIsWeb
//                                       ? Image.network(_image!.path, height: 200, width: 200, fit: BoxFit.cover)
//                                       : FutureBuilder<Uint8List>(
//                                           future: _image!.readAsBytes(),
//                                           builder: (context, snapshot) {
//                                             if (snapshot.connectionState == ConnectionState.done && snapshot.hasData) {
//                                               return Image.memory(snapshot.data!, height: 200, width: 200, fit: BoxFit.cover);
//                                             } else if (snapshot.hasError) {
//                                               return const Text('Error loading image');
//                                             }
//                                             return const CircularProgressIndicator();
//                                           },
//                                         ),
//                                 )
//                               : const Text(
//                                   "No Image Selected",
//                                   style: TextStyle(fontSize: 16, color: Colors.grey),
//                                 ),
//                         ),
//                       ],
//                     ),
//                   ),
//                 ),
//                 const SizedBox(height: 30),
//                 Card(
//                   elevation: 4,
//                   shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
//                   child: Padding(
//                     padding: const EdgeInsets.all(20),
//                     child: Column(
//                       children: [
//                         const Text(
//                           "Extracted Text",
//                           style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
//                         ),
//                         const SizedBox(height: 20),
//                         Container(
//                           width: double.infinity,
//                           padding: const EdgeInsets.all(16),
//                           decoration: BoxDecoration(
//                             color: Colors.white,
//                             borderRadius: BorderRadius.circular(12),
//                             border: Border.all(color: Colors.grey.shade300),
//                           ),
//                           child: Text(
//                             _extractedText.isEmpty ? "No text extracted yet." : _extractedText,
//                             style: const TextStyle(fontSize: 16),
//                             textAlign: TextAlign.start,
//                           ),
//                         ),
//                         const SizedBox(height: 20),
//                         ElevatedButton.icon(
//                           onPressed: _extractedText.isEmpty ? null : _generatePDF,
//                           icon: const Icon(Icons.picture_as_pdf),
//                           label: const Text('Generate PDF'),
//                           style: ElevatedButton.styleFrom(
//                             backgroundColor: Colors.deepPurple,
//                             shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
//                             padding: const EdgeInsets.symmetric(horizontal: 30, vertical: 14),
//                           ),
//                         ),
//                       ],
//                     ),
//                   ),
//                 ),
//                 const SizedBox(height: 20),
//                 if (_statusMessage.isNotEmpty)
//                   Padding(
//                     padding: const EdgeInsets.symmetric(vertical: 8),
//                     child: Text(
//                       _statusMessage,
//                       style: const TextStyle(fontSize: 16, color: Colors.blue),
//                       textAlign: TextAlign.center,
//                     ),
//                   ),
//               ],
//             ),
//           ),
//         ),
//       ),
//     );
//   }
// }


// import 'dart:convert';
// import 'dart:typed_data';
// import 'dart:io';
// import 'dart:html' as html; // Web-specific import

// import 'package:flutter/foundation.dart' show kIsWeb;
// import 'package:flutter/material.dart';
// import 'package:flutter/services.dart';
// import 'package:image_picker/image_picker.dart';
// import 'package:http/http.dart' as http;
// import 'package:hive/hive.dart';
// import 'package:pdf/pdf.dart';
// import 'package:pdf/widgets.dart' as pw;
// import 'package:path_provider/path_provider.dart';
// import 'package:open_filex/open_filex.dart';
// import 'package:share_plus/share_plus.dart';
// import '../widgets/sidebar.dart'; // Vertical sidebar import
// import '../models/text_model.dart';

// class TextExtractorScreen extends StatefulWidget {
//   final Box<TextModel> box;

//   const TextExtractorScreen({super.key, required this.box});

//   @override
//   _TextExtractorScreenState createState() => _TextExtractorScreenState();
// }

// class _TextExtractorScreenState extends State<TextExtractorScreen> {
//   XFile? _image;
//   String _extractedText = "";
//   String _statusMessage = "";
//   final picker = ImagePicker();
//   final TextEditingController _editingController = TextEditingController(); // Reusable controller

//   Future<void> _getImage(ImageSource source) async {
//     try {
//       debugPrint('Picking image from $source...');
//       final pickedFile = await picker.pickImage(source: source);
//       debugPrint('Picked file: ${pickedFile?.path}');

//       if (pickedFile != null) {
//         setState(() {
//           _image = pickedFile;
//           _extractedText = "";
//           _statusMessage = "Image selected, uploading...";
//         });
//         await _uploadImage(pickedFile);
//       } else {
//         setState(() {
//           _statusMessage = "No image selected.";
//         });
//         debugPrint('No image selected');
//       }
//     } catch (e, stackTrace) {
//       setState(() {
//         _statusMessage = "Picker error: $e";
//       });
//       debugPrint('Picker error: $e');
//       debugPrint('Stack trace: $stackTrace');
//     }
//   }

//   Future<void> _uploadImage(XFile image) async {
//     try {
//       debugPrint('Uploading image: ${image.path}');
//       final uri = Uri.parse('http://localhost:3000/api/extract-text');
//       debugPrint('POST to: $uri');
//       var request = http.MultipartRequest('POST', uri);

//       if (kIsWeb) {
//         final bytes = await image.readAsBytes();
//         debugPrint('Image bytes length: ${bytes.length}');
//         request.files.add(http.MultipartFile.fromBytes(
//           'image',
//           bytes,
//           filename: image.name,
//         ));
//       } else {
//         request.files.add(await http.MultipartFile.fromPath('image', image.path));
//         debugPrint('Image file path: ${image.path}');
//       }

//       final response = await request.send();
//       debugPrint('Response status: ${response.statusCode}');
//       final responseBody = await response.stream.bytesToString();
//       debugPrint('Response body (raw): $responseBody');

//       if (response.statusCode == 200) {
//         try {
//           final data = jsonDecode(responseBody) as Map<String, dynamic>? ?? {};
//           final extracted = data['extractedText']?.toString() ?? 'No text extracted.';
//           debugPrint('Parsed extractedText: $extracted');

//           setState(() {
//             _extractedText = extracted;
//             _statusMessage = "Text extracted successfully!";
//           });

//           // Save to Hive with numbered name
//           debugPrint('Saving to Hive, box size before: ${widget.box.length}');
//           final newName = 'Document ${widget.box.length + 1}';
//           final newText = TextModel(
//             name: newName,
//             content: _extractedText,
//             dateTime: DateTime.now(),
//           );
//           await widget.box.add(newText);
//           await widget.box.flush();
//           await widget.box.compact();
//           debugPrint(
//               'Saved: name=${newText.name}, content=${newText.content}, date=${newText.dateTime}');
//           debugPrint('Box size after save: ${widget.box.length}');
//           debugPrint(
//               'Last item: ${widget.box.getAt(widget.box.length - 1)?.name}');
//         } catch (e, stackTrace) {
//           setState(() {
//             _extractedText = "";
//             _statusMessage =
//                 "Parse or save error: $e (Response: $responseBody)";
//           });
//           debugPrint('Parse or save error: $e');
//           debugPrint('Stack trace: $stackTrace');
//           debugPrint('Raw response causing error: $responseBody');
//         }
//       } else {
//         setState(() {
//           _extractedText = "";
//           _statusMessage =
//               'Upload failed (Status: ${response.statusCode}, Body: $responseBody)';
//         });
//         debugPrint(
//             'Upload failed: ${response.statusCode}, Body: $responseBody');
//       }
//     } catch (e, stackTrace) {
//       setState(() {
//         _extractedText = "";
//         _statusMessage = 'Upload error: $e';
//       });
//       debugPrint('Upload error: $e');
//       debugPrint('Stack trace: $stackTrace');
//     }
//   }

//   Future<void> _generatePDF() async {
//     if (_extractedText.isEmpty) {
//       setState(() {
//         _statusMessage = "No text to convert to PDF.";
//       });
//       return;
//     }

//     try {
//       // Create a PDF document
//       final pdf = pw.Document();
//       pdf.addPage(
//         pw.Page(
//           build: (pw.Context context) => pw.Center(
//             child: pw.Text(
//               _extractedText,
//               style: pw.TextStyle(fontSize: 12),
//             ),
//           ),
//         ),
//       );

//       final pdfBytes = await pdf.save();
//       final fileName =
//           'Extracted_Text_${DateTime.now().millisecondsSinceEpoch}.pdf';
//       await _showPDFOptions(pdfBytes, fileName);
//     } catch (e, stackTrace) {
//       setState(() {
//         _statusMessage = "PDF generation error: $e";
//       });
//       debugPrint('PDF generation error: $e');
//       debugPrint('Stack trace: $stackTrace');
//     }
//   }

//   Future<void> _showPDFOptions(Uint8List pdfBytes, String fileName) async {
//     if (kIsWeb) {
//       final blob = html.Blob([pdfBytes]);
//       final url = html.Url.createObjectUrlFromBlob(blob);
//       final anchor = html.AnchorElement(href: url)
//         ..setAttribute("download", fileName)
//         ..click();
//       html.Url.revokeObjectUrl(url);
//       setState(() {
//         _statusMessage = "PDF downloaded successfully!";
//       });
//     } else {
//       showDialog(
//         context: context,
//         builder: (context) => AlertDialog(
//           title: const Text('PDF Options'),
//           content: SingleChildScrollView(
//             child: ListBody(
//               children: <Widget>[
//                 ElevatedButton(
//                   onPressed: () async {
//                     Navigator.pop(context);
//                     final directory = await getApplicationDocumentsDirectory();
//                     final file = File('${directory.path}/$fileName');
//                     await file.writeAsBytes(pdfBytes);
//                     setState(() {
//                       _statusMessage = "PDF saved to ${file.path}";
//                     });
//                     await OpenFilex.open(file.path);
//                   },
//                   child: const Text('Download and Open'),
//                 ),
//                 ElevatedButton(
//                   onPressed: () async {
//                     Navigator.pop(context);
//                     final directory = await getApplicationDocumentsDirectory();
//                     final file = File('${directory.path}/$fileName');
//                     await file.writeAsBytes(pdfBytes);

//                     await Share.shareXFiles(
//                       [XFile(file.path)],
//                       text: 'Extracted Text PDF',
//                     );

//                     setState(() {
//                       _statusMessage = "PDF shared successfully!";
//                     });
//                   },
//                   child: const Text('Share'),
//                 ),
//               ],
//             ),
//           ),
//         ),
//       );
//     }
//   }

//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       drawer: Sidebar(box: widget.box), // Sidebar moved here
//       appBar: AppBar(
//         title: const Text('MediScan - Text Extractor', style: TextStyle(fontWeight: FontWeight.bold)),
//         leading: Builder(
//           builder: (context) => IconButton(
//             icon: const Icon(Icons.menu),
//             onPressed: () => Scaffold.of(context).openDrawer(),
//           ),
//         ),
//         backgroundColor: Colors.blue.shade700,
//       ),
//       body: Container(
//         padding: const EdgeInsets.all(20),
//         color: Colors.grey.shade100,
//         child: Center(
//           child: SingleChildScrollView(
//             child: Column(
//               mainAxisAlignment: MainAxisAlignment.center,
//               children: [
//                 Card(
//                   elevation: 4,
//                   shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
//                   child: Padding(
//                     padding: const EdgeInsets.symmetric(vertical: 20, horizontal: 20),
//                     child: Column(
//                       children: [
//                         const Text(
//                           "Upload Prescription Image",
//                           style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
//                         ),
//                         const SizedBox(height: 20),
//                         ElevatedButton.icon(
//                           onPressed: () => _getImage(ImageSource.gallery),
//                           icon: const Icon(Icons.image),
//                           label: const Text("Select from Gallery"),
//                           style: ElevatedButton.styleFrom(minimumSize: const Size(200, 40)),
//                         ),
//                         const SizedBox(height: 20),
//                         ElevatedButton.icon(
//                           onPressed: () => _getImage(ImageSource.camera),
//                           icon: const Icon(Icons.camera_alt),
//                           label: const Text("Take a Photo"),
//                           style: ElevatedButton.styleFrom(minimumSize: const Size(200, 40)),
//                         ),
//                         const SizedBox(height: 20),
//                         _statusMessage.isNotEmpty
//                             ? Text(_statusMessage, style: const TextStyle(fontSize: 16))
//                             : const SizedBox.shrink(),
//                         const SizedBox(height: 20),
//                         ElevatedButton(
//                           onPressed: _generatePDF,
//                           child: const Text("Generate PDF from Extracted Text"),
//                         ),
//                         const SizedBox(height: 20),
//                         _extractedText.isNotEmpty
//                             ? Text(
//                                 _extractedText,
//                                 style: const TextStyle(fontSize: 16),
//                               )
//                             : const SizedBox.shrink(),
//                       ],
//                     ),
//                   ),
//                 ),
//               ],
//             ),
//           ),
//         ),
//       ),
//     );
//   }
// }

import 'dart:convert';
import 'dart:typed_data';
import 'dart:io';
import 'dart:html' as html;

import 'package:flutter/foundation.dart' show kIsWeb;
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:http/http.dart' as http;
import 'package:hive/hive.dart';
import 'package:pdf/widgets.dart' as pw;
import 'package:pdf/pdf.dart';
import 'package:path_provider/path_provider.dart';
import 'package:open_filex/open_filex.dart';
import 'package:share_plus/share_plus.dart';
import '../widgets/sidebar.dart';
import '../models/text_model.dart';

class TextExtractorScreen extends StatefulWidget {
  final Box<TextModel> box;

  const TextExtractorScreen({super.key, required this.box});

  @override
  State<TextExtractorScreen> createState() => _TextExtractorScreenState();
}

class _TextExtractorScreenState extends State<TextExtractorScreen> {
  XFile? _image;
  String _extractedText = "";
  String _statusMessage = "";
  final picker = ImagePicker();

  Future<void> _getImage(ImageSource source) async {
    try {
      final pickedFile = await picker.pickImage(source: source);
      if (pickedFile != null) {
        setState(() {
          _image = pickedFile;
          _extractedText = "";
          _statusMessage = "Uploading image...";
        });
        await _uploadImage(pickedFile);
      } else {
        setState(() => _statusMessage = "No image selected.");
      }
    } catch (e) {
      setState(() => _statusMessage = "Picker error: $e");
    }
  }

  Future<void> _uploadImage(XFile image) async {
    try {
      final uri = Uri.parse('http://localhost:3000/api/extract-text');
      var request = http.MultipartRequest('POST', uri);

      if (kIsWeb) {
        final bytes = await image.readAsBytes();
        request.files.add(http.MultipartFile.fromBytes('image', bytes, filename: image.name));
      } else {
        request.files.add(await http.MultipartFile.fromPath('image', image.path));
      }

      final response = await request.send();
      final responseBody = await response.stream.bytesToString();

      if (response.statusCode == 200) {
        final data = jsonDecode(responseBody);
        final extracted = data['extractedText']?.toString() ?? 'No text found.';
        setState(() {
          _extractedText = extracted;
          _statusMessage = "Text extracted successfully!";
        });

        final newName = 'Document ${widget.box.length + 1}';
        await widget.box.add(TextModel(
          name: newName,
          content: _extractedText,
          dateTime: DateTime.now(),
        ));
      } else {
        setState(() => _statusMessage = 'Upload failed: ${response.statusCode}');
      }
    } catch (e) {
      setState(() => _statusMessage = 'Upload error: $e');
    }
  }

  Future<void> _generatePDF() async {
    if (_extractedText.isEmpty) {
      setState(() => _statusMessage = "No text to convert.");
      return;
    }

    try {
      final pdf = pw.Document();
      pdf.addPage(pw.Page(
        build: (context) => pw.Padding(
          padding: const pw.EdgeInsets.all(16),
          child: pw.Text(_extractedText, style: const pw.TextStyle(fontSize: 14)),
        ),
      ));

      final pdfBytes = await pdf.save();
      final fileName = 'Extracted_Text_${DateTime.now().millisecondsSinceEpoch}.pdf';
      await _showPDFOptions(pdfBytes, fileName);
    } catch (e) {
      setState(() => _statusMessage = "PDF error: $e");
    }
  }

  Future<void> _showPDFOptions(Uint8List pdfBytes, String fileName) async {
    if (kIsWeb) {
      final blob = html.Blob([pdfBytes]);
      final url = html.Url.createObjectUrlFromBlob(blob);
      final anchor = html.AnchorElement(href: url)
        ..setAttribute("download", fileName)
        ..click();
      html.Url.revokeObjectUrl(url);
      setState(() => _statusMessage = "PDF downloaded.");
    } else {
      showDialog(
        context: context,
        builder: (context) => AlertDialog(
          title: const Text('PDF Options'),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              ElevatedButton.icon(
                onPressed: () async {
                  final dir = await getApplicationDocumentsDirectory();
                  final file = File('${dir.path}/$fileName');
                  await file.writeAsBytes(pdfBytes);
                  setState(() => _statusMessage = "Saved to ${file.path}");
                  await OpenFilex.open(file.path);
                  Navigator.pop(context);
                },
                icon: const Icon(Icons.download),
                label: const Text('Download & Open'),
              ),
              const SizedBox(height: 10),
              ElevatedButton.icon(
                onPressed: () async {
                  final dir = await getApplicationDocumentsDirectory();
                  final file = File('${dir.path}/$fileName');
                  await file.writeAsBytes(pdfBytes);
                  await Share.shareXFiles([XFile(file.path)], text: 'Your PDF is ready!');
                  setState(() => _statusMessage = "PDF shared.");
                  Navigator.pop(context);
                },
                icon: const Icon(Icons.share),
                label: const Text('Share'),
              ),
            ],
          ),
        ),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      drawer: Sidebar(box: widget.box),
      appBar: AppBar(
        title: const Text('MediScan - Text Extractor'),
        backgroundColor: Colors.lightBlue.shade700,
      ),
      body: Container(
        padding: const EdgeInsets.all(16),
        color: Colors.blue.shade50,
        child: Center(
          child: SingleChildScrollView(
            child: Card(
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
              elevation: 6,
              child: Padding(
                padding: const EdgeInsets.all(24.0),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    const Text(
                      "Scan Prescription",
                      style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold),
                    ),
                    const SizedBox(height: 16),
                    ElevatedButton.icon(
                      onPressed: () => _getImage(ImageSource.gallery),
                      icon: const Icon(Icons.image),
                      label: const Text("Choose from Gallery"),
                      style: ElevatedButton.styleFrom(
                        backgroundColor: Colors.lightBlue.shade400,
                        minimumSize: const Size(200, 45),
                        textStyle: const TextStyle(fontSize: 16),
                      ),
                    ),
                    const SizedBox(height: 12),
                    ElevatedButton.icon(
                      onPressed: () => _getImage(ImageSource.camera),
                      icon: const Icon(Icons.camera_alt),
                      label: const Text("Take Photo"),
                      style: ElevatedButton.styleFrom(
                        backgroundColor: Colors.lightBlue.shade400,
                        minimumSize: const Size(200, 45),
                        textStyle: const TextStyle(fontSize: 16),
                      ),
                    ),
                    const SizedBox(height: 20),
                    if (_statusMessage.isNotEmpty)
                      Text(
                        _statusMessage,
                        style: const TextStyle(fontSize: 16, color: Colors.black87),
                        textAlign: TextAlign.center,
                      ),
                    const SizedBox(height: 20),
                    if (_extractedText.isNotEmpty)
                      Column(
                        children: [
                          const Text(
                            "Extracted Text",
                            style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                          ),
                          const SizedBox(height: 8),
                          Container(
                            padding: const EdgeInsets.all(12),
                            decoration: BoxDecoration(
                              border: Border.all(color: Colors.grey.shade300),
                              borderRadius: BorderRadius.circular(12),
                              color: Colors.white,
                            ),
                            child: Text(
                              _extractedText,
                              style: const TextStyle(fontSize: 16),
                            ),
                          ),
                          const SizedBox(height: 20),
                          ElevatedButton.icon(
                            onPressed: _generatePDF,
                            icon: const Icon(Icons.picture_as_pdf),
                            label: const Text("Generate PDF"),
                            style: ElevatedButton.styleFrom(
                              backgroundColor: Colors.green.shade600,
                              minimumSize: const Size(200, 45),
                            ),
                          ),
                        ],
                      ),
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}

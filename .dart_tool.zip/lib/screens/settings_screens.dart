// import 'package:flutter/material.dart';
// import 'package:hive/hive.dart';
// import 'package:shared_preferences/shared_preferences.dart';

// import '../models/text_model.dart';
// import '../widgets/sidebar.dart';
// import 'deleted_documents_screen.dart';

// class SettingsScreen extends StatefulWidget {
//   final Box<TextModel> box;

//   const SettingsScreen({super.key, required this.box});

//   @override
//   _SettingsScreenState createState() => _SettingsScreenState();
// }

// class _SettingsScreenState extends State<SettingsScreen> {
//   bool _alwaysUseCamera = false;

//   @override
//   void initState() {
//     super.initState();
//     _loadCameraPreference();
//   }

//   void _loadCameraPreference() async {
//     SharedPreferences prefs = await SharedPreferences.getInstance();
//     setState(() {
//       _alwaysUseCamera = prefs.getBool('alwaysUseCamera') ?? false;
//     });
//   }

//   void _toggleCameraPreference(bool value) async {
//     SharedPreferences prefs = await SharedPreferences.getInstance();
//     await prefs.setBool('alwaysUseCamera', value);
//     setState(() {
//       _alwaysUseCamera = value;
//     });
//   }

//   void _confirmLogout(BuildContext context) {
//     showDialog(
//       context: context,
//       builder: (context) => AlertDialog(
//         title: const Text('Confirm Logout'),
//         content: const Text('Are you sure you want to log out?'),
//         actions: [
//           TextButton(
//             onPressed: () => Navigator.of(context).pop(),
//             child: const Text('Cancel'),
//           ),
//           ElevatedButton(
//             onPressed: () {
//               Navigator.of(context).pop(); // Closes the dialog
//               Navigator.of(context).popUntil((route) => route.isFirst); // Navigates to first screen
//             },
//             child: const Text('Logout'),
//           ),
//         ],
//       ),
//     );
//   }

//   void _clearAllDocuments(BuildContext context) async {
//     final confirmed = await showDialog<bool>(
//       context: context,
//       builder: (context) => AlertDialog(
//         title: const Text('Clear All Saved Documents'),
//         content: const Text('This will mark all documents as deleted. Are you sure?'),
//         actions: [
//           TextButton(
//             onPressed: () => Navigator.of(context).pop(false),
//             child: const Text('Cancel'),
//           ),
//           ElevatedButton(
//             onPressed: () => Navigator.of(context).pop(true),
//             child: const Text('Delete All'),
//           ),
//         ],
//       ),
//     );

//     if (confirmed ?? false) {
//       for (var doc in widget.box.values) {
//         doc.isDeleted = true;
//         await doc.save();
//       }

//       ScaffoldMessenger.of(context).showSnackBar(
//         const SnackBar(content: Text('All documents marked as deleted.')),
//       );
//     }
//   }

//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       drawer: Sidebar(box: widget.box),
//       appBar: AppBar(
//         title: const Text('Settings'),
//         leading: Builder(
//           builder: (context) => IconButton(
//             icon: const Icon(Icons.menu),
//             onPressed: () => Scaffold.of(context).openDrawer(),
//           ),
//         ),
//       ),
//       body: ListView(
//         padding: const EdgeInsets.all(24),
//         children: [
//           const Text(
//             'Account',
//             style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
//           ),
//           const SizedBox(height: 10),
//           ListTile(
//             leading: const Icon(Icons.logout),
//             title: const Text('Logout'),
//             onTap: () => _confirmLogout(context),
//           ),
//           const Divider(),
//           const Text(
//             'Storage',
//             style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
//           ),
//           const SizedBox(height: 10),
//           // Only one instance of "Clear All Saved Documents"
//           ListTile(
//             leading: const Icon(Icons.delete_forever),
//             title: const Text('Clear All Saved Documents'),
//             onTap: () => _clearAllDocuments(context),
//           ),
//           ListTile(
//             leading: const Icon(Icons.restore_from_trash),
//             title: const Text('View Previously Deleted Documents'),
//             onTap: () {
//               Navigator.push(
//                 context,
//                 MaterialPageRoute(
//                   builder: (context) => DeletedDocumentsScreen(box: widget.box),
//                 ),
//               );
//             },
//           ),
//           const Divider(),
//           const Text(
//             'Preferences',
//             style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
//           ),
//           const SizedBox(height: 10),
//           SwitchListTile(
//             title: const Text('Always use Camera'),
//             value: _alwaysUseCamera,
//             onChanged: _toggleCameraPreference,
//           ),
//         ],
//       ),
//     );
//   }
// }

// import 'package:flutter/material.dart';
// import 'package:hive/hive.dart';
// import 'package:shared_preferences/shared_preferences.dart';

// import '../models/text_model.dart';
// import '../widgets/sidebar.dart';
// import 'deleted_documents_screen.dart';

// class SettingsScreen extends StatefulWidget {
//   final Box<TextModel> box;

//   const SettingsScreen({super.key, required this.box});

//   @override
//   _SettingsScreenState createState() => _SettingsScreenState();
// }

// class _SettingsScreenState extends State<SettingsScreen> {
//   bool _alwaysUseCamera = false;

//   @override
//   void initState() {
//     super.initState();
//     _loadCameraPreference();
//   }

//   void _loadCameraPreference() async {
//     SharedPreferences prefs = await SharedPreferences.getInstance();
//     setState(() {
//       _alwaysUseCamera = prefs.getBool('alwaysUseCamera') ?? false;
//     });
//   }

//   void _toggleCameraPreference(bool value) async {
//     SharedPreferences prefs = await SharedPreferences.getInstance();
//     await prefs.setBool('alwaysUseCamera', value);
//     setState(() {
//       _alwaysUseCamera = value;
//     });
//   }

//   void _confirmLogout(BuildContext context) {
//     showDialog(
//       context: context,
//       builder: (context) => AlertDialog(
//         title: const Text('Confirm Logout'),
//         content: const Text('Are you sure you want to log out?'),
//         actions: [
//           TextButton(
//             onPressed: () => Navigator.of(context).pop(),
//             child: const Text('Cancel'),
//           ),
//           ElevatedButton(
//             style: ElevatedButton.styleFrom(backgroundColor: Colors.redAccent),
//             onPressed: () {
//               Navigator.of(context).pop();
//               Navigator.of(context).popUntil((route) => route.isFirst);
//             },
//             child: const Text('Logout'),
//           ),
//         ],
//       ),
//     );
//   }

//   void _clearAllDocuments(BuildContext context) async {
//     final confirmed = await showDialog<bool>(
//       context: context,
//       builder: (context) => AlertDialog(
//         title: const Text('Clear All Saved Documents'),
//         content: const Text('This will mark all documents as deleted. Are you sure?'),
//         actions: [
//           TextButton(
//             onPressed: () => Navigator.of(context).pop(false),
//             child: const Text('Cancel'),
//           ),
//           ElevatedButton(
//             style: ElevatedButton.styleFrom(backgroundColor: Colors.redAccent),
//             onPressed: () => Navigator.of(context).pop(true),
//             child: const Text('Delete All'),
//           ),
//         ],
//       ),
//     );

//     if (confirmed ?? false) {
//       for (var doc in widget.box.values) {
//         doc.isDeleted = true;
//         await doc.save();
//       }
//       ScaffoldMessenger.of(context).showSnackBar(
//         const SnackBar(content: Text('All documents marked as deleted.')),
//       );
//     }
//   }

//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       drawer: Sidebar(box: widget.box),
//       appBar: AppBar(
//         title: const Text('Settings'),
//         backgroundColor: Colors.indigo,
//       ),
//       body: Container(
//         color: const Color(0xFFF5F7FA),
//         child: ListView(
//           padding: const EdgeInsets.all(16),
//           children: [
//             _buildSectionTitle('Account'),
//             _buildCard([
//               _buildListTile(
//                 icon: Icons.logout,
//                 title: 'Logout',
//                 subtitle: 'Securely log out of your account',
//                 onTap: () => _confirmLogout(context),
//                 iconColor: Colors.redAccent,
//               ),
//             ]),
//             _buildSectionTitle('Storage'),
//             _buildCard([
//               _buildListTile(
//                 icon: Icons.delete_forever,
//                 title: 'Clear All Saved Documents',
//                 subtitle: 'Mark all documents as deleted',
//                 onTap: () => _clearAllDocuments(context),
//               ),
//               _buildListTile(
//                 icon: Icons.restore_from_trash,
//                 title: 'View Deleted Documents',
//                 subtitle: 'Recover or review deleted documents',
//                 onTap: () {
//                   Navigator.push(
//                     context,
//                     MaterialPageRoute(
//                       builder: (context) => DeletedDocumentsScreen(box: widget.box),
//                     ),
//                   );
//                 },
//               ),
//             ]),
//             _buildSectionTitle('Preferences'),
//             _buildCard([
//               SwitchListTile(
//                 title: const Text('Always Use Camera'),
//                 subtitle: const Text('Skip gallery and directly open camera'),
//                 value: _alwaysUseCamera,
//                 onChanged: _toggleCameraPreference,
//                 activeColor: Colors.indigo,
//               ),
//             ]),
//           ],
//         ),
//       ),
//     );
//   }

//   Widget _buildSectionTitle(String title) {
//     return Padding(
//       padding: const EdgeInsets.symmetric(vertical: 12),
//       child: Text(
//         title,
//         style: const TextStyle(fontSize: 22, fontWeight: FontWeight.bold, color: Colors.indigo),
//       ),
//     );
//   }

//   Widget _buildCard(List<Widget> children) {
//     return Card(
//       elevation: 4,
//       shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
//       child: Column(children: children),
//     );
//   }

//   Widget _buildListTile({required IconData icon, required String title, required String subtitle, required VoidCallback onTap, Color iconColor = Colors.indigo}) {
//     return ListTile(
//       leading: CircleAvatar(
//         backgroundColor: iconColor.withOpacity(0.1),
//         child: Icon(icon, color: iconColor),
//       ),
//       title: Text(title, style: const TextStyle(fontWeight: FontWeight.bold)),
//       subtitle: Text(subtitle),
//       trailing: const Icon(Icons.arrow_forward_ios, size: 16),
//       onTap: onTap,
//     );
//   }
// }

// import 'package:flutter/material.dart';
// import 'package:hive/hive.dart';
// import 'package:shared_preferences/shared_preferences.dart';

// import '../models/text_model.dart';
// import '../services/password_service.dart'; // Make sure this file exists
// import '../widgets/sidebar.dart';
// import 'deleted_documents_screen.dart';

// class SettingsScreen extends StatefulWidget {
//   final Box<TextModel> box;

//   const SettingsScreen({super.key, required this.box});

//   @override
//   _SettingsScreenState createState() => _SettingsScreenState();
// }

// class _SettingsScreenState extends State<SettingsScreen> {
//   bool _alwaysUseCamera = false;

//   @override
//   void initState() {
//     super.initState();
//     _loadCameraPreference();
//   }

//   void _loadCameraPreference() async {
//     SharedPreferences prefs = await SharedPreferences.getInstance();
//     setState(() {
//       _alwaysUseCamera = prefs.getBool('alwaysUseCamera') ?? false;
//     });
//   }

//   void _toggleCameraPreference(bool value) async {
//     SharedPreferences prefs = await SharedPreferences.getInstance();
//     await prefs.setBool('alwaysUseCamera', value);
//     setState(() {
//       _alwaysUseCamera = value;
//     });
//   }

//   void _confirmLogout(BuildContext context) {
//     showDialog(
//       context: context,
//       builder: (context) => AlertDialog(
//         title: const Text('Confirm Logout'),
//         content: const Text('Are you sure you want to log out?'),
//         actions: [
//           TextButton(
//             onPressed: () => Navigator.of(context).pop(),
//             child: const Text('Cancel'),
//           ),
//           ElevatedButton(
//             style: ElevatedButton.styleFrom(backgroundColor: Colors.redAccent),
//             onPressed: () {
//               Navigator.of(context).pop();
//               Navigator.of(context).popUntil((route) => route.isFirst);
//             },
//             child: const Text('Logout'),
//           ),
//         ],
//       ),
//     );
//   }

//   void _clearAllDocuments(BuildContext context) async {
//     final confirmed = await showDialog<bool>(
//       context: context,
//       builder: (context) => AlertDialog(
//         title: const Text('Clear All Saved Documents'),
//         content: const Text('This will mark all documents as deleted. Are you sure?'),
//         actions: [
//           TextButton(
//             onPressed: () => Navigator.of(context).pop(false),
//             child: const Text('Cancel'),
//           ),
//           ElevatedButton(
//             style: ElevatedButton.styleFrom(backgroundColor: Colors.redAccent),
//             onPressed: () => Navigator.of(context).pop(true),
//             child: const Text('Delete All'),
//           ),
//         ],
//       ),
//     );

//     if (confirmed ?? false) {
//       for (var doc in widget.box.values) {
//         doc.isDeleted = true;
//         await doc.save();
//       }
//       ScaffoldMessenger.of(context).showSnackBar(
//         const SnackBar(content: Text('All documents marked as deleted.')),
//       );
//     }
//   }

//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       drawer: Sidebar(box: widget.box),
//       appBar: AppBar(
//         title: const Text('Settings'),
//         backgroundColor: Colors.indigo,
//       ),
//       body: Container(
//         color: const Color(0xFFF5F7FA),
//         child: ListView(
//           padding: const EdgeInsets.all(16),
//           children: [
//             _buildSectionTitle('Account'),
//             _buildCard([
//               _buildListTile(
//                 icon: Icons.logout,
//                 title: 'Logout',
//                 subtitle: 'Securely log out of your account',
//                 onTap: () => _confirmLogout(context),
//                 iconColor: Colors.redAccent,
//               ),
//             ]),
//             _buildSectionTitle('Storage'),
//             _buildCard([
//               _buildListTile(
//                 icon: Icons.delete_forever,
//                 title: 'Clear All Saved Documents',
//                 subtitle: 'Mark all documents as deleted',
//                 onTap: () => _clearAllDocuments(context),
//               ),
//               _buildListTile(
//                 icon: Icons.restore_from_trash,
//                 title: 'View Deleted Documents',
//                 subtitle: 'Recover or review deleted documents',
//                 onTap: () {
//                   Navigator.push(
//                     context,
//                     MaterialPageRoute(
//                       builder: (context) => DeletedDocumentsScreen(box: widget.box),
//                     ),
//                   );
//                 },
//               ),
//             ]),
//             _buildSectionTitle('Preferences'),
//             _buildCard([
//               ListTile(
//                 leading: const Icon(Icons.lock, color: Colors.indigo),
//                 title: const Text("Set/Change App Password"),
//                 subtitle: const Text("Secure the app with a password"),
//                 onTap: () {
//                   showDialog(
//                     context: context,
//                     builder: (context) {
//                       final controller = TextEditingController();
//                       return AlertDialog(
//                         title: const Text("Set App Password"),
//                         content: TextField(
//                           controller: controller,
//                           obscureText: true,
//                           decoration: const InputDecoration(hintText: "Enter new password"),
//                         ),
//                         actions: [
//                           TextButton(
//                             onPressed: () async {
//                               await PasswordService.savePassword(controller.text.trim());
//                               Navigator.pop(context);
//                               ScaffoldMessenger.of(context).showSnackBar(
//                                 const SnackBar(content: Text("Password set successfully")),
//                               );
//                             },
//                             child: const Text("Save"),
//                           ),
//                         ],
//                       );
//                     },
//                   );
//                 },
//               ),
//               const Divider(),
//               SwitchListTile(
//                 title: const Text('Always Use Camera'),
//                 subtitle: const Text('Skip gallery and directly open camera'),
//                 value: _alwaysUseCamera,
//                 onChanged: _toggleCameraPreference,
//                 activeColor: Colors.indigo,
//               ),
//             ]),
//           ],
//         ),
//       ),
//     );
//   }

//   Widget _buildSectionTitle(String title) {
//     return Padding(
//       padding: const EdgeInsets.symmetric(vertical: 12),
//       child: Text(
//         title,
//         style: const TextStyle(fontSize: 22, fontWeight: FontWeight.bold, color: Colors.indigo),
//       ),
//     );
//   }

//   Widget _buildCard(List<Widget> children) {
//     return Card(
//       elevation: 4,
//       shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
//       child: Column(children: children),
//     );
//   }

//   Widget _buildListTile({required IconData icon, required String title, required String subtitle, required VoidCallback onTap, Color iconColor = Colors.indigo}) {
//     return ListTile(
//       leading: CircleAvatar(
//         backgroundColor: iconColor.withOpacity(0.1),
//         child: Icon(icon, color: iconColor),
//       ),
//       title: Text(title, style: const TextStyle(fontWeight: FontWeight.bold)),
//       subtitle: Text(subtitle),
//       trailing: const Icon(Icons.arrow_forward_ios, size: 16),
//       onTap: onTap,
//     );
//   }
// }


// import 'package:flutter/material.dart';
// import 'package:hive/hive.dart';
// import 'package:shared_preferences/shared_preferences.dart';
// import '../services/password_service.dart';
// import '../models/text_model.dart';
// import '../widgets/sidebar.dart';
// import 'deleted_documents_screen.dart';


// class SettingsScreen extends StatefulWidget {
//   final Box<TextModel> box;

//   const SettingsScreen({super.key, required this.box});

//   @override
//   _SettingsScreenState createState() => _SettingsScreenState();
// }

// class _SettingsScreenState extends State<SettingsScreen> {
//   bool _alwaysUseCamera = false;

//   @override
//   void initState() {
//     super.initState();
//     _loadCameraPreference();
//   }

//   void _loadCameraPreference() async {
//     SharedPreferences prefs = await SharedPreferences.getInstance();
//     setState(() {
//       _alwaysUseCamera = prefs.getBool('alwaysUseCamera') ?? false;
//     });
//   }

//   void _toggleCameraPreference(bool value) async {
//     SharedPreferences prefs = await SharedPreferences.getInstance();
//     await prefs.setBool('alwaysUseCamera', value);
//     setState(() {
//       _alwaysUseCamera = value;
//     });
//   }

//   void _confirmLogout(BuildContext context) {
//     showDialog(
//       context: context,
//       builder: (context) => AlertDialog(
//         title: const Text('Confirm Logout'),
//         content: const Text('Are you sure you want to log out?'),
//         actions: [
//           TextButton(
//             onPressed: () => Navigator.of(context).pop(),
//             child: const Text('Cancel'),
//           ),
//           ElevatedButton(
//             style: ElevatedButton.styleFrom(backgroundColor: Colors.redAccent),
//             onPressed: () {
//               Navigator.of(context).pop();
//               Navigator.of(context).popUntil((route) => route.isFirst);
//             },
//             child: const Text('Logout'),
//           ),
//         ],
//       ),
//     );
//   }

//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       drawer: Sidebar(box: widget.box),
//       appBar: AppBar(
//         title: const Text('Settings'),
//         backgroundColor: Colors.indigo,
//       ),
//       body: Container(
//         color: const Color(0xFFF5F7FA),
//         child: ListView(
//           padding: const EdgeInsets.all(16),
//           children: [
//             _buildSectionTitle('Account'),
//             _buildCard([
//               _buildListTile(
//                 icon: Icons.logout,
//                 title: 'Logout',
//                 subtitle: 'Securely log out of your account',
//                 onTap: () => _confirmLogout(context),
//                 iconColor: Colors.redAccent,
//               ),
//             ]),
//             _buildSectionTitle('Storage'),
//             _buildCard([
//               _buildListTile(
//                 icon: Icons.restore_from_trash,
//                 title: 'View Deleted Documents',
//                 subtitle: 'Recover or review deleted documents',
//                 onTap: () {
//                   Navigator.push(
//                     context,
//                     MaterialPageRoute(
//                       builder: (context) => DeletedDocumentsScreen(box: widget.box),
//                     ),
//                   );
//                 },
//               ),
//             ]),
//             _buildSectionTitle('Preferences'),
//             _buildCard([
//               ListTile(
//                 leading: const Icon(Icons.lock, color: Colors.indigo),
//                 title: const Text("Set/Change App Password"),
//                 subtitle: const Text("Secure the app with a password"),
//                 onTap: () {
//                   showDialog(
//                     context: context,
//                     builder: (context) {
//                       final controller = TextEditingController();
//                       return AlertDialog(
//                         title: const Text("Set App Password"),
//                         content: TextField(
//                           controller: controller,
//                           obscureText: true,
//                           decoration: const InputDecoration(hintText: "Enter new password"),
//                         ),
//                         actions: [
//                           TextButton(
//                             onPressed: () async {
//                               // Save the password securely
//                               // Replace this with the actual password-saving logic.
//                               await PasswordService.savePassword(controller.text.trim());
//                               Navigator.pop(context);
//                               ScaffoldMessenger.of(context).showSnackBar(
//                                 const SnackBar(content: Text("Password set successfully")),
//                               );
//                             },
//                             child: const Text("Save"),
//                           ),
//                         ],
//                       );
//                     },
//                   );
//                 },
//               ),
//               const Divider(),
//               SwitchListTile(
//                 title: const Text('Always Use Camera'),
//                 subtitle: const Text('Skip gallery and directly open camera'),
//                 value: _alwaysUseCamera,
//                 onChanged: _toggleCameraPreference,
//                 activeColor: Colors.indigo,
//               ),
//             ]),
//           ],
//         ),
//       ),
//     );
//   }

//   Widget _buildSectionTitle(String title) {
//     return Padding(
//       padding: const EdgeInsets.symmetric(vertical: 12),
//       child: Text(
//         title,
//         style: const TextStyle(fontSize: 22, fontWeight: FontWeight.bold, color: Colors.indigo),
//       ),
//     );
//   }

//   Widget _buildCard(List<Widget> children) {
//     return Card(
//       elevation: 4,
//       shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
//       child: Column(children: children),
//     );
//   }

//   Widget _buildListTile({required IconData icon, required String title, required String subtitle, required VoidCallback onTap, Color iconColor = Colors.indigo}) {
//     return ListTile(
//       leading: CircleAvatar(
//         backgroundColor: iconColor.withOpacity(0.1),
//         child: Icon(icon, color: iconColor),
//       ),
//       title: Text(title, style: const TextStyle(fontWeight: FontWeight.bold)),
//       subtitle: Text(subtitle),
//       trailing: const Icon(Icons.arrow_forward_ios, size: 16),
//       onTap: onTap,
//     );
//   }
// }


// import 'package:flutter/material.dart';
// import '../services/password_service.dart';
// import 'package:flutter/material.dart';
// import 'package:hive/hive.dart';
// import 'package:shared_preferences/shared_preferences.dart';
// //import '../services/password_service.dart';
// import '../models/text_model.dart';
// import '../widgets/sidebar.dart';
// import 'deleted_documents_screen.dart';


// class SettingsScreen extends StatefulWidget {
//   final Box<TextModel> box;
//   const SettingsScreen({Key? key,required this.box}) : super(key: key);

//   @override
//   _SettingsScreenState createState() => _SettingsScreenState();
// }

// class _SettingsScreenState extends State<SettingsScreen> {
//   final TextEditingController _passwordController = TextEditingController();
//   String _statusMessage = '';

//   @override
//   void initState() {
//     super.initState();
//     _loadPassword();
//   }

//   void _loadPassword() async {
//     String? password = await PasswordService.getPassword();
//     if (password != null) {
//       _passwordController.text = password;
//     }
//   }

//   void _savePassword() async {
//     String password = _passwordController.text.trim();
//     if (password.isNotEmpty) {
//       await PasswordService.savePassword(password);
//       setState(() {
//         _statusMessage = 'Password saved successfully!';
//       });
//     } else {
//       setState(() {
//         _statusMessage = 'Please enter a valid password.';
//       });
//     }
//   }

//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       appBar: AppBar(
//         title: const Text('Settings'),
//       ),
//       body: Padding(
//         padding: const EdgeInsets.all(16.0),
//         child: Column(
//           crossAxisAlignment: CrossAxisAlignment.start,
//           children: [
//             const Text(
//               'Set Password for Saved Documents',
//               style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
//             ),
//             const SizedBox(height: 12),
//             TextField(
//               controller: _passwordController,
//               obscureText: true,
//               decoration: const InputDecoration(
//                 labelText: 'Enter password',
//                 border: OutlineInputBorder(),
//               ),
//             ),
//             const SizedBox(height: 16),
//             ElevatedButton(
//               onPressed: _savePassword,
//               child: const Text('Save Password'),
//             ),
//             const SizedBox(height: 12),
//             Text(
//               _statusMessage,
//               style: const TextStyle(color: Colors.green),
//             ),
//           ],
//         ),
//       ),
//     );
//   }
// }

// import 'package:flutter/material.dart';
// import 'package:hive/hive.dart';
// import 'package:shared_preferences/shared_preferences.dart';
// import '../services/password_service.dart';
// import '../models/text_model.dart';
// import '../widgets/sidebar.dart';
// import 'deleted_documents_screen.dart';

// class SettingsScreen extends StatefulWidget {
//   final Box<TextModel> box;
//   const SettingsScreen({Key? key, required this.box}) : super(key: key);

//   @override
//   _SettingsScreenState createState() => _SettingsScreenState();
// }

// class _SettingsScreenState extends State<SettingsScreen> {
//   bool _alwaysUseCamera = false;
//   final TextEditingController _passwordController = TextEditingController();
//   String _statusMessage = '';

//   @override
//   void initState() {
//     super.initState();
//     _loadCameraPreference();
//     _loadPassword();
//   }

//   void _loadCameraPreference() async {
//     SharedPreferences prefs = await SharedPreferences.getInstance();
//     setState(() {
//       _alwaysUseCamera = prefs.getBool('alwaysUseCamera') ?? false;
//     });
//   }

//   void _toggleCameraPreference(bool value) async {
//     SharedPreferences prefs = await SharedPreferences.getInstance();
//     await prefs.setBool('alwaysUseCamera', value);
//     setState(() {
//       _alwaysUseCamera = value;
//     });
//   }

//   void _loadPassword() async {
//     String? password = await PasswordService.getPassword();
//     if (password != null) {
//       _passwordController.text = password;
//     }
//   }

//   void _savePassword() async {
//     String password = _passwordController.text.trim();
//     if (password.isNotEmpty) {
//       await PasswordService.savePassword(password);
//       setState(() {
//         _statusMessage = 'Password saved successfully!';
//       });
//     } else {
//       setState(() {
//         _statusMessage = 'Please enter a valid password.';
//       });
//     }
//   }

//   void _confirmLogout(BuildContext context) {
//     showDialog(
//       context: context,
//       builder: (context) => AlertDialog(
//         title: const Text('Confirm Logout'),
//         content: const Text('Are you sure you want to log out?'),
//         actions: [
//           TextButton(
//             onPressed: () => Navigator.of(context).pop(),
//             child: const Text('Cancel'),
//           ),
//           ElevatedButton(
//             style: ElevatedButton.styleFrom(backgroundColor: Colors.redAccent),
//             onPressed: () {
//               Navigator.of(context).pop();
//               Navigator.of(context).popUntil((route) => route.isFirst);
//             },
//             child: const Text('Logout'),
//           ),
//         ],
//       ),
//     );
//   }

//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       drawer: Sidebar(box: widget.box),
//       appBar: AppBar(
//         title: const Text('Settings'),
//         backgroundColor: Colors.indigo,
//       ),
//       body: Container(
//         color: const Color(0xFFF5F7FA),
//         child: ListView(
//           padding: const EdgeInsets.all(16),
//           children: [
//             _buildSectionTitle('Account'),
//             _buildCard([
//               _buildListTile(
//                 icon: Icons.logout,
//                 title: 'Logout',
//                 subtitle: 'Securely log out of your account',
//                 onTap: () => _confirmLogout(context),
//                 iconColor: Colors.redAccent,
//               ),
//             ]),
//             _buildSectionTitle('Storage'),
//             _buildCard([
//               _buildListTile(
//                 icon: Icons.restore_from_trash,
//                 title: 'View Deleted Documents',
//                 subtitle: 'Recover or review deleted documents',
//                 onTap: () {
//                   Navigator.push(
//                     context,
//                     MaterialPageRoute(
//                       builder: (context) =>
//                           DeletedDocumentsScreen(box: widget.box),
//                     ),
//                   );
//                 },
//               ),
//             ]),
//             _buildSectionTitle('Preferences'),
//             _buildCard([
//               Padding(
//                 padding: const EdgeInsets.all(12.0),
//                 child: Column(
//                   crossAxisAlignment: CrossAxisAlignment.start,
//                   children: [
//                     const Text(
//                       'Set Password for Saved Documents',
//                       style:
//                           TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
//                     ),
//                     const SizedBox(height: 8),
//                     TextField(
//                       controller: _passwordController,
//                       obscureText: true,
//                       decoration: const InputDecoration(
//                         labelText: 'Enter password',
//                         border: OutlineInputBorder(),
//                       ),
//                     ),
//                     const SizedBox(height: 8),
//                     ElevatedButton(
//                       onPressed: _savePassword,
//                       child: const Text('Save Password'),
//                     ),
//                     const SizedBox(height: 6),
//                     Text(
//                       _statusMessage,
//                       style: const TextStyle(color: Colors.green),
//                     ),
//                   ],
//                 ),
//               ),
//               const Divider(),
//               SwitchListTile(
//                 title: const Text('Always Use Camera'),
//                 subtitle: const Text('Skip gallery and directly open camera'),
//                 value: _alwaysUseCamera,
//                 onChanged: _toggleCameraPreference,
//                 activeColor: Colors.indigo,
//               ),
//             ]),
//           ],
//         ),
//       ),
//     );
//   }

//   Widget _buildSectionTitle(String title) {
//     return Padding(
//       padding: const EdgeInsets.symmetric(vertical: 12),
//       child: Text(
//         title,
//         style: const TextStyle(
//             fontSize: 22, fontWeight: FontWeight.bold, color: Colors.indigo),
//       ),
//     );
//   }

//   Widget _buildCard(List<Widget> children) {
//     return Card(
//       elevation: 4,
//       shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
//       child: Column(children: children),
//     );
//   }

//   Widget _buildListTile({
//     required IconData icon,
//     required String title,
//     required String subtitle,
//     required VoidCallback onTap,
//     Color iconColor = Colors.indigo,
//   }) {
//     return ListTile(
//       leading: CircleAvatar(
//         backgroundColor: iconColor.withOpacity(0.1),
//         child: Icon(icon, color: iconColor),
//       ),
//       title: Text(title, style: const TextStyle(fontWeight: FontWeight.bold)),
//       subtitle: Text(subtitle),
//       trailing: const Icon(Icons.arrow_forward_ios, size: 16),
//       onTap: onTap,
//     );
//   }
// }


// import 'package:flutter/material.dart';
// import 'package:hive/hive.dart';
// import 'package:shared_preferences/shared_preferences.dart';
// import '../services/password_service.dart';
// import '../models/text_model.dart';
// import '../widgets/sidebar.dart';
// import 'deleted_documents_screen.dart';
// import '../widgets/vertical_tab_sidebar.dart';


// class SettingsScreen extends StatefulWidget {
//   final Box<TextModel> box;
//   const SettingsScreen({Key? key, required this.box}) : super(key: key);

//   @override
//   _SettingsScreenState createState() => _SettingsScreenState();
// }

// class _SettingsScreenState extends State<SettingsScreen> {
//   bool _alwaysUseCamera = false;
//   final TextEditingController _passwordController = TextEditingController();
//   String _statusMessage = '';

//   @override
//   void initState() {
//     super.initState();
//     _loadCameraPreference();
//     _loadPassword();
//   }

//   void _loadCameraPreference() async {
//     SharedPreferences prefs = await SharedPreferences.getInstance();
//     setState(() {
//       _alwaysUseCamera = prefs.getBool('alwaysUseCamera') ?? false;
//     });
//   }

//   void _toggleCameraPreference(bool value) async {
//     SharedPreferences prefs = await SharedPreferences.getInstance();
//     await prefs.setBool('alwaysUseCamera', value);
//     setState(() {
//       _alwaysUseCamera = value;
//     });
//   }

//   void _loadPassword() async {
//     String? password = await PasswordService.getPassword();
//     if (password != null) {
//       _passwordController.text = password;
//     }
//   }

//   void _savePassword() async {
//     String password = _passwordController.text.trim();
//     if (password.isNotEmpty) {
//       await PasswordService.savePassword(password);
//       setState(() {
//         _statusMessage = '🔒 Password saved successfully!';
//       });
//     } else {
//       setState(() {
//         _statusMessage = '❗ Please enter a valid password.';
//       });
//     }
//   }

//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       //drawer: Sidebar(box: widget.box),
//       body: VerticalTabSidebar(box: widget.box),

//       appBar: AppBar(
//         title: const Text('Settings for Doctors'),
//         backgroundColor: Colors.teal,
//         elevation: 2,
//       ),
//       body: Container(
//         decoration: const BoxDecoration(
//           gradient: LinearGradient(
//             colors: [Color(0xFFE8F5E9), Color(0xFFF1F8E9)],
//             begin: Alignment.topLeft,
//             end: Alignment.bottomRight,
//           ),
//         ),
//         child: ListView(
//           padding: const EdgeInsets.all(16),
//           children: [
//             _buildSectionTitle('🧾 Document Settings'),
//             _buildCard([
//               _buildListTile(
//                 icon: Icons.delete_forever_rounded,
//                 title: 'View Deleted Documents',
//                 subtitle: 'Recover or review removed text records',
//                 onTap: () {
//                   Navigator.push(
//                     context,
//                     MaterialPageRoute(
//                       builder: (context) =>
//                           DeletedDocumentsScreen(box: widget.box),
//                     ),
//                   );
//                 },
//               ),
//             ]),
//             const SizedBox(height: 16),
//             _buildSectionTitle('🔐 Security & Preferences'),
//             _buildCard([
//               Padding(
//                 padding: const EdgeInsets.all(12.0),
//                 child: Column(
//                   crossAxisAlignment: CrossAxisAlignment.start,
//                   children: [
//                     const Text(
//                       'Set Password for Saved Records',
//                       style:
//                           TextStyle(fontSize: 16, fontWeight: FontWeight.w600),
//                     ),
//                     const SizedBox(height: 8),
//                     TextField(
//                       controller: _passwordController,
//                       obscureText: true,
//                       decoration: InputDecoration(
//                         labelText: 'Enter secure password',
//                         border: OutlineInputBorder(
//                           borderRadius: BorderRadius.circular(8),
//                         ),
//                         prefixIcon: const Icon(Icons.lock_outline),
//                       ),
//                     ),
//                     const SizedBox(height: 10),
//                     ElevatedButton.icon(
//                       onPressed: _savePassword,
//                       icon: const Icon(Icons.save_alt),
//                       label: const Text('Save Password'),
//                       style: ElevatedButton.styleFrom(
//                         backgroundColor: Colors.teal,
//                         shape: RoundedRectangleBorder(
//                             borderRadius: BorderRadius.circular(10)),
//                       ),
//                     ),
//                     const SizedBox(height: 6),
//                     Text(
//                       _statusMessage,
//                       style: const TextStyle(color: Colors.green),
//                     ),
//                   ],
//                 ),
//               ),
//               const Divider(),
//               SwitchListTile(
//                 title: const Text('Always Use Camera'),
//                 subtitle:
//                     const Text('Skip gallery and directly open camera view'),
//                 value: _alwaysUseCamera,
//                 onChanged: _toggleCameraPreference,
//                 activeColor: Colors.teal,
//                 secondary: const Icon(Icons.camera_alt_outlined),
//               ),
//             ]),
//           ],
//         ),
//       ),
//     );
//   }

//   Widget _buildSectionTitle(String title) {
//     return Padding(
//       padding: const EdgeInsets.symmetric(vertical: 10),
//       child: Text(
//         title,
//         style: const TextStyle(
//           fontSize: 20,
//           fontWeight: FontWeight.bold,
//           color: Colors.teal,
//         ),
//       ),
//     );
//   }

//   Widget _buildCard(List<Widget> children) {
//     return Card(
//       elevation: 6,
//       margin: const EdgeInsets.only(bottom: 12),
//       shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
//       child: Column(children: children),
//     );
//   }

//   Widget _buildListTile({
//     required IconData icon,
//     required String title,
//     required String subtitle,
//     required VoidCallback onTap,
//   }) {
//     return ListTile(
//       leading: CircleAvatar(
//         backgroundColor: Colors.teal.shade50,
//         child: Icon(icon, color: Colors.teal),
//       ),
//       title: Text(title, style: const TextStyle(fontWeight: FontWeight.w600)),
//       subtitle: Text(subtitle),
//       trailing: const Icon(Icons.arrow_forward_ios, size: 16),
//       onTap: onTap,
//     );
//   }
// }

import 'package:flutter/material.dart';
import 'package:hive/hive.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../services/password_service.dart';
import '../models/text_model.dart';
import '../widgets/sidebar.dart';
import 'deleted_documents_screen.dart';

class SettingsScreen extends StatefulWidget {
  final Box<TextModel> box;
  const SettingsScreen({Key? key, required this.box}) : super(key: key);

  @override
  _SettingsScreenState createState() => _SettingsScreenState();
}

class _SettingsScreenState extends State<SettingsScreen> {
  bool _alwaysUseCamera = false;
  final TextEditingController _passwordController = TextEditingController();
  String _statusMessage = '';

  @override
  void initState() {
    super.initState();
    _loadCameraPreference();
    _loadPassword();
  }

  void _loadCameraPreference() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    setState(() {
      _alwaysUseCamera = prefs.getBool('alwaysUseCamera') ?? false;
    });
  }

  void _toggleCameraPreference(bool value) async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    await prefs.setBool('alwaysUseCamera', value);
    setState(() {
      _alwaysUseCamera = value;
    });
  }

  void _loadPassword() async {
    String? password = await PasswordService.getPassword();
    if (password != null) {
      _passwordController.text = password;
    }
  }

  void _savePassword() async {
    String password = _passwordController.text.trim();
    if (password.isNotEmpty) {
      await PasswordService.savePassword(password);
      setState(() {
        _statusMessage = '🔒 Password saved successfully!';
      });
    } else {
      setState(() {
        _statusMessage = '❗ Please enter a valid password.';
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      drawer: Sidebar(box: widget.box), // Sidebar moved here
      appBar: AppBar(
        title: const Text('Settings for Doctors'),
        backgroundColor: Colors.teal,
        elevation: 2,
      ),
      body: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            colors: [Color(0xFFE8F5E9), Color(0xFFF1F8E9)],
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ),
        ),
        child: ListView(
          padding: const EdgeInsets.all(16),
          children: [
            _buildSectionTitle('🧾 Document Settings'),
            _buildCard([ 
              _buildListTile(
                icon: Icons.delete_forever_rounded,
                title: 'View Deleted Documents',
                subtitle: 'Recover or review removed text records',
                onTap: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (context) =>
                          DeletedDocumentsScreen(box: widget.box),
                    ),
                  );
                },
              ),
            ]),
            const SizedBox(height: 16),
            _buildSectionTitle('🔐 Security & Preferences'),
            _buildCard([
              Padding(
                padding: const EdgeInsets.all(12.0),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text(
                      'Set Password for Saved Records',
                      style:
                          TextStyle(fontSize: 16, fontWeight: FontWeight.w600),
                    ),
                    const SizedBox(height: 8),
                    TextField(
                      controller: _passwordController,
                      obscureText: true,
                      decoration: InputDecoration(
                        labelText: 'Enter secure password',
                        border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(8),
                        ),
                        prefixIcon: const Icon(Icons.lock_outline),
                      ),
                    ),
                    const SizedBox(height: 10),
                    ElevatedButton.icon(
                      onPressed: _savePassword,
                      icon: const Icon(Icons.save_alt),
                      label: const Text('Save Password'),
                      style: ElevatedButton.styleFrom(
                        backgroundColor: Colors.teal,
                        shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(10)),
                      ),
                    ),
                    const SizedBox(height: 6),
                    Text(
                      _statusMessage,
                      style: const TextStyle(color: Colors.green),
                    ),
                  ],
                ),
              ),
              const Divider(),
              SwitchListTile(
                title: const Text('Always Use Camera'),
                subtitle:
                    const Text('Skip gallery and directly open camera view'),
                value: _alwaysUseCamera,
                onChanged: _toggleCameraPreference,
                activeColor: Colors.teal,
                secondary: const Icon(Icons.camera_alt_outlined),
              ),
            ]),
          ],
        ),
      ),
    );
  }

  Widget _buildSectionTitle(String title) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 10),
      child: Text(
        title,
        style: const TextStyle(
          fontSize: 20,
          fontWeight: FontWeight.bold,
          color: Colors.teal,
        ),
      ),
    );
  }

  Widget _buildCard(List<Widget> children) {
    return Card(
      elevation: 6,
      margin: const EdgeInsets.only(bottom: 12),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
      child: Column(children: children),
    );
  }

  Widget _buildListTile({
    required IconData icon,
    required String title,
    required String subtitle,
    required VoidCallback onTap,
  }) {
    return ListTile(
      leading: CircleAvatar(
        backgroundColor: Colors.teal.shade50,
        child: Icon(icon, color: Colors.teal),
      ),
      title: Text(title, style: const TextStyle(fontWeight: FontWeight.w600)),
      subtitle: Text(subtitle),
      trailing: const Icon(Icons.arrow_forward_ios, size: 16),
      onTap: onTap,
    );
  }
}

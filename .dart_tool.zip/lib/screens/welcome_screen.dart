// import 'package:flutter/material.dart';

// class WelcomeScreen extends StatelessWidget {
//   final TextEditingController emailController = TextEditingController();
//   final TextEditingController passwordController = TextEditingController();

//   WelcomeScreen({super.key});

//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       backgroundColor: Colors.white,
//       body: Center(
//         child: SingleChildScrollView(
//           padding: const EdgeInsets.all(24),
//           child: Column(
//             mainAxisAlignment: MainAxisAlignment.center,
//             children: [
//               const CircleAvatar(
//                 radius: 50,
//                 backgroundImage: AssetImage('assets/images/doctor.png'), // or use emoji
//               ),
//               const SizedBox(height: 20),
//               const Text(
//                 'Welcome to MediScan',
//                 style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
//               ),
//               const SizedBox(height: 20),
//               const Text(
//                 'Create a profile of your own',
//                 style: TextStyle(fontSize: 16),
//               ),
//               const SizedBox(height: 20),
//               TextField(
//                 controller: emailController,
//                 decoration: const InputDecoration(
//                   labelText: 'Email',
//                   border: OutlineInputBorder(),
//                 ),
//               ),
//               const SizedBox(height: 12),
//               TextField(
//                 controller: passwordController,
//                 obscureText: true,
//                 decoration: const InputDecoration(
//                   labelText: 'New Password',
//                   border: OutlineInputBorder(),
//                 ),
//               ),
//               const SizedBox(height: 16),
//               ElevatedButton(
//                 onPressed: () {
//                   final email = emailController.text.trim();
//                   final password = passwordController.text.trim();
//                   // Save to SharedPreferences or send to backend here
//                   Navigator.pushReplacementNamed(context, '/home');
//                 },
//                 child: const Text('Create Profile'),
//               ),
//               const SizedBox(height: 12),
//               OutlinedButton.icon(
//                 onPressed: () {
//                   // Implement Google sign-in
//                 },
//                 icon: const Icon(Icons.login),
//                 label: const Text('Continue with Google'),
//               )
//             ],
//           ),
//         ),
//       ),
//     );
//   }
// }

// import 'package:flutter/material.dart';
// import 'package:hive/hive.dart';
// import '../models/text_model.dart';
// import 'text_extractor_screen.dart';

// class WelcomeScreen extends StatelessWidget {
//   final Box<TextModel> box;
//   final TextEditingController emailController = TextEditingController();
//   final TextEditingController passwordController = TextEditingController();

//   WelcomeScreen({super.key, required this.box});

//   void _createProfile(BuildContext context) {
//     final email = emailController.text.trim();
//     final password = passwordController.text.trim();

//     if (email.isNotEmpty && password.isNotEmpty) {
//       // TODO: Save email and password to secure storage or preferences
//       Navigator.pushReplacement(
//         context,
//         MaterialPageRoute(builder: (_) => TextExtractorScreen(box: box)),
//       );
//     } else {
//       ScaffoldMessenger.of(context).showSnackBar(
//         const SnackBar(content: Text('Please enter email and password')),
//       );
//     }
//   }

//   void _continueWithGoogle(BuildContext context) {
//     // TODO: Implement actual Google sign-in
//     Navigator.pushReplacement(
//       context,
//       MaterialPageRoute(builder: (_) => TextExtractorScreen(box: box)),
//     );
//   }

//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       backgroundColor: Colors.white,
//       body: Center(
//         child: SingleChildScrollView(
//           padding: const EdgeInsets.all(24),
//           child: Column(
//             mainAxisAlignment: MainAxisAlignment.center,
//             children: [
//               const CircleAvatar(
//                 radius: 50,
//                 backgroundImage: AssetImage('assets/images/doctor.png'),
//               ),
//               const SizedBox(height: 20),
//               const Text(
//                 'Welcome to MediScan',
//                 style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
//               ),
//               const SizedBox(height: 20),
//               const Text(
//                 'Create a profile of your own',
//                 style: TextStyle(fontSize: 16),
//               ),
//               const SizedBox(height: 20),
//               TextField(
//                 controller: emailController,
//                 keyboardType: TextInputType.emailAddress,
//                 decoration: const InputDecoration(
//                   labelText: 'Email',
//                   border: OutlineInputBorder(),
//                 ),
//               ),
//               const SizedBox(height: 12),
//               TextField(
//                 controller: passwordController,
//                 obscureText: true,
//                 decoration: const InputDecoration(
//                   labelText: 'New Password',
//                   border: OutlineInputBorder(),
//                 ),
//               ),
//               const SizedBox(height: 16),
//               ElevatedButton(
//                 onPressed: () => _createProfile(context),
//                 child: const Text('Create Profile'),
//               ),
//               const SizedBox(height: 12),
//               OutlinedButton.icon(
//                 onPressed: () => _continueWithGoogle(context),
//                 icon: const Icon(Icons.login),
//                 label: const Text('Continue with Google'),
//               ),
//             ],
//           ),
//         ),
//       ),
//     );
//   }
// }
// import 'package:flutter/material.dart';
// import 'package:hive/hive.dart';
// import '../models/text_model.dart';
// import 'text_extractor_screen.dart';
// import 'package:google_fonts/google_fonts.dart';

// class WelcomeScreen extends StatelessWidget {
//   final Box<TextModel> box;
//   final TextEditingController emailController = TextEditingController();
//   final TextEditingController passwordController = TextEditingController();

//   WelcomeScreen({super.key, required this.box});

//   // Profile creation
//   void _createProfile(BuildContext context) {
//     final email = emailController.text.trim();
//     final password = passwordController.text.trim();

//     if (email.isNotEmpty && password.isNotEmpty) {
//       // Save email and password to secure storage or preferences
//       Navigator.pushReplacement(
//         context,
//         MaterialPageRoute(builder: (_) => TextExtractorScreen(box: box)),
//       );
//     } else {
//       ScaffoldMessenger.of(context).showSnackBar(
//         const SnackBar(content: Text('Please enter email and password')),
//       );
//     }
//   }

//   // Google sign-in
//   void _continueWithGoogle(BuildContext context) {
//     // TODO: Implement Google Sign-In logic here
//     Navigator.pushReplacement(
//       context,
//       MaterialPageRoute(builder: (_) => TextExtractorScreen(box: box)),
//     );
//   }

//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       backgroundColor: Colors.white,
//       body: Center(
//         child: SingleChildScrollView(
//           padding: const EdgeInsets.all(24),
//           child: Column(
//             mainAxisAlignment: MainAxisAlignment.center,
//             children: [
//               // Doctor Icon (Profile Picture)
//               const CircleAvatar(
//                 radius: 50,
//                 backgroundImage: AssetImage('assets/images/doctor.png'),  // You can customize this
//               ),
//               const SizedBox(height: 20),
//               // Welcome Text
//               Text(
//                 'Welcome to MediScan',
//                 style: GoogleFonts.lato(
//                   fontSize: 24,
//                   fontWeight: FontWeight.bold,
//                   color: Colors.indigo,
//                 ),
//               ),
//               const SizedBox(height: 20),
//               Text(
//                 'Create a profile of your own',
//                 style: GoogleFonts.lato(
//                   fontSize: 16,
//                   color: Colors.grey[600],
//                 ),
//               ),
//               const SizedBox(height: 20),
//               // Email Input
//               TextField(
//                 controller: emailController,
//                 keyboardType: TextInputType.emailAddress,
//                 decoration: const InputDecoration(
//                   labelText: 'Email',
//                   border: OutlineInputBorder(),
//                 ),
//               ),
//               const SizedBox(height: 12),
//               // Password Input
//               TextField(
//                 controller: passwordController,
//                 obscureText: true,
//                 decoration: const InputDecoration(
//                   labelText: 'New Password',
//                   border: OutlineInputBorder(),
//                 ),
//               ),
//               const SizedBox(height: 16),
//               // Create Profile Button
//               ElevatedButton(
//                 onPressed: () => _createProfile(context),
//                 style: ElevatedButton.styleFrom(
//                   primary: Colors.indigo, // Button color
//                   padding: const EdgeInsets.symmetric(vertical: 14),
//                   shape: RoundedRectangleBorder(
//                     borderRadius: BorderRadius.circular(10),
//                   ),
//                 ),
//                 child: const Text('Create Profile'),
//               ),
//               const SizedBox(height: 12),
//               // Continue with Google Button
//               OutlinedButton.icon(
//                 onPressed: () => _continueWithGoogle(context),
//                 icon: const Icon(Icons.login, color: Colors.blue),
//                 label: const Text(
//                   'Continue with Google',
//                   style: TextStyle(color: Colors.blue),
//                 ),
//                 style: OutlinedButton.styleFrom(
//                   padding: const EdgeInsets.symmetric(vertical: 14),
//                   side: const BorderSide(color: Colors.blue),
//                   shape: RoundedRectangleBorder(
//                     borderRadius: BorderRadius.circular(10),
//                   ),
//                 ),
//               ),
//             ],
//           ),
//         ),
//       ),
//     );
//   }
// }


// import 'package:flutter/material.dart';
// import 'package:hive/hive.dart';
// import '../models/text_model.dart';
// import 'text_extractor_screen.dart';
// import 'package:google_fonts/google_fonts.dart';

// class WelcomeScreen extends StatelessWidget {
//   final Box<TextModel> box;
//   final TextEditingController emailController = TextEditingController();
//   final TextEditingController passwordController = TextEditingController();

//   WelcomeScreen({super.key, required this.box});

//   void _createProfile(BuildContext context) {
//     final email = emailController.text.trim();
//     final password = passwordController.text.trim();

//     if (email.isNotEmpty && password.isNotEmpty) {
//       Navigator.pushReplacement(
//         context,
//         MaterialPageRoute(builder: (_) => TextExtractorScreen(box: box)),
//       );
//     } else {
//       ScaffoldMessenger.of(context).showSnackBar(
//         const SnackBar(content: Text('Please enter email and password')),
//       );
//     }
//   }

//   void _continueWithGoogle(BuildContext context) {
//     Navigator.pushReplacement(
//       context,
//       MaterialPageRoute(builder: (_) => TextExtractorScreen(box: box)),
//     );
//   }

//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       body: Container(
//         decoration: const BoxDecoration(
//           gradient: LinearGradient(
//             colors: [Color(0xFFE0F7FA), Color(0xFFB2EBF2)],
//             begin: Alignment.topCenter,
//             end: Alignment.bottomCenter,
//           ),
//         ),
//         child: Center(
//           child: SingleChildScrollView(
//             padding: const EdgeInsets.all(24),
//             child: Column(
//               mainAxisAlignment: MainAxisAlignment.center,
//               children: [
//                 // Profile image
//                 Container(
//                   decoration: BoxDecoration(
//                     shape: BoxShape.circle,
//                     boxShadow: [
//                       BoxShadow(
//                         color: Colors.grey.withOpacity(0.5),
//                         blurRadius: 10,
//                         spreadRadius: 2,
//                         offset: const Offset(0, 5),
//                       ),
//                     ],
//                   ),
//                   child: const CircleAvatar(
//                     radius: 60,
//                     backgroundImage: AssetImage('assets/images/doctor.png'),
//                     backgroundColor: Colors.transparent,
//                   ),
//                 ),
//                 const SizedBox(height: 30),
//                 Text(
//                   'Welcome to MediScan',
//                   style: GoogleFonts.poppins(
//                     fontSize: 28,
//                     fontWeight: FontWeight.bold,
//                     color: Colors.teal[800],
//                   ),
//                 ),
//                 const SizedBox(height: 8),
//                 Text(
//                   'Empowering Doctors with AI Tools',
//                   style: GoogleFonts.poppins(
//                     fontSize: 16,
//                     color: Colors.teal[600],
//                   ),
//                 ),
//                 const SizedBox(height: 30),

//                 // Login card
//                 Card(
//                   elevation: 8,
//                   shape: RoundedRectangleBorder(
//                     borderRadius: BorderRadius.circular(16),
//                   ),
//                   child: Padding(
//                     padding: const EdgeInsets.symmetric(
//                         horizontal: 24, vertical: 30),
//                     child: Column(
//                       children: [
//                         TextField(
//                           controller: emailController,
//                           keyboardType: TextInputType.emailAddress,
//                           decoration: const InputDecoration(
//                             labelText: 'Email',
//                             prefixIcon: Icon(Icons.email),
//                             border: OutlineInputBorder(),
//                           ),
//                         ),
//                         const SizedBox(height: 16),
//                         TextField(
//                           controller: passwordController,
//                           obscureText: true,
//                           decoration: const InputDecoration(
//                             labelText: 'New Password',
//                             prefixIcon: Icon(Icons.lock),
//                             border: OutlineInputBorder(),
//                           ),
//                         ),
//                         const SizedBox(height: 24),
//                         ElevatedButton(
//                           onPressed: () => _createProfile(context),
//                           style: ElevatedButton.styleFrom(
//                             backgroundColor: Colors.teal,
//                             minimumSize: const Size.fromHeight(50),
//                             shape: RoundedRectangleBorder(
//                               borderRadius: BorderRadius.circular(12),
//                             ),
//                           ),
//                           child: const Text('Create Profile'),
//                         ),
//                         const SizedBox(height: 12),
//                         OutlinedButton.icon(
//                           onPressed: () => _continueWithGoogle(context),
//                           icon: const Icon(Icons.login, color: Colors.teal),
//                           label: const Text(
//                             'Continue with Google',
//                             style: TextStyle(color: Colors.teal),
//                           ),
//                           style: OutlinedButton.styleFrom(
//                             minimumSize: const Size.fromHeight(50),
//                             side: const BorderSide(color: Colors.teal),
//                             shape: RoundedRectangleBorder(
//                               borderRadius: BorderRadius.circular(12),
//                             ),
//                           ),
//                         ),
//                       ],
//                     ),
//                   ),
//                 ),
//               ],
//             ),
//           ),
//         ),
//       ),
//     );
//   }
// }

// import 'dart:io';

// import 'package:flutter/material.dart';
// import 'package:google_fonts/google_fonts.dart';
// import 'package:google_sign_in/google_sign_in.dart';
// import 'package:image_picker/image_picker.dart';
// import 'package:hive/hive.dart';

// import '../models/text_model.dart';
// import 'text_extractor_screen.dart';

// class WelcomeScreen extends StatefulWidget {
//   final Box<TextModel> box;

//   const WelcomeScreen({super.key, required this.box});

//   @override
//   State<WelcomeScreen> createState() => _WelcomeScreenState();
// }

// class _WelcomeScreenState extends State<WelcomeScreen> {
//   final TextEditingController emailController = TextEditingController();
//   final TextEditingController passwordController = TextEditingController();
//   final GoogleSignIn _googleSignIn = GoogleSignIn(
//     clientId: '148854509440-kn285oqvob9hn3vku4r0fnm0alnkg93a.apps.googleusercontent.com'
//   );
//   // final account = await _googleSignIn.signIn();

//   File? _profileImage;

//   Future<void> _pickImage() async {
//     final picker = ImagePicker();
//     final pickedFile = await picker.pickImage(source: ImageSource.gallery);

//     if (pickedFile != null) {
//       setState(() {
//         _profileImage = File(pickedFile.path);
//       });
//     }
//   }

//   void _createProfile(BuildContext context) {
//     final email = emailController.text.trim();
//     final password = passwordController.text.trim();

//     if (email.isNotEmpty && password.isNotEmpty) {
//       // TODO: Save credentials securely if needed
//       Navigator.pushReplacement(
//         context,
//         MaterialPageRoute(builder: (_) => TextExtractorScreen(box: widget.box)),
//       );
//     } else {
//       ScaffoldMessenger.of(context).showSnackBar(
//         const SnackBar(content: Text('Please enter email and password')),
//       );
//     }
//   }

//   void _continueWithGoogle(BuildContext context) async {
//     try {
//       final account = await _googleSignIn.signIn();
//       if (account != null) {
//         // You can store user info like account.displayName, account.email, etc.
//         Navigator.pushReplacement(
//           context,
//           MaterialPageRoute(builder: (_) => TextExtractorScreen(box: widget.box)),
//         );
//       } else {
//         ScaffoldMessenger.of(context).showSnackBar(
//           const SnackBar(content: Text('Google Sign-In was cancelled')),
//         );
//       }
//     } catch (error) {
//       ScaffoldMessenger.of(context).showSnackBar(
//         SnackBar(content: Text('Google Sign-In failed: $error')),
//       );
//     }
//   }

//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       body: Container(
//         decoration: const BoxDecoration(
//           gradient: LinearGradient(
//             colors: [Color(0xFFE0F7FA), Color(0xFFB2EBF2)],
//             begin: Alignment.topCenter,
//             end: Alignment.bottomCenter,
//           ),
//         ),
//         child: Center(
//           child: SingleChildScrollView(
//             padding: const EdgeInsets.all(24),
//             child: Column(
//               mainAxisAlignment: MainAxisAlignment.center,
//               children: [
//                 GestureDetector(
//                   onTap: _pickImage,
//                   child: Container(
//                     decoration: BoxDecoration(
//                       shape: BoxShape.circle,
//                       boxShadow: [
//                         BoxShadow(
//                           color: Colors.grey.withOpacity(0.5),
//                           blurRadius: 10,
//                           spreadRadius: 2,
//                           offset: const Offset(0, 5),
//                         ),
//                       ],
//                     ),
//                     child: CircleAvatar(
//                       radius: 60,
//                       backgroundImage: _profileImage != null
//                           ? FileImage(_profileImage!)
//                           : const AssetImage('assets/images/doctor.png') as ImageProvider,
//                       backgroundColor: Colors.transparent,
//                       child: Align(
//                         alignment: Alignment.bottomRight,
//                         child: CircleAvatar(
//                           backgroundColor: Colors.white,
//                           radius: 16,
//                           child: Icon(Icons.edit, size: 18, color: Colors.teal),
//                         ),
//                       ),
//                     ),
//                   ),
//                 ),
//                 const SizedBox(height: 30),
//                 Text(
//                   'Welcome to MediScan',
//                   style: GoogleFonts.poppins(
//                     fontSize: 28,
//                     fontWeight: FontWeight.bold,
//                     color: Colors.teal[800],
//                   ),
//                 ),
//                 const SizedBox(height: 8),
//                 Text(
//                   'Empowering Doctors with AI Tools',
//                   style: GoogleFonts.poppins(
//                     fontSize: 16,
//                     color: Colors.teal[600],
//                   ),
//                 ),
//                 const SizedBox(height: 30),

//                 Card(
//                   elevation: 8,
//                   shape: RoundedRectangleBorder(
//                     borderRadius: BorderRadius.circular(16),
//                   ),
//                   child: Padding(
//                     padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 30),
//                     child: Column(
//                       children: [
//                         TextField(
//                           controller: emailController,
//                           keyboardType: TextInputType.emailAddress,
//                           decoration: const InputDecoration(
//                             labelText: 'Email',
//                             prefixIcon: Icon(Icons.email),
//                             border: OutlineInputBorder(),
//                           ),
//                         ),
//                         const SizedBox(height: 16),
//                         TextField(
//                           controller: passwordController,
//                           obscureText: true,
//                           decoration: const InputDecoration(
//                             labelText: 'New Password',
//                             prefixIcon: Icon(Icons.lock),
//                             border: OutlineInputBorder(),
//                           ),
//                         ),
//                         const SizedBox(height: 24),
//                         ElevatedButton(
//                           onPressed: () => _createProfile(context),
//                           style: ElevatedButton.styleFrom(
//                             backgroundColor: Colors.teal,
//                             minimumSize: const Size.fromHeight(50),
//                             shape: RoundedRectangleBorder(
//                               borderRadius: BorderRadius.circular(12),
//                             ),
//                           ),
//                           child: const Text('Create Profile'),
//                         ),
//                         const SizedBox(height: 12),
//                         OutlinedButton.icon(
//                           onPressed: () => _continueWithGoogle(context),
//                           icon: const Icon(Icons.login, color: Colors.teal),
//                           label: const Text(
//                             'Continue with Google',
//                             style: TextStyle(color: Colors.teal),
//                           ),
//                           style: OutlinedButton.styleFrom(
//                             minimumSize: const Size.fromHeight(50),
//                             side: const BorderSide(color: Colors.teal),
//                             shape: RoundedRectangleBorder(
//                               borderRadius: BorderRadius.circular(12),
//                             ),
//                           ),
//                         ),
//                       ],
//                     ),
//                   ),
//                 ),
//               ],
//             ),
//           ),
//         ),
//       ),
//     );
//   }
// }

// import 'package:flutter/material.dart';
// import 'package:google_fonts/google_fonts.dart';
// import 'package:google_sign_in/google_sign_in.dart';
// import 'package:hive/hive.dart';
// import '../models/text_model.dart';
// import 'text_extractor_screen.dart';
// import 'package:text_digitization_app/services/auth_service.dart';


// class WelcomeScreen extends StatefulWidget {
//   final Box<TextModel> box;

//   const WelcomeScreen({super.key, required this.box});

//   @override
//   State<WelcomeScreen> createState() => _WelcomeScreenState();
// }

// class _WelcomeScreenState extends State<WelcomeScreen> {
//   final TextEditingController emailController = TextEditingController();
//   final TextEditingController passwordController = TextEditingController();

//   // 👇 Replace with your actual web client ID from Google Cloud Console
//   final GoogleSignIn _googleSignIn = GoogleSignIn(
//     clientId: '148854509440-kn285oqvob9hn3vku4r0fnm0alnkg93a.apps.googleusercontent.com',
//   );

//   void _createProfile(BuildContext context) {
//     final email = emailController.text.trim();
//     final password = passwordController.text.trim();

//     if (email.isNotEmpty && password.isNotEmpty) {
//       Navigator.pushReplacement(
//         context,
//         MaterialPageRoute(builder: (_) => TextExtractorScreen(box: widget.box!)),
//       );
//     } else {
//       ScaffoldMessenger.of(context).showSnackBar(
//         const SnackBar(content: Text('Please enter email and password')),
//       );
//     }
//   }

//   Future<void> _continueWithGoogle(BuildContext context) async {
//     try {
//       final account = await _googleSignIn.signIn();
//       if (account != null) {
//         final user = await AuthService().signInWithGoogle();

//         // You can store/display user info like account.email or account.displayName
//         Navigator.pushReplacement(
//           context,
//           MaterialPageRoute(builder: (_) => TextExtractorScreen(box: widget.box)),
//         );
//       } else {
//         ScaffoldMessenger.of(context).showSnackBar(
//           const SnackBar(content: Text('Google Sign-In was cancelled')),
//         );
//       }
//     } catch (error) {
//       ScaffoldMessenger.of(context).showSnackBar(
//         SnackBar(content: Text('Google Sign-In failed: $error')),
//       );
//     }
//   }

//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       body: Container(
//         decoration: const BoxDecoration(
//           gradient: LinearGradient(
//             colors: [Color(0xFFE0F7FA), Color(0xFFB2EBF2)],
//             begin: Alignment.topCenter,
//             end: Alignment.bottomCenter,
//           ),
//         ),
//         child: Center(
//           child: SingleChildScrollView(
//             padding: const EdgeInsets.all(24),
//             child: Column(
//               mainAxisAlignment: MainAxisAlignment.center,
//               children: [
//                 // Profile image
//                 Container(
//                   decoration: BoxDecoration(
//                     shape: BoxShape.circle,
//                     boxShadow: [
//                       BoxShadow(
//                         color: Colors.grey.withOpacity(0.5),
//                         blurRadius: 10,
//                         spreadRadius: 2,
//                         offset: const Offset(0, 5),
//                       ),
//                     ],
//                   ),
//                   child: const CircleAvatar(
//                     radius: 60,
//                     backgroundImage: AssetImage('assets/images/doctor.png'),
//                     backgroundColor: Colors.transparent,
//                   ),
//                 ),
//                 const SizedBox(height: 30),
//                 Text(
//                   'Welcome to MediScan',
//                   style: GoogleFonts.poppins(
//                     fontSize: 28,
//                     fontWeight: FontWeight.bold,
//                     color: Colors.teal[800],
//                   ),
//                 ),
//                 const SizedBox(height: 8),
//                 Text(
//                   'Empowering Doctors with AI Tools',
//                   style: GoogleFonts.poppins(
//                     fontSize: 16,
//                     color: Colors.teal[600],
//                   ),
//                 ),
//                 const SizedBox(height: 30),

//                 // Login card
//                 Card(
//                   elevation: 8,
//                   shape: RoundedRectangleBorder(
//                     borderRadius: BorderRadius.circular(16),
//                   ),
//                   child: Padding(
//                     padding: const EdgeInsets.symmetric(
//                         horizontal: 24, vertical: 30),
//                     child: Column(
//                       children: [
//                         TextField(
//                           controller: emailController,
//                           keyboardType: TextInputType.emailAddress,
//                           decoration: const InputDecoration(
//                             labelText: 'Email',
//                             prefixIcon: Icon(Icons.email),
//                             border: OutlineInputBorder(),
//                           ),
//                         ),
//                         const SizedBox(height: 16),
//                         TextField(
//                           controller: passwordController,
//                           obscureText: true,
//                           decoration: const InputDecoration(
//                             labelText: 'New Password',
//                             prefixIcon: Icon(Icons.lock),
//                             border: OutlineInputBorder(),
//                           ),
//                         ),
//                         const SizedBox(height: 24),
//                         ElevatedButton(
//                           onPressed: () => _createProfile(context),
//                           style: ElevatedButton.styleFrom(
//                             backgroundColor: Colors.teal,
//                             minimumSize: const Size.fromHeight(50),
//                             shape: RoundedRectangleBorder(
//                               borderRadius: BorderRadius.circular(12),
//                             ),
//                           ),
//                           child: const Text('Create Profile'),
//                         ),
//                         const SizedBox(height: 12),
//                         OutlinedButton.icon(
//                           onPressed: () => _continueWithGoogle(context),
//                           icon: const Icon(Icons.login, color: Colors.teal),
//                           label: const Text(
//                             'Continue with Google',
//                             style: TextStyle(color: Colors.teal),
//                           ),
//                           style: OutlinedButton.styleFrom(
//                             minimumSize: const Size.fromHeight(50),
//                             side: const BorderSide(color: Colors.teal),
//                             shape: RoundedRectangleBorder(
//                               borderRadius: BorderRadius.circular(12),
//                             ),
//                           ),
//                         ),
//                       ],
//                     ),
//                   ),
//                 ),
//               ],
//             ),
//           ),
//         ),
//       ),
//     );
//   }
// }


// import 'package:flutter/material.dart';
// import 'package:google_fonts/google_fonts.dart';
// import 'package:google_sign_in/google_sign_in.dart';
// import 'package:hive/hive.dart';
// import '../models/text_model.dart';
// import 'text_extractor_screen.dart';
// import 'package:text_digitization_app/services/auth_service.dart';

// class WelcomeScreen extends StatefulWidget {
//   final Box<TextModel> box;  // Required box parameter

//   const WelcomeScreen({super.key, required this.box});

//   @override
//   State<WelcomeScreen> createState() => _WelcomeScreenState();
// }

// class _WelcomeScreenState extends State<WelcomeScreen> {
//   final TextEditingController emailController = TextEditingController();
//   final TextEditingController passwordController = TextEditingController();

//   final GoogleSignIn _googleSignIn = GoogleSignIn(
//     clientId: '148854509440-kn285oqvob9hn3vku4r0fnm0alnkg93a.apps.googleusercontent.com',
//   );

//   void _createProfile(BuildContext context) {
//     final email = emailController.text.trim();
//     final password = passwordController.text.trim();

//     if (email.isNotEmpty && password.isNotEmpty) {
//       Navigator.pushReplacement(
//         context,
//         MaterialPageRoute(builder: (_) => TextExtractorScreen(box: widget.box)),
//       );
//     } else {
//       ScaffoldMessenger.of(context).showSnackBar(
//         const SnackBar(content: Text('Please enter email and password')),
//       );
//     }
//   }

//   Future<void> _continueWithGoogle(BuildContext context) async {
//     try {
//       final account = await _googleSignIn.signIn();
//       if (account != null) {
//         // Now pass 'box' to the AuthService method
//         final user = await AuthService().signInWithGoogle(box: widget.box);

//         // After signing in, navigate to TextExtractorScreen with the box
//         Navigator.pushReplacement(
//           context,
//           MaterialPageRoute(builder: (_) => TextExtractorScreen(box: widget.box)),
//         );
//       } else {
//         ScaffoldMessenger.of(context).showSnackBar(
//           const SnackBar(content: Text('Google Sign-In was cancelled')),
//         );
//       }
//     } catch (error) {
//       ScaffoldMessenger.of(context).showSnackBar(
//         SnackBar(content: Text('Google Sign-In failed: $error')),
//       );
//     }
//   }

//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       body: Container(
//         decoration: const BoxDecoration(
//           gradient: LinearGradient(
//             colors: [Color(0xFFE0F7FA), Color(0xFFB2EBF2)],
//             begin: Alignment.topCenter,
//             end: Alignment.bottomCenter,
//           ),
//         ),
//         child: Center(
//           child: SingleChildScrollView(
//             padding: const EdgeInsets.all(24),
//             child: Column(
//               mainAxisAlignment: MainAxisAlignment.center,
//               children: [
//                 // Profile image
//                 Container(
//                   decoration: BoxDecoration(
//                     shape: BoxShape.circle,
//                     boxShadow: [
//                       BoxShadow(
//                         color: Colors.grey.withOpacity(0.5),
//                         blurRadius: 10,
//                         spreadRadius: 2,
//                         offset: const Offset(0, 5),
//                       ),
//                     ],
//                   ),
//                   child: const CircleAvatar(
//                     radius: 60,
//                     backgroundImage: AssetImage('assets/images/doctor.png'),
//                     backgroundColor: Colors.transparent,
//                   ),
//                 ),
//                 const SizedBox(height: 30),
//                 Text(
//                   'Welcome to MediScan',
//                   style: GoogleFonts.poppins(
//                     fontSize: 28,
//                     fontWeight: FontWeight.bold,
//                     color: Colors.teal[800],
//                   ),
//                 ),
//                 const SizedBox(height: 8),
//                 Text(
//                   'Empowering Doctors with AI Tools',
//                   style: GoogleFonts.poppins(
//                     fontSize: 16,
//                     color: Colors.teal[600],
//                   ),
//                 ),
//                 const SizedBox(height: 30),

//                 // Login card
//                 Card(
//                   elevation: 8,
//                   shape: RoundedRectangleBorder(
//                     borderRadius: BorderRadius.circular(16),
//                   ),
//                   child: Padding(
//                     padding: const EdgeInsets.symmetric(
//                         horizontal: 24, vertical: 30),
//                     child: Column(
//                       children: [
//                         TextField(
//                           controller: emailController,
//                           keyboardType: TextInputType.emailAddress,
//                           decoration: const InputDecoration(
//                             labelText: 'Email',
//                             prefixIcon: Icon(Icons.email),
//                             border: OutlineInputBorder(),
//                           ),
//                         ),
//                         const SizedBox(height: 16),
//                         TextField(
//                           controller: passwordController,
//                           obscureText: true,
//                           decoration: const InputDecoration(
//                             labelText: 'New Password',
//                             prefixIcon: Icon(Icons.lock),
//                             border: OutlineInputBorder(),
//                           ),
//                         ),
//                         const SizedBox(height: 24),
//                         ElevatedButton(
//                           onPressed: () => _createProfile(context),
//                           style: ElevatedButton.styleFrom(
//                             backgroundColor: Colors.teal,
//                             minimumSize: const Size.fromHeight(50),
//                             shape: RoundedRectangleBorder(
//                               borderRadius: BorderRadius.circular(12),
//                             ),
//                           ),
//                           child: const Text('Create Profile'),
//                         ),
//                         const SizedBox(height: 12),
//                         OutlinedButton.icon(
//                           onPressed: () => _continueWithGoogle(context),
//                           icon: const Icon(Icons.login, color: Colors.teal),
//                           label: const Text(
//                             'Continue with Google',
//                             style: TextStyle(color: Colors.teal),
//                           ),
//                           style: OutlinedButton.styleFrom(
//                             minimumSize: const Size.fromHeight(50),
//                             side: const BorderSide(color: Colors.teal),
//                             shape: RoundedRectangleBorder(
//                               borderRadius: BorderRadius.circular(12),
//                             ),
//                           ),
//                         ),
//                       ],
//                     ),
//                   ),
//                 ),
//               ],
//             ),
//           ),
//         ),
//       ),
//     );
//   }
// }

import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:google_sign_in/google_sign_in.dart';
import 'package:hive/hive.dart';
import '../models/text_model.dart';
import 'text_extractor_screen.dart';
import 'package:text_digitization_app/services/auth_service.dart';
import '../widgets/vertical_tab_sidebar.dart'; // Add this at the top

class WelcomeScreen extends StatefulWidget {
  final Box<TextModel> box;

  const WelcomeScreen({super.key, required this.box});

  @override
  State<WelcomeScreen> createState() => _WelcomeScreenState();
}

class _WelcomeScreenState extends State<WelcomeScreen> {
  final TextEditingController emailController = TextEditingController();
  final TextEditingController passwordController = TextEditingController();

  final GoogleSignIn _googleSignIn = GoogleSignIn(
    clientId: '148854509440-kn285oqvob9hn3vku4r0fnm0alnkg93a.apps.googleusercontent.com',
  );

  void _createProfile(BuildContext context) {
    final email = emailController.text.trim();
    final password = passwordController.text.trim();

    if (email.isNotEmpty && password.isNotEmpty) {
      Navigator.pushReplacement(
        context,
        MaterialPageRoute(builder: (_) => TextExtractorScreen(box: widget.box)),
      );
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Please enter email and password')),
      );
    }
  }

  Future<void> _continueWithGoogle(BuildContext context) async {
    try {
      final account = await _googleSignIn.signIn();
      if (account != null) {
        // Now pass both the context and widget.box
        final user = await AuthService().signInWithGoogle(context, widget.box);

        // Navigate to the TextExtractorScreen after successful sign-in
        Navigator.pushReplacement(
          context,
          MaterialPageRoute(builder: (_) => TextExtractorScreen(box: widget.box)),
        );
      } else {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Google Sign-In was cancelled')),
        );
      }
    } catch (error) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Google Sign-In failed: $error')),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            colors: [Color(0xFFE0F7FA), Color(0xFFB2EBF2)],
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
          ),
        ),
        child: Center(
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(24),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                // Profile image
                Container(
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    boxShadow: [
                      BoxShadow(
                        color: Colors.grey.withOpacity(0.5),
                        blurRadius: 10,
                        spreadRadius: 2,
                        offset: const Offset(0, 5),
                      ),
                    ],
                  ),
                  child: const CircleAvatar(
                    radius: 60,
                    backgroundImage: AssetImage('assets/images/doctor.png'),
                    backgroundColor: Colors.transparent,
                  ),
                ),
                const SizedBox(height: 30),
                Text(
                  'Welcome to MediScan',
                  style: GoogleFonts.poppins(
                    fontSize: 28,
                    fontWeight: FontWeight.bold,
                    color: Colors.teal[800],
                  ),
                ),
                const SizedBox(height: 8),
                Text(
                  'Empowering Doctors with AI Tools',
                  style: GoogleFonts.poppins(
                    fontSize: 16,
                    color: Colors.teal[600],
                  ),
                ),
                const SizedBox(height: 30),

                // Login card
                Card(
                  elevation: 8,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(16),
                  ),
                  child: Padding(
                    padding: const EdgeInsets.symmetric(
                        horizontal: 24, vertical: 30),
                    child: Column(
                      children: [
                        TextField(
                          controller: emailController,
                          keyboardType: TextInputType.emailAddress,
                          decoration: const InputDecoration(
                            labelText: 'Email',
                            prefixIcon: Icon(Icons.email),
                            border: OutlineInputBorder(),
                          ),
                        ),
                        const SizedBox(height: 16),
                        TextField(
                          controller: passwordController,
                          obscureText: true,
                          decoration: const InputDecoration(
                            labelText: 'New Password',
                            prefixIcon: Icon(Icons.lock),
                            border: OutlineInputBorder(),
                          ),
                        ),
                        const SizedBox(height: 24),
                        ElevatedButton(
                          onPressed: () => _createProfile(context),
                          style: ElevatedButton.styleFrom(
                            backgroundColor: Colors.teal,
                            minimumSize: const Size.fromHeight(50),
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(12),
                            ),
                          ),
                          child: const Text('Create Profile'),
                        ),
                        const SizedBox(height: 12),
                        OutlinedButton.icon(
                          onPressed: () => _continueWithGoogle(context),
                          icon: const Icon(Icons.login, color: Colors.teal),
                          label: const Text(
                            'Continue with Google',
                            style: TextStyle(color: Colors.teal),
                          ),
                          style: OutlinedButton.styleFrom(
                            minimumSize: const Size.fromHeight(50),
                            side: const BorderSide(color: Colors.teal),
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(12),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

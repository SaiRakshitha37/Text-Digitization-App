
// import 'package:flutter/material.dart';
// import 'package:hive/hive.dart';
// import 'package:http/http.dart' as http;
// import 'dart:convert';
// import 'package:flutter/services.dart';

// import '../models/text_model.dart';
// import '../services/api_service.dart';
// import '../services/password_service.dart';
// import '../widgets/sidebar.dart';

// class SavedDocumentsScreen extends StatefulWidget {
//   final Box<TextModel> box;

//   const SavedDocumentsScreen({Key? key, required this.box}) : super(key: key);

//   @override
//   _SavedDocumentsScreenState createState() => _SavedDocumentsScreenState();
// }

// class _SavedDocumentsScreenState extends State<SavedDocumentsScreen> {
//   List<TextModel> _texts = [];
//   List<TextModel> _filteredTexts = [];
//   late TextEditingController _searchController;

//   @override
//   void initState() {
//     super.initState();
//     _searchController = TextEditingController();
//     _verifyPasswordAndLoad();
//   }

//   Future<void> _verifyPasswordAndLoad() async {
//     final savedPassword = await PasswordService.getPassword();
//     if (savedPassword == null || savedPassword.isEmpty) {
//       _loadTextsFromServer();
//       return;
//     }

//     final controller = TextEditingController();
//     bool verified = false;

//     await showDialog(
//       barrierDismissible: false,
//       context: context,
//       builder: (context) {
//         return AlertDialog(
//           title: const Text('Enter Password'),
//           content: TextField(
//             controller: controller,
//             obscureText: true,
//             decoration: const InputDecoration(hintText: 'App password'),
//           ),
//           actions: [
//             TextButton(
//               onPressed: () => Navigator.pop(context),
//               child: const Text('Cancel'),
//             ),
//             ElevatedButton(
//               onPressed: () {
//                 if (controller.text.trim() == savedPassword) {
//                   verified = true;
//                   Navigator.pop(context);
//                 } else {
//                   ScaffoldMessenger.of(context).showSnackBar(
//                     const SnackBar(content: Text('Incorrect password')),
//                   );
//                 }
//               },
//               child: const Text('Submit'),
//             ),
//           ],
//         );
//       },
//     );

//     if (verified) {
//       _loadTextsFromServer();
//     } else {
//       Navigator.pop(context);
//     }
//   }

//   Future<void> _loadTextsFromServer() async {
//     final response = await http.get(Uri.parse(ApiService.getSavedTextsUrl()));

//     if (response.statusCode == 200) {
//       final List<dynamic> data = json.decode(response.body);
//       setState(() {
//         _texts = data.map((json) => TextModel.fromJson(json)).where((t) => !t.isDeleted).toList();
//         _filteredTexts = List.from(_texts);
//       });
//     } else {
//       ScaffoldMessenger.of(context).showSnackBar(
//         const SnackBar(content: Text('Failed to load texts')),
//       );
//     }
//   }

//   void _searchDocuments(String query) {
//     final filtered = _texts.where((text) {
//       final titleLower = text.name.toLowerCase();
//       final queryLower = query.toLowerCase();
//       return titleLower.contains(queryLower);
//     }).toList();

//     setState(() {
//       _filteredTexts = filtered;
//     });
//   }

//   void _copyText(TextModel text) {
//     Clipboard.setData(ClipboardData(text: text.content));
//     ScaffoldMessenger.of(context).showSnackBar(
//       const SnackBar(content: Text('Text copied to clipboard')),
//     );
//   }

//   void _deleteText(int index) {
//     showDialog(
//       context: context,
//       builder: (_) => AlertDialog(
//         title: const Text("Delete Document"),
//         content: const Text("Are you sure you want to delete this document?"),
//         actions: [
//           TextButton(
//             onPressed: () => Navigator.pop(context),
//             child: const Text("Cancel"),
//           ),
//           ElevatedButton(
//             onPressed: () async {
//               final textToDelete = _filteredTexts[index];

//               setState(() {
//                 textToDelete.isDeleted = true;
//                 textToDelete.save();
//                 widget.box.put(textToDelete.name, textToDelete);

//                 _texts.removeWhere((t) => t.name == textToDelete.name);
//                 _filteredTexts.removeAt(index);
//               });

//               Navigator.pop(context);
//               ScaffoldMessenger.of(context).showSnackBar(
//                 const SnackBar(content: Text('Document deleted')),
//               );
//             },
//             child: const Text("Delete"),
//           ),
//         ],
//       ),
//     );
//   }

//   void _renameText(int index) {
//     final controller = TextEditingController(text: _filteredTexts[index].name);
//     showDialog(
//       context: context,
//       builder: (_) => AlertDialog(
//         title: const Text("Rename Document"),
//         content: TextField(
//           controller: controller,
//           decoration: const InputDecoration(hintText: "New document name"),
//         ),
//         actions: [
//           TextButton(onPressed: () => Navigator.pop(context), child: const Text("Cancel")),
//           ElevatedButton(
//             onPressed: () {
//               setState(() {
//                 final newName = controller.text;
//                 final oldName = _filteredTexts[index].name;

//                 _filteredTexts[index].name = newName;
//                 final text = _texts.firstWhere((t) => t.name == oldName);
//                 text.name = newName;

//                 text.save();
//                 widget.box.put(newName, text);
//               });
//               Navigator.pop(context);
//               ScaffoldMessenger.of(context).showSnackBar(
//                 const SnackBar(content: Text('Document renamed')),
//               );
//             },
//             child: const Text("Save"),
//           ),
//         ],
//       ),
//     );
//   }

//   void _editText(int index) {
//     final controller = TextEditingController(text: _filteredTexts[index].content);
//     showDialog(
//       context: context,
//       builder: (_) => AlertDialog(
//         title: const Text("Edit Content"),
//         content: TextField(
//           controller: controller,
//           maxLines: 10,
//           decoration: const InputDecoration(hintText: "Edit document content"),
//         ),
//         actions: [
//           TextButton(onPressed: () => Navigator.pop(context), child: const Text("Cancel")),
//           ElevatedButton(
//             onPressed: () {
//               setState(() {
//                 final newContent = controller.text;
//                 _filteredTexts[index].content = newContent;

//                 final text = _texts.firstWhere((t) => t.name == _filteredTexts[index].name);
//                 text.content = newContent;
//                 text.save();
//               });
//               Navigator.pop(context);
//               ScaffoldMessenger.of(context).showSnackBar(
//                 const SnackBar(content: Text('Content updated')),
//               );
//             },
//             child: const Text("Save"),
//           ),
//         ],
//       ),
//     );
//   }

//   @override
//   void dispose() {
//     _searchController.dispose();
//     super.dispose();
//   }

//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       drawer: Sidebar(box: widget.box),
//       appBar: AppBar(
//         title: const Text('Saved Documents'),
//         backgroundColor: Colors.lightBlue.shade700,
//       ),
//       body: Container(
//         color: Colors.blue.shade50,
//         padding: const EdgeInsets.all(16.0),
//         child: Column(
//           children: [
//             TextField(
//               controller: _searchController,
//               onChanged: _searchDocuments,
//               decoration: InputDecoration(
//                 prefixIcon: const Icon(Icons.search),
//                 hintText: 'Search documents...',
//                 filled: true,
//                 fillColor: Colors.white,
//                 border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
//               ),
//             ),
//             const SizedBox(height: 16),
//             Expanded(
//               child: _filteredTexts.isEmpty
//                   ? const Center(child: Text('No documents found.'))
//                   : ListView.builder(
//                       itemCount: _filteredTexts.length,
//                       itemBuilder: (context, index) {
//                         final text = _filteredTexts[index];
//                         return Card(
//                           shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
//                           elevation: 4,
//                           margin: const EdgeInsets.symmetric(vertical: 8),
//                           child: ListTile(
//                             title: Text(
//                               text.name,
//                               style: const TextStyle(fontWeight: FontWeight.bold),
//                             ),
//                             subtitle: Text(
//                               text.content.length > 100
//                                   ? '${text.content.substring(0, 100)}...'
//                                   : text.content,
//                             ),
//                             trailing: PopupMenuButton<String>(
//                               onSelected: (value) {
//                                 switch (value) {
//                                   case 'Edit':
//                                     _editText(index);
//                                     break;
//                                   case 'Rename':
//                                     _renameText(index);
//                                     break;
//                                   case 'Copy':
//                                     _copyText(text);
//                                     break;
//                                   case 'Delete':
//                                     _deleteText(index);
//                                     break;
//                                 }
//                               },
//                               itemBuilder: (context) => [
//                                 const PopupMenuItem(value: 'Edit', child: Text('Edit')),
//                                 const PopupMenuItem(value: 'Rename', child: Text('Rename')),
//                                 const PopupMenuItem(value: 'Copy', child: Text('Copy')),
//                                 const PopupMenuItem(value: 'Delete', child: Text('Delete')),
//                               ],
//                             ),
//                           ),
//                         );
//                       },
//                     ),
//             ),
//           ],
//         ),
//       ),
//     );
//   }
// }


import 'package:flutter/material.dart';
import 'package:hive/hive.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'package:flutter/services.dart';

import '../models/text_model.dart';
import '../services/api_service.dart';
import '../services/password_service.dart';
import '../widgets/sidebar.dart';

class SavedDocumentsScreen extends StatefulWidget {
  final Box<TextModel> box;

  const SavedDocumentsScreen({Key? key, required this.box}) : super(key: key);

  @override
  _SavedDocumentsScreenState createState() => _SavedDocumentsScreenState();
}

class _SavedDocumentsScreenState extends State<SavedDocumentsScreen> {
  List<TextModel> _texts = [];
  List<TextModel> _filteredTexts = [];
  late TextEditingController _searchController;

  @override
  void initState() {
    super.initState();
    _searchController = TextEditingController();
    _verifyPasswordAndLoad();
  }

  Future<void> _verifyPasswordAndLoad() async {
    final savedPassword = await PasswordService.getPassword();
    if (savedPassword == null || savedPassword.isEmpty) {
      _loadTextsFromServer();
      return;
    }

    final controller = TextEditingController();
    bool verified = false;

    await showDialog(
      barrierDismissible: false,
      context: context,
      builder: (context) {
        return AlertDialog(
          title: const Text('Enter Password'),
          content: TextField(
            controller: controller,
            obscureText: true,
            decoration: const InputDecoration(hintText: 'App password'),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context),
              child: const Text('Cancel'),
            ),
            ElevatedButton(
              onPressed: () {
                if (controller.text.trim() == savedPassword) {
                  verified = true;
                  Navigator.pop(context);
                } else {
                  ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(content: Text('Incorrect password')),
                  );
                }
              },
              child: const Text('Submit'),
            ),
          ],
        );
      },
    );

    if (verified) {
      _loadTextsFromServer();
    } else {
      Navigator.pop(context);
    }
  }

  Future<void> _loadTextsFromServer() async {
    final response = await http.get(Uri.parse(ApiService.getSavedTextsUrl()));

    if (response.statusCode == 200) {
      final List<dynamic> data = json.decode(response.body);
      setState(() {
        _texts = data.map((json) => TextModel.fromJson(json)).toList();
        _filteredTexts = List.from(_texts);
      });
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Failed to load texts')),
      );
    }
  }

  void _searchDocuments(String query) {
    final filtered = _texts.where((text) {
      final titleLower = text.name.toLowerCase();
      final queryLower = query.toLowerCase();
      return titleLower.contains(queryLower);
    }).toList();

    setState(() {
      _filteredTexts = filtered;
    });
  }

  void _copyText(TextModel text) {
    Clipboard.setData(ClipboardData(text: text.content));
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('Text copied to clipboard')),
    );
  }

  void _deleteText(int filteredIndex) async {
    final textToDelete = _filteredTexts[filteredIndex];
    final realIndex = _texts.indexWhere((t) => t.name == textToDelete.name);

    final confirmed = await showDialog<bool>(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text("Delete Document"),
        content: const Text("Are you sure you want to delete this document?"),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, false),
            child: const Text("Cancel"),
          ),
          ElevatedButton(
            onPressed: () => Navigator.pop(context, true),
            child: const Text("Delete"),
          ),
        ],
      ),
    );

    if (confirmed == true) {
      setState(() {
        _texts.removeAt(realIndex);
        _filteredTexts.removeAt(filteredIndex);
      });

      // Optionally delete from Hive box (by key or custom logic)
      await widget.box.delete(textToDelete.name);

      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Document deleted')),
      );
    }
  }

  void _renameText(int index) {
    final controller = TextEditingController(text: _filteredTexts[index].name);
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text("Rename Document"),
        content: TextField(
          controller: controller,
          decoration: const InputDecoration(hintText: "New document name"),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context), child: const Text("Cancel")),
          ElevatedButton(
            onPressed: () {
              setState(() {
                _filteredTexts[index].name = controller.text;
                final realIndex = _texts.indexWhere((t) => t.name == _filteredTexts[index].name);
                if (realIndex != -1) {
                  _texts[realIndex].name = controller.text;
                }
              });
              Navigator.pop(context);
              ScaffoldMessenger.of(context).showSnackBar(
                const SnackBar(content: Text('Document renamed')),
              );
            },
            child: const Text("Save"),
          ),
        ],
      ),
    );
  }

  void _editText(int index) {
    final controller = TextEditingController(text: _filteredTexts[index].content);
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text("Edit Text"),
        content: TextField(
          controller: controller,
          maxLines: 10,
          decoration: const InputDecoration(hintText: "Edit your text here"),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context), child: const Text("Cancel")),
          ElevatedButton(
            onPressed: () {
              setState(() {
                _filteredTexts[index].content = controller.text;
                final realIndex = _texts.indexWhere((t) => t.name == _filteredTexts[index].name);
                if (realIndex != -1) {
                  _texts[realIndex].content = controller.text;
                }
              });
              Navigator.pop(context);
              ScaffoldMessenger.of(context).showSnackBar(
                const SnackBar(content: Text('Document updated')),
              );
            },
            child: const Text("Save"),
          ),
        ],
      ),
    );
  }

  @override
  void dispose() {
    _searchController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      drawer: Sidebar(box: widget.box),
      appBar: AppBar(
        title: const Text('Saved Documents'),
        backgroundColor: Colors.lightBlue.shade700,
      ),
      body: Container(
        color: Colors.blue.shade50,
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            TextField(
              controller: _searchController,
              onChanged: _searchDocuments,
              decoration: InputDecoration(
                prefixIcon: const Icon(Icons.search),
                hintText: 'Search documents...',
                filled: true,
                fillColor: Colors.white,
                border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
              ),
            ),
            const SizedBox(height: 16),
            Expanded(
              child: _filteredTexts.isEmpty
                  ? const Center(child: Text('No documents found.'))
                  : ListView.builder(
                      itemCount: _filteredTexts.length,
                      itemBuilder: (context, index) {
                        final text = _filteredTexts[index];
                        return Card(
                          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
                          elevation: 4,
                          margin: const EdgeInsets.symmetric(vertical: 8),
                          child: ListTile(
                            title: Text(
                              text.name,
                              style: const TextStyle(fontWeight: FontWeight.bold),
                            ),
                            subtitle: Text(
                              text.content.length > 100
                                  ? '${text.content.substring(0, 100)}...'
                                  : text.content,
                            ),
                            trailing: PopupMenuButton<String>(
                              onSelected: (value) {
                                switch (value) {
                                  case 'Edit':
                                    _editText(index);
                                    break;
                                  case 'Rename':
                                    _renameText(index);
                                    break;
                                  case 'Copy':
                                    _copyText(text);
                                    break;
                                  case 'Delete':
                                    _deleteText(index);
                                    break;
                                }
                              },
                              itemBuilder: (context) => [
                                const PopupMenuItem(value: 'Edit', child: Text('Edit')),
                                const PopupMenuItem(value: 'Rename', child: Text('Rename')),
                                const PopupMenuItem(value: 'Copy', child: Text('Copy')),
                                const PopupMenuItem(value: 'Delete', child: Text('Delete')),
                              ],
                            ),
                          ),
                        );
                      },
                    ),
            ),
          ],
        ),
      ),
    );
  }
}

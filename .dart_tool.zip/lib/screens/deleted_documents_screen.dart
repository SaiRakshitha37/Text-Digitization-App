// import 'package:flutter/material.dart';
// //import 'package:hive/hive.dart';
// import '../models/text_model.dart';
// import 'package:hive_flutter/hive_flutter.dart';

// class DeletedDocumentsScreen extends StatelessWidget {
//   final Box<TextModel> box;

//   const DeletedDocumentsScreen({super.key, required this.box});

//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       appBar: AppBar(title: const Text('Deleted Documents')),

//       // 👇 Replace the old ListView.builder with this:
//       body: ValueListenableBuilder(
//         valueListenable: box.listenable(),
//         builder: (context, Box<TextModel> updatedBox, _) {
//           final deletedDocs = updatedBox.values.where((doc) => doc.isDeleted).toList();

//           if (deletedDocs.isEmpty) {
//             return const Center(
//               child: Text('No deleted documents found.'),
//             );
//           }

//           return ListView.builder(
//             itemCount: deletedDocs.length,
//             itemBuilder: (context, index) {
//               final doc = deletedDocs[index];
//               return ListTile(
//                 title: Text(doc.name),
//                 subtitle: Text(
//                   doc.content.length > 100 ? '${doc.content.substring(0, 100)}...' : doc.content,
//                 ),
//                 trailing: IconButton(
//                   icon: const Icon(Icons.restore),
//                   onPressed: () async {
//                     doc.isDeleted = false;
//                     await doc.save();
//                     ScaffoldMessenger.of(context).showSnackBar(
//                       const SnackBar(content: Text('Document restored')),
//                     );
//                   },
//                 ),
//               );
//             },
//           );
//         },
//       ),
//     );
//   }
// }


import 'package:flutter/material.dart';
import 'package:hive_flutter/hive_flutter.dart';
import '../models/text_model.dart';

class DeletedDocumentsScreen extends StatelessWidget {
  final Box<TextModel> box;

  const DeletedDocumentsScreen({super.key, required this.box});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Deleted Documents')),

      body: ValueListenableBuilder(
        valueListenable: box.listenable(),
        builder: (context, Box<TextModel> updatedBox, _) {
          final deletedDocs = updatedBox.values.where((doc) => doc.isDeleted).toList();

          if (deletedDocs.isEmpty) {
            return const Center(
              child: Text('No deleted documents found.'),
            );
          }

          return ListView.builder(
            itemCount: deletedDocs.length,
            itemBuilder: (context, index) {
              final doc = deletedDocs[index];
              return ListTile(
                title: Text(doc.name),
                subtitle: Text(
                  doc.content.length > 100 ? '${doc.content.substring(0, 100)}...' : doc.content,
                ),
                trailing: IconButton(
                  icon: const Icon(Icons.restore),
                  onPressed: () async {
                    doc.isDeleted = false;
                    await doc.save();  // Restore the document by setting isDeleted = false
                    ScaffoldMessenger.of(context).showSnackBar(
                      const SnackBar(content: Text('Document restored')),
                    );
                  },
                ),
              );
            },
          );
        },
      ),
    );
  }
}


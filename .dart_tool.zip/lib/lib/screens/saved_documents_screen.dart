import 'package:flutter/material.dart';
import 'package:hive_flutter/hive_flutter.dart';
import '../models/text_model.dart';
import '../utils/hive_boxes.dart';
import 'package:intl/intl.dart';

class SavedDocumentsScreen extends StatelessWidget {
  const SavedDocumentsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final textBox = HiveBoxes.getTexts();

    return Scaffold(
      appBar: AppBar(
        title: const Text('Saved Documents'),
      ),
      body: ValueListenableBuilder<Box<TextModel>>(
        valueListenable: textBox.listenable(),
        builder: (context, box, _) {
          final texts = box.values.toList().cast<TextModel>();

          if (texts.isEmpty) {
            return const Center(child: Text('No saved documents found.'));
          }

          return ListView.builder(
            itemCount: texts.length,
            itemBuilder: (context, index) {
              final item = texts[index];
              return Card(
                margin: const EdgeInsets.all(8),
                elevation: 2,
                child: ListTile(
                  title: Text(item.content),
                  subtitle: Text(
                    'Saved on: ${DateFormat.yMMMd().add_jm().format(item.dateTime)}',
                  ),
                  trailing: IconButton(
                    icon: const Icon(Icons.delete, color: Colors.red),
                    onPressed: () {
                      item.delete(); // Delete from Hive
                    },
                  ),
                ),
              );
            },
          );
        },
      ),
    );
  }
}

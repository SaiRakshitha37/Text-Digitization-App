import 'package:flutter/material.dart';
import '../screens/saved_documents_screen.dart';

class Sidebar extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Drawer(
      child: ListView(
        padding: EdgeInsets.zero,
        children: [
          DrawerHeader(
            decoration: BoxDecoration(color: Colors.deepPurple),
            child: Text('Menu', style: TextStyle(color: Colors.white, fontSize: 24)),
          ),
          ListTile(
            title: Text('View Saved Content'),
            onTap: () {
              Navigator.push(
                context,
                MaterialPageRoute(builder:(_)  => SavedDocumentsScreen()),
              );
            },
          ),
        ],
      ),
    );
  }
}

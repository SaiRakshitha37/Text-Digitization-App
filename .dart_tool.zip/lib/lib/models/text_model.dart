import 'package:hive/hive.dart';

part 'text_model.g.dart';

@HiveType(typeId: 0)
class TextModel extends HiveObject {
  @HiveField(0)
  String content;

  @HiveField(1)
  DateTime dateTime;

  TextModel({required this.content, required this.dateTime});
}

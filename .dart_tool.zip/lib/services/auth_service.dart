// import 'package:firebase_auth/firebase_auth.dart';
// import 'package:google_sign_in/google_sign_in.dart';

// class AuthService {
//   final FirebaseAuth _auth = FirebaseAuth.instance;

//   Future<User?> signInWithGoogle() async {
//     final GoogleSignInAccount? googleUser = await GoogleSignIn().signIn();
//     if (googleUser == null) return null;

//     final GoogleSignInAuthentication googleAuth = await googleUser.authentication;

//     final credential = GoogleAuthProvider.credential(
//       accessToken: googleAuth.accessToken,
//       idToken: googleAuth.idToken,
//     );

//     UserCredential userCredential = await _auth.signInWithCredential(credential);
//     return userCredential.user;
//   }

//   User? get currentUser => _auth.currentUser;

//   Future<void> signOut() async {
//     await _auth.signOut();
//   }
// }


// import 'package:firebase_auth/firebase_auth.dart';
// import 'package:cloud_firestore/cloud_firestore.dart';
// import 'package:google_sign_in/google_sign_in.dart';
// import 'package:shared_preferences/shared_preferences.dart';


// class AuthService {
//   final FirebaseAuth _auth = FirebaseAuth.instance;
//   final FirebaseFirestore _firestore = FirebaseFirestore.instance;

//   Future<User?> signInWithGoogle() async {
//     try {
//       final GoogleSignInAccount? googleUser = await GoogleSignIn().signIn();
//       if (googleUser == null) return null;

//       final GoogleSignInAuthentication googleAuth = await googleUser.authentication;
//       final credential = GoogleAuthProvider.credential(
//         accessToken: googleAuth.accessToken,
//         idToken: googleAuth.idToken,
//       );

//       UserCredential userCredential = await _auth.signInWithCredential(credential);
//       User? user = userCredential.user;

//       if (user != null) {
//         await _firestore.collection('users').doc(user.uid).set({
//           'uid': user.uid,
//           'name': user.displayName,
//           'email': user.email,
//           'photoUrl': user.photoURL,
//           'lastSignIn': FieldValue.serverTimestamp(),
//         }, SetOptions(merge: true));

//         await saveUserInfoLocally(user);
//       }

//       return user;
//     } catch (e) {
//       print("Google Sign-In Error: $e");
//       return null;
//     }
//   }

//   // 🧠 Make sure saveUserInfoLocally is also inside the class or above it
//   Future<void> saveUserInfoLocally(User user) async {
//     final prefs = await SharedPreferences.getInstance();
//     await prefs.setString('email', user.email ?? '');
//     await prefs.setString('name', user.displayName ?? '');
//     await prefs.setString('photoUrl', user.photoURL ?? '');
//     print("Email: ${user.email}");
//     print("Name: ${user.displayName}");
//     print("Photo URL: ${user.photoURL}");
//   }
// }


// import 'package:firebase_auth/firebase_auth.dart';
// import 'package:google_sign_in/google_sign_in.dart';
// import 'package:shared_preferences/shared_preferences.dart';
// import 'package:flutter/material.dart';
// import 'package:text_digitization_app/screens/welcome_screen.dart';

// class AuthService {
//   final FirebaseAuth _auth = FirebaseAuth.instance;
//   final GoogleSignIn _googleSignIn = GoogleSignIn();

//   // Method to sign in with Google and store user info in SharedPreferences
//   Future<void> signInWithGoogle(BuildContext context) async {
//     try {
//       final GoogleSignInAccount? googleUser = await _googleSignIn.signIn();
//       final GoogleSignInAuthentication googleAuth = await googleUser!.authentication;

//       final AuthCredential credential = GoogleAuthProvider.credential(
//         accessToken: googleAuth.accessToken,
//         idToken: googleAuth.idToken,
//       );

//       final UserCredential userCredential = await _auth.signInWithCredential(credential);
//       final user = userCredential.user;

//       if (user != null) {
//         // Store the user's email, name, and first letter of the name for avatar in SharedPreferences
//         SharedPreferences prefs = await SharedPreferences.getInstance();
//         await prefs.setString('email', user.email ?? 'No Email');
//         await prefs.setString('name', user.displayName ?? 'No Name');
        
//         // Get the first letter of the name for the avatar
//         String firstLetter = (user.displayName != null && user.displayName!.isNotEmpty)
//             ? user.displayName![0].toUpperCase()
//             : 'U';  // Default to 'U' for unknown if the name is empty

//         // Store the first letter in SharedPreferences for the avatar
//         await prefs.setString('avatar', firstLetter);

//         // Navigate to the Welcome screen after successful sign-in
//         Navigator.pushReplacement(
//           context,
//           MaterialPageRoute(builder: (context) => WelcomeScreen()),
//         );
//       }
//     } catch (e) {
//       print('Google Sign-In Error: $e'); // Handle errors
//     }
//   }

//   // Sign out method to handle user sign out
//   Future<void> signOut() async {
//     try {
//       await _googleSignIn.signOut();
//       await _auth.signOut();
//     } catch (e) {
//       print('Sign Out Error: $e');
//     }
//   }
// }

import 'package:firebase_auth/firebase_auth.dart';
import 'package:google_sign_in/google_sign_in.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:flutter/material.dart';
import 'package:text_digitization_app/screens/welcome_screen.dart';
import 'package:hive/hive.dart';
import 'package:text_digitization_app/models/text_model.dart';

class AuthService {
  final FirebaseAuth _auth = FirebaseAuth.instance;
  final GoogleSignIn _googleSignIn = GoogleSignIn();

  // Method to sign in with Google and store user info in SharedPreferences
  Future<void> signInWithGoogle(BuildContext context, Box<TextModel> box) async {
    try {
      final GoogleSignInAccount? googleUser = await _googleSignIn.signIn();
      final GoogleSignInAuthentication googleAuth = await googleUser!.authentication;

      final AuthCredential credential = GoogleAuthProvider.credential(
        accessToken: googleAuth.accessToken,
        idToken: googleAuth.idToken,
      );

      final UserCredential userCredential = await _auth.signInWithCredential(credential);
      final user = userCredential.user;

      if (user != null) {
        // Store the user's email, name, and first letter of the name for avatar in SharedPreferences
        SharedPreferences prefs = await SharedPreferences.getInstance();
        await prefs.setString('email', user.email ?? 'No Email');
        await prefs.setString('name', user.displayName ?? 'No Name');
        
        // Get the first letter of the name for the avatar
        String firstLetter = (user.displayName != null && user.displayName!.isNotEmpty)
            ? user.displayName![0].toUpperCase()
            : 'U';  // Default to 'U' for unknown if the name is empty

        // Store the first letter in SharedPreferences for the avatar
        await prefs.setString('avatar', firstLetter);

        // Navigate to the Welcome screen after successful sign-in
        Navigator.pushReplacement(
          context,
          MaterialPageRoute(builder: (context) => WelcomeScreen(box: box)),
        );
      }
    } catch (e) {
      print('Google Sign-In Error: $e'); // Handle errors
    }
  }

  // Sign out method to handle user sign out
  Future<void> signOut() async {
    try {
      await _googleSignIn.signOut();
      await _auth.signOut();
    } catch (e) {
      print('Sign Out Error: $e');
    }
  }
}

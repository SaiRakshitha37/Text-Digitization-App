// import 'dart:async';
// import 'dart:io' show Platform;
// import 'package:flutter/foundation.dart' show kIsWeb;
// import 'package:flutter/material.dart';
// import 'package:hive/hive.dart';
// import 'package:hive_flutter/hive_flutter.dart';
// import 'package:path_provider/path_provider.dart';
// import 'package:google_fonts/google_fonts.dart';
// import 'screens/text_extractor_screen.dart';
// import 'models/text_model.dart';
// import 'screens/welcome_screen.dart';

// Future<Box<TextModel>> _initializeHive() async {
//   if (!kIsWeb) {
//     final appDocDir = await getApplicationDocumentsDirectory();
//     await Hive.initFlutter(appDocDir.path);
//     debugPrint('Hive initialized for native at: ${appDocDir.path}');
//   } else {
//     await Hive.initFlutter();
//     debugPrint('Hive initialized for web');
//   }
//   Hive.registerAdapter(TextModelAdapter());
//   final box = await Hive.openBox<TextModel>('text_model');
//   debugPrint('Box opened, size: ${box.length}');
//   if (box.isNotEmpty) {
//     for (var i = 0; i < box.length; i++) {
//       final item = box.getAt(i);
//       debugPrint(
//           'Document $i: name=${item?.name}, content=${item?.content}, date=${item?.dateTime}');
//     }
//   } else {
//     debugPrint('Box is empty on startup');
//   }
//   return box;
// }

// void main() async {
//   WidgetsFlutterBinding.ensureInitialized();
//   final boxFuture = _initializeHive();

//   runApp(
//     FutureBuilder<Box<TextModel>>(
//       future: boxFuture,
//       builder: (context, snapshot) {
//         if (snapshot.connectionState == ConnectionState.done) {
//           if (snapshot.hasError) {
//             debugPrint('Hive initialization error: ${snapshot.error}');
//             return MaterialApp(
//               home: Scaffold(
//                 body: Center(
//                     child: Text('Error initializing Hive: ${snapshot.error}')),
//               ),
//             );
//           }
//           return MediScanApp(box: snapshot.data!);
//         }
//         return const MaterialApp(
//           home: Scaffold(
//             body: Center(child: CircularProgressIndicator()),
//           ),
//         );
//       },
//     ),
//   );
// }

// class MediScanApp extends StatelessWidget {
//   final Box<TextModel> box;
//   const MediScanApp({super.key, required this.box});

//   @override
//   Widget build(BuildContext context) {
//     return MaterialApp(
//       title: 'MediScan',
//       debugShowCheckedModeBanner: false,
//       theme: ThemeData(
//         primarySwatch: Colors.indigo,
//         textTheme: GoogleFonts.notoSansTextTheme(
//           Theme.of(context).textTheme,
//         ),
//       ),
//       home: SplashScreen(box: box),
//     );
//   }
// }

// class SplashScreen extends StatefulWidget {
//   final Box<TextModel> box;
//   const SplashScreen({super.key, required this.box});

//   @override
//   State<SplashScreen> createState() => _SplashScreenState();
// }

// class _SplashScreenState extends State<SplashScreen>
//     with TickerProviderStateMixin {
//   late AnimationController _dropController;
//   late Animation<Offset> _logoDrop;
//   late AnimationController _fadeController;
//   late Animation<double> _fadeIn;
//   late AnimationController _scanController;
//   double _scanY = 0;
//   late AnimationController _bgController;
//   late Animation<Color?> _bgColor;

//   @override
//   void initState() {
//     super.initState();
//     _dropController = AnimationController(
//       duration: const Duration(milliseconds: 900),
//       vsync: this,
//     );
//     _logoDrop = Tween<Offset>(
//       begin: const Offset(0, -2),
//       end: Offset.zero,
//     ).animate(
//         CurvedAnimation(parent: _dropController, curve: Curves.bounceOut));
//     _fadeController = AnimationController(
//       duration: const Duration(milliseconds: 700),
//       vsync: this,
//     );
//     _fadeIn = Tween<double>(begin: 0, end: 1).animate(_fadeController);
//     _scanController = AnimationController(
//       vsync: this,
//       duration: const Duration(seconds: 2),
//     )..addListener(() {
//         setState(() {
//           _scanY = _scanController.value * 100;
//         });
//       });
//     _bgController = AnimationController(
//       duration: const Duration(seconds: 5),
//       vsync: this,
//     )..repeat(reverse: true);
//     _bgColor = ColorTween(
//       begin: const Color(0xFF00C9A7),
//       end: const Color(0xFFB2FEFA),
//     ).animate(_bgController);
//     _startSequence();
//   }

//   Future<void> _startSequence() async {
//     await _dropController.forward();
//     await _fadeController.forward();
//     await _scanController.forward();
//     await Future.delayed(const Duration(milliseconds: 700));
//     if (mounted) {
//       Navigator.pushReplacement(
//         context,
//         MaterialPageRoute(builder: (context) => WelcomeScreen(box: widget.box)),
//       );
//     }
//   }

//   void _skipSplash() {
//     Navigator.pushReplacement(
//       context,
//       MaterialPageRoute(builder: (context) => HomeScreen(box: widget.box)),
//     );
//   }

//   @override
//   void dispose() {
//     _dropController.dispose();
//     _fadeController.dispose();
//     _scanController.dispose();
//     _bgController.dispose();
//     super.dispose();
//   }

//   Widget buildPaperScanner() {
//     return Stack(
//       alignment: Alignment.topCenter,
//       children: [
//         Container(
//           width: 140,
//           height: 100,
//           decoration: BoxDecoration(
//             color: Colors.white,
//             borderRadius: BorderRadius.circular(6),
//             boxShadow: [
//               BoxShadow(
//                 color: Colors.black12,
//                 blurRadius: 6,
//                 offset: Offset(0, 2),
//               ),
//             ],
//           ),
//           child: const Icon(Icons.description, size: 40, color: Colors.grey),
//         ),
//         Positioned(
//           top: _scanY,
//           child: Container(
//             width: 120,
//             height: 4,
//             decoration: BoxDecoration(
//               color: Colors.lightGreenAccent,
//               borderRadius: BorderRadius.circular(4),
//             ),
//           ),
//         ),
//       ],
//     );
//   }

//   @override
//   Widget build(BuildContext context) {
//     return AnimatedBuilder(
//       animation: _bgColor,
//       builder: (context, child) {
//         return Scaffold(
//           backgroundColor: _bgColor.value,
//           body: Stack(
//             children: [
//               Center(
//                 child: Column(
//                   mainAxisAlignment: MainAxisAlignment.center,
//                   children: [
//                     SlideTransition(
//                       position: _logoDrop,
//                       child: const Icon(Icons.document_scanner,
//                           size: 70, color: Colors.white),
//                     ),
//                     const SizedBox(height: 30),
//                     FadeTransition(
//                       opacity: _fadeIn,
//                       child: Column(
//                         children: [
//                           const Text(
//                             "MEDISCAN",
//                             style: TextStyle(
//                               fontSize: 28,
//                               fontWeight: FontWeight.bold,
//                               color: Colors.white,
//                               letterSpacing: 2,
//                             ),
//                           ),
//                           const SizedBox(height: 30),
//                           buildPaperScanner(),
//                         ],
//                       ),
//                     ),
//                   ],
//                 ),
//               ),
//               Positioned(
//                 top: 40,
//                 right: 20,
//                 child: TextButton(
//                   onPressed: _skipSplash,
//                   style: TextButton.styleFrom(
//                     backgroundColor: Colors.white.withOpacity(0.2),
//                     foregroundColor: Colors.white,
//                     padding:
//                         const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
//                     shape: RoundedRectangleBorder(
//                       borderRadius: BorderRadius.circular(30),
//                     ),
//                   ),
//                   child: const Text("Skip"),
//                 ),
//               ),
//             ],
//           ),
//         );
//       },
//     );
//   }
// }

// class HomeScreen extends StatelessWidget {
//   final Box<TextModel> box;
//   const HomeScreen({super.key, required this.box});

//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       appBar: AppBar(
//         title: const Text('MediScan Home'),
//         backgroundColor: const Color(0xFF00B4DB),
//       ),
//       body: Center(
//         child: Column(
//           mainAxisAlignment: MainAxisAlignment.center,
//           children: [
//             const Text('Welcome to MediScan!'),
//             ElevatedButton(
//               onPressed: () {
//                 Navigator.push(
//                   context,
//                   MaterialPageRoute(
//                     builder: (context) => TextExtractorScreen(box: box),
//                   ),
//                 );
//               },
//               child: const Text('Go to Text Extractor'),
//             ),
//           ],
//         ),
//       ),
//     );
//   }
// }

// import 'dart:async';
// import 'dart:io' show Platform;
// import 'package:flutter/foundation.dart' show kIsWeb;
// import 'package:flutter/material.dart';
// import 'package:hive/hive.dart';
// import 'package:hive_flutter/hive_flutter.dart';
// import 'package:path_provider/path_provider.dart';
// import 'package:google_fonts/google_fonts.dart';
// import 'screens/text_extractor_screen.dart';
// import 'models/text_model.dart';
// // import 'screens/register_screen.dart'; // Import the Register Screen
// // import 'screens/login_screen.dart'; // Import your Login Screen
// import 'package:image_picker/image_picker.dart'; // Import for image picker functionality

// // Initialize Hive
// Future<Box<TextModel>> _initializeHive() async {
//   if (!kIsWeb) {
//     final appDocDir = await getApplicationDocumentsDirectory();
//     await Hive.initFlutter(appDocDir.path);
//     debugPrint('Hive initialized for native at: ${appDocDir.path}');
//   } else {
//     await Hive.initFlutter();
//     debugPrint('Hive initialized for web');
//   }
//   Hive.registerAdapter(TextModelAdapter());
//   final box = await Hive.openBox<TextModel>('text_model');
//   debugPrint('Box opened, size: ${box.length}');
//   if (box.isNotEmpty) {
//     for (var i = 0; i < box.length; i++) {
//       final item = box.getAt(i);
//       debugPrint(
//           'Document $i: name=${item?.name}, content=${item?.content}, date=${item?.dateTime}');
//     }
//   } else {
//     debugPrint('Box is empty on startup');
//   }
//   return box;
// }

// void main() async {
//   WidgetsFlutterBinding.ensureInitialized();
//   final boxFuture = _initializeHive();

//   runApp(
//     FutureBuilder<Box<TextModel>>(
//       future: boxFuture,
//       builder: (context, snapshot) {
//         if (snapshot.connectionState == ConnectionState.done) {
//           if (snapshot.hasError) {
//             debugPrint('Hive initialization error: ${snapshot.error}');
//             return MaterialApp(
//               home: Scaffold(
//                 body: Center(child: Text('Error initializing Hive: ${snapshot.error}')),
//               ),
//             );
//           }
//           return MediScanApp(box: snapshot.data!);
//         }
//         return const MaterialApp(
//           home: Scaffold(
//             body: Center(child: CircularProgressIndicator()),
//           ),
//         );
//       },
//     ),
//   );
// }

// class MediScanApp extends StatelessWidget {
//   final Box<TextModel> box;
//   const MediScanApp({super.key, required this.box});

//   @override
//   Widget build(BuildContext context) {
//     return MaterialApp(
//       title: 'MediScan',
//       debugShowCheckedModeBanner: false,
//       theme: ThemeData(
//         primarySwatch: Colors.indigo,
//         textTheme: GoogleFonts.notoSansTextTheme(
//           Theme.of(context).textTheme,
//         ),
//       ),
//       home: SplashScreen(box: box),
//       routes: {
//         '/login': (context) => const LoginScreen(),
//         '/register': (context) => const RegisterScreen(),
//       },
//     );
//   }
// }

// class SplashScreen extends StatefulWidget {
//   final Box<TextModel> box;
//   const SplashScreen({super.key, required this.box});

//   @override
//   State<SplashScreen> createState() => _SplashScreenState();
// }

// class _SplashScreenState extends State<SplashScreen> with TickerProviderStateMixin {
//   late AnimationController _dropController;
//   late Animation<Offset> _logoDrop;
//   late AnimationController _fadeController;
//   late Animation<double> _fadeIn;
//   late AnimationController _scanController;
//   double _scanY = 0;
//   late AnimationController _bgController;
//   late Animation<Color?> _bgColor;

//   @override
//   void initState() {
//     super.initState();
//     _dropController = AnimationController(
//       duration: const Duration(milliseconds: 900),
//       vsync: this,
//     );
//     _logoDrop = Tween<Offset>(begin: const Offset(0, -2), end: Offset.zero)
//         .animate(CurvedAnimation(parent: _dropController, curve: Curves.bounceOut));
//     _fadeController = AnimationController(
//       duration: const Duration(milliseconds: 700),
//       vsync: this,
//     );
//     _fadeIn = Tween<double>(begin: 0, end: 1).animate(_fadeController);
//     _scanController = AnimationController(
//       vsync: this,
//       duration: const Duration(seconds: 2),
//     )..addListener(() {
//         setState(() {
//           _scanY = _scanController.value * 100;
//         });
//       });
//     _bgController = AnimationController(
//       duration: const Duration(seconds: 5),
//       vsync: this,
//     )..repeat(reverse: true);
//     _bgColor = ColorTween(
//       begin: const Color(0xFF00C9A7),
//       end: const Color(0xFFB2FEFA),
//     ).animate(_bgController);
//     _startSequence();
//   }

//   Future<void> _startSequence() async {
//     await _dropController.forward();
//     await _fadeController.forward();
//     await _scanController.forward();
//     await Future.delayed(const Duration(milliseconds: 700));
//     if (mounted) {
//       Navigator.pushReplacement(
//         context,
//         MaterialPageRoute(builder: (context) => const LoginScreen()),
//       );
//     }
//   }

//   void _skipSplash() {
//     Navigator.pushReplacement(
//       context,
//       MaterialPageRoute(builder: (context) => const LoginScreen()),
//     );
//   }

//   @override
//   void dispose() {
//     _dropController.dispose();
//     _fadeController.dispose();
//     _scanController.dispose();
//     _bgController.dispose();
//     super.dispose();
//   }

//   Widget buildPaperScanner() {
//     return Stack(
//       alignment: Alignment.topCenter,
//       children: [
//         Container(
//           width: 140,
//           height: 100,
//           decoration: BoxDecoration(
//             color: Colors.white,
//             borderRadius: BorderRadius.circular(6),
//             boxShadow: [
//               BoxShadow(
//                 color: Colors.black12,
//                 blurRadius: 6,
//                 offset: Offset(0, 2),
//               ),
//             ],
//           ),
//           child: const Icon(Icons.description, size: 40, color: Colors.grey),
//         ),
//         Positioned(
//           top: _scanY,
//           child: Container(
//             width: 120,
//             height: 4,
//             decoration: BoxDecoration(
//               color: Colors.lightGreenAccent,
//               borderRadius: BorderRadius.circular(4),
//             ),
//           ),
//         ),
//       ],
//     );
//   }

//   @override
//   Widget build(BuildContext context) {
//     return AnimatedBuilder(
//       animation: _bgColor,
//       builder: (context, child) {
//         return Scaffold(
//           backgroundColor: _bgColor.value,
//           body: Stack(
//             children: [
//               Center(
//                 child: Column(
//                   mainAxisAlignment: MainAxisAlignment.center,
//                   children: [
//                     SlideTransition(
//                       position: _logoDrop,
//                       child: const Icon(Icons.document_scanner,
//                           size: 70, color: Colors.white),
//                     ),
//                     const SizedBox(height: 30),
//                     FadeTransition(
//                       opacity: _fadeIn,
//                       child: Column(
//                         children: [
//                           const Text(
//                             "MEDISCAN",
//                             style: TextStyle(
//                               fontSize: 28,
//                               fontWeight: FontWeight.bold,
//                               color: Colors.white,
//                               letterSpacing: 2,
//                             ),
//                           ),
//                           const SizedBox(height: 30),
//                           buildPaperScanner(),
//                         ],
//                       ),
//                     ),
//                   ],
//                 ),
//               ),
//               Positioned(
//                 top: 40,
//                 right: 20,
//                 child: TextButton(
//                   onPressed: _skipSplash,
//                   style: TextButton.styleFrom(
//                     backgroundColor: Colors.white.withOpacity(0.2),
//                     foregroundColor: Colors.white,
//                     padding:
//                         const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
//                     shape: RoundedRectangleBorder(
//                       borderRadius: BorderRadius.circular(30),
//                     ),
//                   ),
//                   child: const Text("Skip"),
//                 ),
//               ),
//             ],
//           ),
//         );
//       },
//     );
//   }
// }

// import 'dart:async';
// import 'dart:io' show Platform;
// import 'package:flutter/foundation.dart' show kIsWeb;
// import 'package:flutter/material.dart';
// import 'package:hive/hive.dart';
// import 'package:hive_flutter/hive_flutter.dart';
// import 'package:path_provider/path_provider.dart';
// import 'package:google_fonts/google_fonts.dart';
// import 'screens/text_extractor_screen.dart';
// import 'models/text_model.dart';
// import 'screens/welcome_screen.dart';

// Future<Box<TextModel>> _initializeHive() async {
//   if (!kIsWeb) {
//     final appDocDir = await getApplicationDocumentsDirectory();
//     await Hive.initFlutter(appDocDir.path);
//     debugPrint('Hive initialized for native at: ${appDocDir.path}');
//   } else {
//     await Hive.initFlutter();
//     debugPrint('Hive initialized for web');
//   }
//   Hive.registerAdapter(TextModelAdapter());
//   final box = await Hive.openBox<TextModel>('text_model');
//   debugPrint('Box opened, size: ${box.length}');
//   return box;
// }

// void main() async {
//   WidgetsFlutterBinding.ensureInitialized();
//   final boxFuture = _initializeHive(); // Initialize Hive in the background

//   runApp(
//     MediScanApp(boxFuture: boxFuture),
//   );
// }

// class MediScanApp extends StatelessWidget {
//   final Future<Box<TextModel>> boxFuture; // Pass Future<Box> to the app
//   const MediScanApp({super.key, required this.boxFuture});

//   @override
//   Widget build(BuildContext context) {
//     return MaterialApp(
//       title: 'MediScan',
//       debugShowCheckedModeBanner: false,
//       theme: ThemeData(
//         primarySwatch: Colors.indigo,
//         textTheme: GoogleFonts.notoSansTextTheme(
//           Theme.of(context).textTheme,
//         ),
//       ),
//       home: SplashScreen(boxFuture: boxFuture), // Show SplashScreen first
//     );
//   }
// }

// class SplashScreen extends StatefulWidget {
//   final Future<Box<TextModel>> boxFuture;
//   const SplashScreen({super.key, required this.boxFuture});

//   @override
//   State<SplashScreen> createState() => _SplashScreenState();
// }

// class _SplashScreenState extends State<SplashScreen> with TickerProviderStateMixin {
//   late AnimationController _dropController;
//   late Animation<Offset> _logoDrop;
//   late AnimationController _fadeController;
//   late Animation<double> _fadeIn;
//   late AnimationController _scanController;
//   double _scanY = 0;
//   late AnimationController _bgController;
//   late Animation<Color?> _bgColor;

//   @override
//   void initState() {
//     super.initState();
//     _dropController = AnimationController(
//       duration: const Duration(milliseconds: 900),
//       vsync: this,
//     );
//     _logoDrop = Tween<Offset>(begin: const Offset(0, -2), end: Offset.zero)
//         .animate(CurvedAnimation(parent: _dropController, curve: Curves.bounceOut));
//     _fadeController = AnimationController(
//       duration: const Duration(milliseconds: 700),
//       vsync: this,
//     );
//     _fadeIn = Tween<double>(begin: 0, end: 1).animate(_fadeController);
//     _scanController = AnimationController(
//       vsync: this,
//       duration: const Duration(seconds: 2),
//     )..addListener(() {
//         setState(() {
//           _scanY = _scanController.value * 100;
//         });
//       });
//     _bgController = AnimationController(
//       duration: const Duration(seconds: 5),
//       vsync: this,
//     )..repeat(reverse: true);
//     _bgColor = ColorTween(
//       begin: const Color(0xFF00C9A7),
//       end: const Color(0xFFB2FEFA),
//     ).animate(_bgController);
//     _startSequence();
//   }

//   Future<void> _startSequence() async {
//     await _dropController.forward();
//     await _fadeController.forward();
//     await _scanController.forward();
//     await Future.delayed(const Duration(milliseconds: 700));

//     // Wait for Hive initialization and then navigate
//     final box = await widget.boxFuture;
//     if (mounted) {
//       Navigator.pushReplacement(
//         context,
//         MaterialPageRoute(builder: (context) => WelcomeScreen(box: box)),
//       );
//     }
//   }

//   @override
//   void dispose() {
//     _dropController.dispose();
//     _fadeController.dispose();
//     _scanController.dispose();
//     _bgController.dispose();
//     super.dispose();
//   }

//   @override
//   Widget build(BuildContext context) {
//     return AnimatedBuilder(
//       animation: _bgColor,
//       builder: (context, child) {
//         return Scaffold(
//           backgroundColor: _bgColor.value,
//           body: Stack(
//             children: [
//               Center(
//                 child: Column(
//                   mainAxisAlignment: MainAxisAlignment.center,
//                   children: [
//                     SlideTransition(
//                       position: _logoDrop,
//                       child: const Icon(Icons.document_scanner,
//                           size: 70, color: Colors.white),
//                     ),
//                     const SizedBox(height: 30),
//                     FadeTransition(
//                       opacity: _fadeIn,
//                       child: Column(
//                         children: [
//                           const Text(
//                             "MEDISCAN",
//                             style: TextStyle(
//                               fontSize: 28,
//                               fontWeight: FontWeight.bold,
//                               color: Colors.white,
//                               letterSpacing: 2,
//                             ),
//                           ),
//                           const SizedBox(height: 30),
//                           buildPaperScanner(),
//                         ],
//                       ),
//                     ),
//                   ],
//                 ),
//               ),
//               Positioned(
//                 top: 40,
//                 right: 20,
//                 child: TextButton(
//                   onPressed: () {
//                     Navigator.pushReplacement(
//                       context,
//                       MaterialPageRoute(
//                         builder: (context) => WelcomeScreen(
//                           box: widget.boxFuture as Box<TextModel>,
//                         ),
//                       ),
//                     );
//                   },
//                   style: TextButton.styleFrom(
//                     backgroundColor: Colors.white.withOpacity(0.2),
//                     foregroundColor: Colors.white,
//                     padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
//                     shape: RoundedRectangleBorder(
//                       borderRadius: BorderRadius.circular(30),
//                     ),
//                   ),
//                   child: const Text("Skip"),
//                 ),
//               ),
//             ],
//           ),
//         );
//       },
//     );
//   }

//   Widget buildPaperScanner() {
//     return Stack(
//       alignment: Alignment.topCenter,
//       children: [
//         Container(
//           width: 140,
//           height: 100,
//           decoration: BoxDecoration(
//             color: Colors.white,
//             borderRadius: BorderRadius.circular(6),
//             boxShadow: [
//               BoxShadow(
//                 color: Colors.black12,
//                 blurRadius: 6,
//                 offset: Offset(0, 2),
//               ),
//             ],
//           ),
//           child: const Icon(Icons.description, size: 40, color: Colors.grey),
//         ),
//         Positioned(
//           top: _scanY,
//           child: Container(
//             width: 120,
//             height: 4,
//             decoration: BoxDecoration(
//               color: Colors.lightGreenAccent,
//               borderRadius: BorderRadius.circular(4),
//             ),
//           ),
//         ),
//       ],
//     );
//   }
// }

import 'dart:async';
import 'dart:io' show Platform;
import 'package:flutter/foundation.dart' show kIsWeb;
import 'package:flutter/material.dart';
import 'package:hive/hive.dart';
import 'package:hive_flutter/hive_flutter.dart';
import '../widgets/vertical_tab_sidebar.dart'; // Add this at the top
import 'package:path_provider/path_provider.dart';
import 'package:google_fonts/google_fonts.dart';
import 'screens/text_extractor_screen.dart';
import 'models/text_model.dart';
import 'package:firebase_core/firebase_core.dart';
import 'screens/welcome_screen.dart';
import 'firebase_options.dart';
import 'services/auth_service.dart';

Future<Box<TextModel>> _initializeHive() async {
  if (!kIsWeb) {
    final appDocDir = await getApplicationDocumentsDirectory();
    await Hive.initFlutter(appDocDir.path);
    debugPrint('Hive initialized for native at: ${appDocDir.path}');
  } else {
    await Hive.initFlutter();
    debugPrint('Hive initialized for web');
  }
  Hive.registerAdapter(TextModelAdapter());
  final box = await Hive.openBox<TextModel>('text_model');
  debugPrint('Box opened, size: ${box.length}');
  return box;
}

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  if(kIsWeb){
    await Firebase.initializeApp(
      options: const FirebaseOptions(
        apiKey: "AIzaSyDvmcsqJaz0kUBBCyjVGwhd2wJIMcGiKEU",
        authDomain: "mediscan-textdigitizer-d37ad.firebaseapp.com",
        projectId: "mediscan-textdigitizer-d37ad",
        storageBucket: "mediscan-textdigitizer-d37ad.firebasestorage.app",
        messagingSenderId: "189601133833",
        appId: "1:189601133833:web:d3822fa00ffb0076e44fd8",
        measurementId: "G-SNLZL9VK6Q",
      ),
    );
  }
  await Firebase.initializeApp(
    options: DefaultFirebaseOptions.currentPlatform,
  );
  final boxFuture = _initializeHive(); // Initialize Hive in the background

  runApp(
    MediScanApp(boxFuture: boxFuture),
  );
}

class MediScanApp extends StatelessWidget {
  final Future<Box<TextModel>> boxFuture;
  const MediScanApp({super.key, required this.boxFuture});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'MediScan',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        primarySwatch: Colors.indigo,
        textTheme: GoogleFonts.notoSansTextTheme(
          Theme.of(context).textTheme,
        ),
      ),
      home: SplashScreen(boxFuture: boxFuture),
    );
  }
}

class SplashScreen extends StatefulWidget {
  final Future<Box<TextModel>> boxFuture;
  const SplashScreen({super.key, required this.boxFuture});

  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen> with TickerProviderStateMixin {
  late AnimationController _dropController;
  late Animation<Offset> _logoDrop;
  late AnimationController _fadeController;
  late Animation<double> _fadeIn;
  late AnimationController _scanController;
  double _scanY = 0;
  late AnimationController _bgController;
  late Animation<Color?> _bgColor;

  @override
  void initState() {
    super.initState();
    _dropController = AnimationController(
      duration: const Duration(milliseconds: 900),
      vsync: this,
    );
    _logoDrop = Tween<Offset>(begin: const Offset(0, -2), end: Offset.zero)
        .animate(CurvedAnimation(parent: _dropController, curve: Curves.bounceOut));
    _fadeController = AnimationController(
      duration: const Duration(milliseconds: 700),
      vsync: this,
    );
    _fadeIn = Tween<double>(begin: 0, end: 1).animate(_fadeController);
    _scanController = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 2),
    )..addListener(() {
        setState(() {
          _scanY = _scanController.value * 100;
        });
      });
    _bgController = AnimationController(
      duration: const Duration(seconds: 5),
      vsync: this,
    )..repeat(reverse: true);
    _bgColor = ColorTween(
      begin: const Color(0xFF00C9A7),
      end: const Color(0xFFB2FEFA),
    ).animate(_bgController);
    _startSequence();
  }

  Future<void> _startSequence() async {
    await _dropController.forward();
    await _fadeController.forward();
    await _scanController.forward();
    await Future.delayed(const Duration(milliseconds: 700));

    final box = await widget.boxFuture;
    if (mounted) {
      Navigator.pushReplacement(
        context,
        MaterialPageRoute(builder: (context) => WelcomeScreen(box: box)),
      );
    }
  }

  @override
  void dispose() {
    _dropController.dispose();
    _fadeController.dispose();
    _scanController.dispose();
    _bgController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: _bgColor,
      builder: (context, child) {
        return Scaffold(
          backgroundColor: _bgColor.value,
          body: Stack(
            children: [
              Center(
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    SlideTransition(
                      position: _logoDrop,
                      child: const Icon(Icons.document_scanner,
                          size: 70, color: Colors.white),
                    ),
                    const SizedBox(height: 30),
                    FadeTransition(
                      opacity: _fadeIn,
                      child: Column(
                        children: [
                          const Text(
                            "MEDISCAN",
                            style: TextStyle(
                              fontSize: 28,
                              fontWeight: FontWeight.bold,
                              color: Colors.white,
                              letterSpacing: 2,
                            ),
                          ),
                          const SizedBox(height: 30),
                          buildPaperScanner(),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
              Positioned(
                top: 40,
                right: 20,
                child: TextButton(
                  onPressed: () async {
                    final box = await widget.boxFuture;
                    if (!mounted) return;
                    Navigator.pushReplacement(
                      context,
                      MaterialPageRoute(
                        builder: (context) => WelcomeScreen(box: box),
                      ),
                    );
                  },
                  style: TextButton.styleFrom(
                    backgroundColor: Colors.white.withOpacity(0.2),
                    foregroundColor: Colors.white,
                    padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(30),
                    ),
                  ),
                  child: const Text("Skip"),
                ),
              ),
            ],
          ),
        );
      },
    );
  }

  Widget buildPaperScanner() {
    return Stack(
      alignment: Alignment.topCenter,
      children: [
        Container(
          width: 140,
          height: 100,
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(6),
            boxShadow: [
              BoxShadow(
                color: Colors.black12,
                blurRadius: 6,
                offset: Offset(0, 2),
              ),
            ],
          ),
          child: const Icon(Icons.description, size: 40, color: Colors.grey),
        ),
        Positioned(
          top: _scanY,
          child: Container(
            width: 120,
            height: 4,
            decoration: BoxDecoration(
              color: Colors.lightGreenAccent,
              borderRadius: BorderRadius.circular(4),
            ),
          ),
        ),
      ],
    );
  }
}
